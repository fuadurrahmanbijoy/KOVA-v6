import { app, dialog } from 'electron';
import { isAbsolute, join, relative, resolve } from 'node:path';
import { singleInstance, onFiles } from './src/kit/handoff';
import { registerRpc, expose, type RpcTable } from './src/kit/rpc';
import { registerIcons } from './src/kit/icons';
import { createFrame } from './src/kit/window';
import * as F from './src/foundation';
import * as I from './src/installer';
import * as R from './src/runner';
import * as S from './src/seal';
import * as FR from './src/frame';

// Argument checks for the RPC allowlist (renderer input is never trusted).
type T = 'string' | 'number' | 'boolean' | 'array' | 'object' | 'any' | 'string?' | 'boolean?' | 'number?';
const need = (...t: T[]) => (a: unknown[]) => t.forEach((k, i) => {
  const v = a[i], opt = k.endsWith('?'), base = k.replace('?', '');
  if (v === undefined && opt) return; if (base === 'any') return;
  const ok = base === 'array' ? Array.isArray(v) : base === 'object' ? typeof v === 'object' && v !== null && !Array.isArray(v) : typeof v === base;
  if (!ok) throw new Error(`KV-RPC: argument ${i + 1} must be ${base}`);
});
const kvFiles = /\.(kvx|kvcore|kvlib|kvpart)$/i;
const files = (a: unknown[]) => { if (!Array.isArray(a[0]) || a[0].length > 200 || !a[0].every((f) => typeof f === 'string' && kvFiles.test(f))) throw new Error('KV-RPC: expected a list of Kova files'); };
const one = (re: RegExp) => (a: unknown[]) => { if (typeof a[0] !== 'string' || !re.test(a[0])) throw new Error('KV-RPC: unexpected file type'); };
const under = (root: string) => (a: unknown[]) => {
  if (typeof a[0] !== 'string') throw new Error('KV-RPC: path must be a string');
  const rel = relative(resolve(root), resolve(a[0])); if (rel.startsWith('..') || isAbsolute(rel)) throw new Error('KV-RPC: path is outside the Library');
};

if (singleInstance()) {
  app.whenReady().then(async () => {
    try {
      const foundation = F.create();
      const installer = I.create(foundation);
      const runner = R.create(foundation, installer);
      const seal = S.create(foundation, installer, runner);
      registerIcons();
      // The window and its autohide controls belong to the kit. Parts never create windows.
      const window = createFrame({ shellHtml: join(__dirname, 'ui', 'shell.html'), shellPreload: join(__dirname, 'preload-shell.js') });
      const frame = FR.create({ foundation, installer, runner, seal, window });
      // Hooks (rev 4). Both are registered BEFORE frame.start():
      //   runner.onChoose        <- Frame provides the dialog (frame.chooseOne), the Runner uses it for `open`.
      //   installer.onBeforeChange <- the Runner provides the action (stop the app), the Installer calls it before remove/switch/update/disable.
      runner.onChoose((q, options) => frame.chooseOne(q, options));
      installer.onBeforeChange(async (id) => { await runner.stop(id); });
      // Composite view: installer.apps.list() merged with the Runner's state as runState.
      const withRun = <A extends { id: string }>(a: A) => ({ ...a, runState: runner.state(a.id) });
      const apps = {
        list: () => installer.apps.list().map(withRun),
        get: (id: string) => { const a = installer.apps.get(id); return a ? withRun(a) : null; },
      };
      const table: RpcTable = {
        'installer.apps.list': { fn: apps.list },
        'installer.apps.get': { fn: apps.get, check: need('string') },
        ...expose('installer', installer, ['apps.summary', 'apps.setAutoStart', 'apps.setEnabled', 'apps.remove', 'versions.switch', 'versions.remove', 'versions.snapshots', 'versions.restore', 'waiting.list', 'waiting.discard', 'defaults.get', 'defaults.set', 'exportSet'],
          { 'apps.summary': need('string'), 'apps.setAutoStart': need('string', 'boolean'), 'apps.setEnabled': need('string', 'boolean'), 'apps.remove': need('string', 'boolean'), 'versions.switch': need('string', 'string'), 'versions.remove': need('string', 'string', 'boolean'), 'versions.snapshots': need('string'), 'versions.restore': need('string', 'string'), 'waiting.discard': need('string'), 'defaults.set': need('string'), exportSet: need('string', 'string') }),
        // foundation.fs.* and foundation.index.* are NOT exposed; renderers never write files or the index directly.
        ...expose('foundation', foundation, ['log.tail', 'bank.get', 'redact', 'safeMode.isOn', 'safeMode.request', 'repair.forApp', 'repair.forCore', 'repair.friendly', 'repair.diagnostics', 'repair.bundle', 'repair.files', 'quit.request', 'profile.read', 'space.check', 'settings.get', 'settings.set'],
          { 'log.tail': need('number'), 'bank.get': need('string'), redact: need('string'), 'repair.forApp': need('object'), 'repair.forCore': need('array'), 'repair.friendly': need('string'), 'repair.bundle': need('object'), 'repair.files': need('object'), 'space.check': need('number'), 'settings.get': need('string', 'any'), 'settings.set': need('string', 'any') }),
        ...expose('runner', runner, ['start', 'stop', 'pause', 'state', 'busy', 'stats', 'setShape', 'open', 'report', 'logTail'],
          { start: need('string'), stop: need('string', 'boolean?'), pause: need('string'), state: need('string'), setShape: need('string', 'string'), open: need('object'), report: need('string', 'string'), logTail: need('string', 'number') }),
        ...expose('seal', seal, ['exportLibrary', 'importLibrary', 'installCore', 'listCores', 'removeCore', 'runtimeInfo'],
          { exportLibrary: need('array', 'string'), importLibrary: (a) => { need('string')(a); one(/\.kvlib$/i)(a); }, installCore: (a) => { need('string')(a); one(/\.kvcore$/i)(a); }, removeCore: need('string') }),
        ...expose('frame', frame, ['handleFiles', 'pickFile', 'openFolder', 'copyText', 'toast', 'show', 'restart'],
          { handleFiles: files, pickFile: need('object'), openFolder: (a) => { need('string')(a); under(foundation.paths.root)(a); }, copyText: need('string'), toast: need('string'), show: need('string', 'any') }),
      };
      registerRpc(table, { allowedSender: () => window.win.webContents });
      onFiles((f) => frame.handleFiles(f));
      await frame.start();
      foundation.quit.markStartedOk();
    } catch (e: any) { dialog.showErrorBox('Kova could not start', String(e?.stack ?? e).slice(0, 1500)); app.quit(); }
  });
}
