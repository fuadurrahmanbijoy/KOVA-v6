(() => {
  if (window.__kovaIcons) return; window.__kovaIcons = true;
  const cache = new Map();
  const keyOf = (e) => e.dataset.icon + (e.hasAttribute('data-filled') ? '!' : '') + (e.dataset.size || '24');
  async function fill(e) {
    if (!window.kova || !window.kova.icon || !e.dataset.icon) return;
    const k = keyOf(e); if (e.dataset.done === k) return;
    let u = cache.get(k);
    if (!u) { u = await window.kova.icon(e.dataset.icon, e.hasAttribute('data-filled'), +(e.dataset.size || 24)); cache.set(k, u); }
    e.style.setProperty('--src', 'url("' + u + '")'); e.classList.add('k-ic'); e.dataset.done = k;
  }
  const scan = (r) => r.querySelectorAll && r.querySelectorAll('[data-icon]').forEach(fill);
  new MutationObserver((ms) => { for (const m of ms) { if (m.type === 'attributes') fill(m.target); else m.addedNodes.forEach((n) => { if (n.nodeType === 1) { if (n.matches && n.matches('[data-icon]')) fill(n); scan(n); } }); } })
    .observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-icon', 'data-filled', 'data-size'] });
  scan(document);
})();

(() => {
  if (window.__kovaSel) return; window.__kovaSel = true;
  let uid = 0, openInst = null;
  // ONE delegated listener for every select on the page (no per-instance document listeners to leak).
  document.addEventListener('mousedown', (e) => { if (openInst && !openInst.w.contains(e.target)) openInst.close(); });
  function up(sel) {
    if (sel.dataset.kdone) return; sel.dataset.kdone = '1';
    const id = 'ksel' + (++uid);
    const w = document.createElement('div'); w.className = 'k-sel'; sel.parentNode.insertBefore(w, sel); w.appendChild(sel);
    const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'k-sel-btn'; btn.id = id + '-btn';
    btn.setAttribute('role', 'combobox'); btn.setAttribute('aria-haspopup', 'listbox'); btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-controls', id + '-menu'); w.appendChild(btn);
    const lab = (sel.id && document.querySelector('label[for="' + CSS.escape(sel.id) + '"]')) || sel.closest('label');
    if (lab) { if (!lab.id) lab.id = id + '-label'; btn.setAttribute('aria-labelledby', lab.id + ' ' + btn.id); }
    else if (sel.getAttribute('aria-labelledby')) btn.setAttribute('aria-labelledby', sel.getAttribute('aria-labelledby') + ' ' + btn.id);
    else if (sel.getAttribute('aria-label')) btn.setAttribute('aria-label', sel.getAttribute('aria-label'));
    let menu = null, idx = 0, buf = '', bufT = 0;
    const label = () => { const o = sel.options[sel.selectedIndex]; btn.textContent = o ? o.textContent : ''; };
    const active = () => {
      if (!menu) return; [...menu.children].forEach((c, i) => c.classList.toggle('active', i === idx));
      const cur = menu.children[idx]; if (cur) { menu.setAttribute('aria-activedescendant', cur.id); btn.setAttribute('aria-activedescendant', cur.id); cur.scrollIntoView({ block: 'nearest' }); }
    };
    const close = () => { if (menu) { menu.remove(); menu = null; } w.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); btn.removeAttribute('aria-activedescendant'); if (openInst === inst) openInst = null; };
    const inst = { w, close };
    const choose = (i) => { sel.selectedIndex = i; sel.dispatchEvent(new Event('change', { bubbles: true })); label(); close(); btn.focus(); };
    const open = () => {
      if (menu) return close(); if (openInst) openInst.close();
      menu = document.createElement('div'); menu.className = 'k-sel-menu'; menu.id = id + '-menu'; menu.setAttribute('role', 'listbox'); idx = Math.max(0, sel.selectedIndex);
      if (lab) menu.setAttribute('aria-labelledby', lab.id);
      [...sel.options].forEach((o, i) => { const d = document.createElement('div'); d.className = 'k-sel-opt'; d.id = id + '-o' + i; d.setAttribute('role', 'option'); d.setAttribute('aria-selected', String(i === sel.selectedIndex)); d.textContent = o.textContent; d.onmousedown = (e) => { e.preventDefault(); choose(i); }; menu.appendChild(d); });
      w.appendChild(menu); w.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); openInst = inst; active();
    };
    btn.onclick = open;
    btn.onkeydown = (e) => {
      const n = sel.options.length;
      if (e.key === 'Tab') { close(); return; }                       // Tab closes the menu and moves on
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!menu) open(); idx = (idx + (e.key === 'ArrowDown' ? 1 : n - 1)) % n; active(); }
      else if (e.key === 'Home' || e.key === 'End') { e.preventDefault(); if (!menu) open(); idx = e.key === 'Home' ? 0 : n - 1; active(); }
      else if ((e.key === 'Enter' || e.key === ' ') && menu && !buf) { e.preventDefault(); choose(idx); }
      else if (e.key === 'Escape') { if (menu) { e.preventDefault(); e.stopPropagation(); } close(); }
      else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {                     // typeahead
        const t = Date.now(); buf = (t - bufT < 700 ? buf : '') + e.key.toLowerCase(); bufT = t; setTimeout(() => { if (Date.now() - bufT >= 690) buf = ''; }, 700);
        if (!menu) open();
        const from = buf.length === 1 ? idx + 1 : idx;
        for (let k = 0; k < n; k++) { const i = (from + k) % n; if (sel.options[i].textContent.trim().toLowerCase().startsWith(buf)) { idx = i; break; } }
        e.preventDefault(); active();
      }
    };
    sel.addEventListener('change', label); label();
  }
  const scan = (r) => r.querySelectorAll && r.querySelectorAll('select.k-select').forEach(up);
  new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((n) => { if (n.nodeType === 1) { if (n.matches && n.matches('select.k-select')) up(n); scan(n); } }))).observe(document.documentElement, { childList: true, subtree: true });
  scan(document);
})();
