#!/usr/bin/env python3
"""Copy the shared scripts from core-kit/scripts (single source of truth) into app-kit/scripts.  python tools/sync-kits.py [app-kit dir]"""
import sys, os, shutil, pathlib
core = pathlib.Path(__file__).resolve().parent.parent
app = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else core.parent / 'app-kit'
SHARED = ['assemble.py', 'pack-part.py', 'pack-kvx.py', 'wire-app.py', 'verify.py', 'fp.py', 'mint-id.py', 'kvlib.py']  # kvlib.py: shared helpers imported by the others
(app / 'scripts').mkdir(parents=True, exist_ok=True)
for f in SHARED: shutil.copyfile(core / 'scripts' / f, app / 'scripts' / f)
print('synced', len(SHARED), 'files ->', app / 'scripts')
