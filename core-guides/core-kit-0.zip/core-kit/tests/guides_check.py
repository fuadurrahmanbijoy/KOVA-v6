"""Batch 3 acceptance: guides use only method names that exist in seam-types.ts and carry no stale names. Run from core-kit/: python tests/guides_check.py"""
import re, glob, sys, os
K = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
st = open(os.path.join(K, 'src/kit/seam-types.ts'), encoding='utf8').read()
B = re.compile(r'<!-- BEGIN (S2\.\d+) -->\n.*?\n<!-- END \1 -->', re.S)
def members(name):
    m = re.search(r'export interface %s \{(.*?)\n\}' % name, st, re.S); return set(re.findall(r'\b([a-zA-Z]+)\s*[(:]', m[1])) if m else set()
names = {n: members(n) for n in ('Foundation', 'Installer', 'Runner', 'Frame', 'Seal')}
fails = 0
def fail(m):
    global fails; fails += 1; print('FAIL', m)
for n in ('Foundation', 'Installer', 'Runner', 'Frame', 'Seal'):
    if len(names[n]) < 4: fail(f'could not extract members of {n}')
need = {'Foundation': ('mutate', 'update'), 'Installer': ('onBeforeChange',), 'Runner': ('onChoose',), 'Frame': ('chooseOne', 'restart')}
for n, ms in need.items():
    for x in ms:
        if x not in names[n]: fail(f'seam-types lacks {n}.{x}')
files = sorted(glob.glob(os.path.join(K, 'guides/*.md'))) + sorted(glob.glob('/tmp/w/launch/*.md'))
stale = ['index.write', 'topBar toggle', 'S10', 'S14', 'repair note', 'switchCore', 'D1 Principles', 'Use this version', 'Restart now']
allm = set().union(*names.values())
for f in files:
    t = open(f, encoding='utf8').read(); body = B.sub('', t); b = os.path.basename(f)
    for s in stale:
        if re.search(r'(?<![A-Za-z0-9.])' + re.escape(s) + r'(?![0-9])', body): fail(f'{b}: stale "{s}"')
    for m in re.finditer(r'`(?:foundation|installer|runner|frame|seal)\.([a-zA-Z.]+)`', body):
        first = m[1].split('.')[0]
        if first not in allm: fail(f'{b}: unknown member {m[0]}')
    if 'index.write' in body and 'always throws' not in body: fail(b + ': index.write')
for need_s in ('onBeforeChange', 'onChoose', 'Wiring contract', 'S2.11'):
    for f in glob.glob(os.path.join(K, 'guides/part-*.md')):
        if need_s not in open(f, encoding='utf8').read(): fail(f'{os.path.basename(f)} lacks {need_s}')
for f in glob.glob(os.path.join(K, 'guides/part-*.md')):
    if 'schema' not in re.search(r'^Use kit:.*$', open(f, encoding='utf8').read(), re.M)[0]: fail(os.path.basename(f) + ': Use kit lacks schema')
print('guides_check:', 'FAIL' if fails else 'ok'); sys.exit(1 if fails else 0)
