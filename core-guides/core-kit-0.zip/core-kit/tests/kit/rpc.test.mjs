import { test } from 'node:test'; import assert from 'node:assert/strict'; import { kit, stub } from './_setup.mjs';
const R = kit('rpc'), W = kit('window'), el = stub('electron');
const calls = []; const svc = { foundation: { hello: (a) => 'hi ' + a, nested: { deep: function () { return this === svc.foundation.nested; } } } };
const table = { ...R.expose('foundation', svc.foundation, ['hello', 'nested.deep'], { hello: (a) => { if (typeof a[0] !== 'string') throw new Error('bad arg'); } }) };
test('allowlist rejects prototype walks, unknown paths, bad args', async () => {
  for (const p of ['foundation.constructor.constructor', '__proto__', 'foundation.__proto__.x', 'constructor', 'prototype', 'toString', 'hasOwnProperty', 'foundation.fs.writeJsonAtomic', 'nope', '', 5, null, 'foundation.hello.call'])
    await assert.rejects(R.dispatch(table, p, []), /KV-RPC/, String(p));
  assert.equal(await R.dispatch(table, 'foundation.hello', ['x']), 'hi x'); assert.equal(await R.dispatch(table, 'foundation.nested.deep', []), true);
  await assert.rejects(R.dispatch(table, 'foundation.hello', [5]), /bad arg/); await assert.rejects(R.dispatch(table, 'foundation.hello', 'x'), /list/);
});
test('expose: own properties only, banned segments refused', async () => {
  class K { m() { return 1; } } const k = new K(); k.own = () => 2;
  const t = R.expose('k', k, ['m', 'own']); await assert.rejects(R.dispatch(t, 'k.m', []), /no such call/); assert.equal(await R.dispatch(t, 'k.own', []), 2);
  assert.throws(() => R.expose('x', {}, ['a.__proto__.b']), /bad path/); assert.throws(() => R.expose('x', {}, ['constructor']), /bad path/);
});
test('registerRpc checks sender and sender frame url', async () => {
  const shell = { getURL: () => 'file:///app/ui/shell.html#home' }, other = { getURL: () => 'file:///app/ui/shell.html' };
  R.registerRpc(table, { allowedSender: () => shell }); const h = el.__handlers.get('kova:call');
  assert.equal(await h({ sender: shell, senderFrame: { url: 'file:///app/ui/shell.html?x=1#y' } }, 'foundation.hello', ['a']), 'hi a');
  await assert.rejects(h({ sender: other, senderFrame: { url: 'file:///app/ui/shell.html' } }, 'foundation.hello', ['a']), /not allowed/);
  await assert.rejects(h({ sender: shell, senderFrame: { url: 'https://evil.test/' } }, 'foundation.hello', ['a']), /not allowed/);
  await assert.rejects(h({ sender: shell, senderFrame: { url: 'file:///app/other.html' } }, 'foundation.hello', ['a']), /not allowed/);
  await assert.rejects(h({ sender: shell, senderFrame: null }, 'foundation.hello', ['a']), /not allowed/);
  await assert.rejects(h({ sender: shell, senderFrame: { url: 'file:///app/ui/shell.html' } }, 'foundation.constructor.constructor', ['a']), /KV-RPC/);
});
test('window: sandbox, lockdown, csp, drag strip', () => {
  assert.equal(W.DRAG_REGION_PX, 28); const m = W.cspMeta(); for (const d of ["default-src 'self'", "img-src 'self' data:", "style-src 'self' 'unsafe-inline'", "script-src 'self'", "object-src 'none'", "base-uri 'none'", "frame-src 'none'"]) assert.ok(m.includes(d), d);
  const f = W.createFrame({ shellHtml: '/a/shell.html', shellPreload: '/a/p.js' }), log = el.__log;
  assert.equal(f.win.opts.webPreferences.sandbox, true); assert.equal(f.overlay.webContents.opts.sandbox, true); assert.equal(f.win.opts.webPreferences.contextIsolation, true);
  assert.deepEqual(f.win.webContents.openHandler(), { action: 'deny' }); let prevented = 0; for (const ev of ['will-navigate', 'will-redirect']) f.win.webContents.emit(ev, { preventDefault: () => prevented++ }); assert.equal(prevented, 2);
  let granted = null; log.permReq(null, 'media', (v) => (granted = v)); assert.equal(granted, false); assert.equal(log.permCheck(), false);
  assert.equal(f.DRAG_REGION_PX, 28); assert.equal(typeof f.controls.reveal, 'function');
});
