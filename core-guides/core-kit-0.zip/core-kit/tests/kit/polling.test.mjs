import { test, mock } from 'node:test'; import assert from 'node:assert/strict'; import { kit, stub } from './_setup.mjs';
const W = kit('window'), el = stub('electron');
test('cursor polling runs only while focused (120 ms); Ctrl+Shift+M reveals and focuses the overlay', () => {
  mock.timers.enable({ apis: ['setInterval', 'setTimeout'] });
  const f = W.createFrame({ shellHtml: '/a/s.html', shellPreload: '/a/p.js' }), log = el.__log; log.cursor = 0;
  mock.timers.tick(1000); assert.equal(log.cursor, 0, 'no polling before focus');
  f.win.emit('focus'); mock.timers.tick(1200); assert.equal(log.cursor, 10, '120 ms interval'); // 1200/120
  f.win.emit('blur'); const n = log.cursor; mock.timers.tick(2000); assert.equal(log.cursor, n, 'stopped on blur');
  const ev = { preventDefault() { this.p = true; } }; f.win.webContents.emit('before-input-event', ev, { type: 'keyDown', control: true, shift: true, alt: false, key: 'M' });
  assert.ok(ev.p); assert.equal(f.overlay.webContents.focused, true); assert.ok(f.overlay.webContents.sent.some((s) => s[0] === 'wc:focus-first'));
  assert.ok(f.overlay.bounds.width > 0, 'bounds non-zero while focus is inside the overlay'); mock.timers.tick(5000); assert.ok(f.overlay.bounds.width > 0, 'stays open while focused inside');
  f.overlay.webContents.focused = false; f.overlay.webContents.emit('blur'); mock.timers.tick(1500); assert.equal(f.overlay.bounds.width, 0);
  const ev2 = { preventDefault() { this.p = true; } }; f.win.webContents.emit('before-input-event', ev2, { type: 'keyDown', control: true, shift: false, key: 'M' }); assert.ok(!ev2.p);
  mock.timers.reset();
});
