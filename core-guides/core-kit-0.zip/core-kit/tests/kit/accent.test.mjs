import { test } from 'node:test'; import assert from 'node:assert/strict'; import { kit } from './_setup.mjs';
const A = kit('accent'), L = kit('look');
test('varsCss: invalid accents fall back (no CSS injection)', () => {
  for (const x of ['#fff;}body{display:none}', 'red', 'url(x)', '', undefined, '#12']) { const c = L.varsCss({ mode: 'light', accent: x }); assert.ok(c.includes('--k-accent:#0F6CBD'), String(x)); assert.ok(!/[{};]body|display/.test(c)); assert.equal((c.match(/\{/g) || []).length, 1); }
  assert.ok(L.varsCss({ mode: 'dark', accent: '#fc0' }).includes('--k-accent:#FFCC00'));
});
test('--k-accent-text reaches 4.5 on page, surface and tint; outline >= 3', () => {
  for (const acc of ['#FFFF00', '#FFFFFF', '#000000', '#0F6CBD', '#FFCC00', '#00FF00']) for (const mode of ['light', 'dark']) {
    const t = A.accentText(acc, mode), S = A.SURFACES[mode], tint = A.deriveAccent(acc, mode).tint;
    for (const bg of [S.page, S.surface, tint]) assert.ok(A.contrast(t, bg) >= 4.5, `${acc} ${mode} text ${t} on ${bg}: ${A.contrast(t, bg).toFixed(2)}`);
    assert.ok(A.contrast(t, S.page) >= 3);
    assert.ok(L.varsCss({ mode, accent: acc }).includes('--k-accent-text:' + t));
  }
});
test('follows=false uses light mode values', () => { assert.equal(L.varsCss({ mode: 'dark', accent: '#FFFF00' }, false), L.varsCss({ mode: 'light', accent: '#FFFF00' }, true)); });
