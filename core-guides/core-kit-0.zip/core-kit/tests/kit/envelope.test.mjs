import { test, mock } from 'node:test'; import assert from 'node:assert/strict'; import { kit } from './_setup.mjs';
const E = kit('envelope'), H = kit('handshake');
test('stamp overwrites a forged from', () => {
  const e = E.env(2, 'core', 'x', 'event', 'n', { a: 1 }), forged = { ...e, from: 'core' }, s = E.stamp(forged, 'app-7');
  assert.equal(s.from, 'app-7'); assert.equal(forged.from, 'core'); assert.deepEqual(s.body, { a: 1 }); assert.equal(s.name, 'n');
});
function rig(ctx = {}) {
  mock.timers.enable({ apis: ['setInterval', 'setTimeout', 'Date'], now: 1_000_000 });
  let cb = () => {}; const sent = [], ch = { send: (m) => sent.push(m.name), onMessage: (f) => { cb = f; return () => {}; } };
  const hs = { edition: 2, capabilities: [], appId: 'a', welcome: () => ({ ok: true, body: {} }), ...ctx };
  let res, end = 0; const p = H.coreHandshake(ch, hs).then((r) => { res = r; end = Date.now(); });
  const msg = (name, body = {}) => cb({ v: 2, id: 'i', from: 'a', to: 'core', kind: 'event', name, body, time: 0 });
  const tick = async (ms) => { for (let t = 0; t < ms; t += 250) { mock.timers.tick(250); await Promise.resolve(); } await Promise.resolve(); };
  return { msg, tick, sent, done: () => res, end: () => end, p };
}
test.afterEach(() => mock.timers.reset());
test('hello 10 s, then ready gets a FRESH 10 s', async () => {
  const r = rig(); await r.tick(9000); r.msg('hello', { id: 'a', edition: 2, needs: ['x'] }); await r.tick(9500); assert.equal(r.done(), undefined); r.msg('ready'); await r.p; assert.deepEqual(r.done(), { ok: true, needs: ['x'] }); assert.deepEqual(r.sent, ['hello', 'welcome']);
});
test('no hello in 10 s fails; no ready 10 s after hello fails', async () => {
  const a = rig(); await a.tick(10500); await a.p; assert.equal(a.done().code, 'KV-RU-001'); assert.match(a.done().reason, /hello/); mock.timers.reset();
  const b = rig(); await b.tick(5000); b.msg('hello', { id: 'a', edition: 2, needs: [] }); await b.tick(10500); await b.p; assert.equal(b.done().code, 'KV-RU-001'); assert.match(b.done().reason, /ready/);
});
test('stillLoading extends, hard cap 120 s', async () => {
  const a = rig(); for (let i = 0; i < 4; i++) { await a.tick(8000); a.msg('stillLoading'); } await a.tick(1000); assert.equal(a.done(), undefined); a.msg('hello', { id: 'a', edition: 2, needs: [] }); a.msg('ready'); await a.p; assert.equal(a.done().ok, true); mock.timers.reset();
  const b = rig(); for (let i = 0; i < 30; i++) { await b.tick(5000); b.msg('stillLoading'); b.msg('stillLoading'); b.msg('stillLoading'); } await b.p; assert.equal(b.done().ok, false); assert.ok(b.end() - 1_000_000 <= 121_000, 'cap held: ' + (b.end() - 1_000_000));
});
test('firstStartGraceMs (default 60 s) only when the version never started', async () => {
  const a = rig({ neverStartedOk: true }); await a.tick(55000); assert.equal(a.done(), undefined); a.msg('hello', { id: 'a', edition: 2, needs: [] }); await a.tick(55000); assert.equal(a.done(), undefined); a.msg('ready'); await a.p; assert.equal(a.done().ok, true); mock.timers.reset();
  const b = rig({ neverStartedOk: true, firstStartGraceMs: 20000 }); await b.tick(25000); await b.p; assert.equal(b.done().ok, false); mock.timers.reset();
  const c = rig(); await c.tick(11000); await c.p; assert.equal(c.done().ok, false);
});
test('incompatible welcome still reports KV-RU-007', async () => {
  const a = rig({ welcome: () => ({ ok: false, reason: 'too new' }) }); a.msg('hello', { id: 'a', edition: 9, needs: [] }); await a.p; assert.deepEqual([a.done().code, a.done().reason], ['KV-RU-007', 'too new']); assert.deepEqual(a.sent, ['hello', 'incompatible']);
});
