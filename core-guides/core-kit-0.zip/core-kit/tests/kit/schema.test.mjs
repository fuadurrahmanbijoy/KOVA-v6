import { test } from 'node:test'; import assert from 'node:assert/strict'; import { kit } from './_setup.mjs';
const S = kit('schema');
const bad = (r, re) => { assert.equal(r.ok, false); assert.ok(r.errors.some((e) => re.test(e)), r.errors.join('|')); };
test('kova.json: valid and ALL errors listed', () => {
  assert.ok(S.validateKovaJson({ name: 'Nova', type: 'md reader', edition: 2, opens: ['file:md', 'link:https'], dependencies: { 'left-pad': '^1.3.0' } }).ok);
  const r = S.validateKovaJson({ name: '', edition: 0, entry: '../x', opens: ['ftp:x'], sizeHint: 'huge', dependencies: { '-x': '1' } });
  assert.ok(r.errors.length >= 6, r.errors.join('|'));
});
test('withDefaults is the single source', () => {
  const d = S.withDefaults({ name: 'a', type: 'b', edition: 2 });
  assert.equal(d.entry, 'ui/index.html'); assert.equal(d.backendAutoDetect, true); assert.equal(d.runsInBackground, false); assert.equal(d.followsCoreTheme, true); assert.equal(d.sizeHint, 'regular');
  assert.equal(S.withDefaults({ name: 'a', type: 'b', edition: 2 }, true).runsInBackground, true);
  assert.equal(S.withDefaults({ name: 'a', type: 'b', edition: 2, backend: 'x.js', runsInBackground: false }).runsInBackground, false);
});
test('persisted records: valid + invalid, each carries format', () => {
  const idx = S.emptyIndex(), mk = S.emptyMarker();
  assert.ok(S.validateLibraryIndex(idx).ok); bad(S.validateLibraryIndex({ apps: 'x', defaults: 1, sets: [] }), /format/);
  assert.ok(S.validateMarker(mk).ok); bad(S.validateMarker({ ...mk, failStreak: -1, pendingFirstStart: 'y' }), /failStreak/); bad(S.validateMarker({ next: 1 }), /format/);
  const app = { format: 1, id: 'a-b-1234', name: 'a', type: 'b', icon: 'x', active: 'k1', versions: ['k1'], enabled: true, autoStart: false, installedAt: 1 };
  assert.ok(S.validateAppRecord(app).ok); bad(S.validateAppRecord({ ...app, active: 'zz' }), /active/);
  const v = { format: 1, key: 'k', fingerprint: 'f', buildStamp: '1', stampParsed: null, edition: 2, bytes: 1, installedAt: 1, hasSnapshot: false };
  assert.ok(S.validateVersionRecord(v).ok); bad(S.validateVersionRecord({ ...v, stampParsed: 'x', bytes: 1.5 }), /stampParsed/);
  const pj = { format: 1, setId: 'nova-md-reader-7m2q', part: 1, total: 3, owns: ['backend/**'] };
  assert.ok(S.validatePartJson(pj).ok); bad(S.validatePartJson({ ...pj, part: 4 }), /part and total/);
  const pr = { format: 1, nickname: 'n', mode: 'dark', accent: '#abc', language: 'en', timeZone: 'UTC', dateFormat: 'iso', clock: '24h', railLabels: true, topBar: false };
  assert.ok(S.validateProfileBasics(pr).ok); bad(S.validateProfileBasics({ ...pr, accent: 'red;}' }), /accent/);
});
test('blueprint', () => {
  const bp = { setId: 'nova-md-reader-7m2q', name: 'Nova', type: 'md reader', parts: [{ n: 1, owns: ['a/**'] }, { n: 2, owns: ['b/**'] }, { n: 3, owns: ['c/**'] }] };
  assert.ok(S.validateBlueprint(bp).ok); bad(S.validateBlueprint({ ...bp, parts: [{ n: 2, owns: ['../x'] }] }), /3 to 6/); bad(S.validateBlueprint({ name: 'x', parts: 5 }), /setId/);
});
test('parseAccent strict', () => {
  assert.equal(S.parseAccent('#0f6cbd'), '#0F6CBD'); assert.equal(S.parseAccent('#fc0'), '#FFCC00');
  for (const x of ['red', '#12345', '#GGGGGG', '#fff;}body{x:y', 'url(x)', '', null, 5, '#1234567']) assert.equal(S.parseAccent(x), null, String(x));
});
