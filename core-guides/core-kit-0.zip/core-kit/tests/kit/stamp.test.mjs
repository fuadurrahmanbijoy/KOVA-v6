import { test } from 'node:test'; import assert from 'node:assert/strict'; import { kit } from './_setup.mjs';
const S = kit('stamp');
test('impossible calendar dates are labels, not rolled over', () => {
  for (const x of ['2026-02-31', '2026-04-31', '2026-02-30 10:00', '20260231', '2025-02-29']) assert.equal(S.parseStamp(x).utc, null, x);
  assert.notEqual(S.parseStamp('2024-02-29').utc, null); assert.notEqual(S.parseStamp('2026-02-28 10:30').utc, null); assert.notEqual(S.parseStamp('20261231T2359').utc, null);
  assert.equal(S.fileStamp(S.parseStamp('2026-02-31')), '2026-02-31');
});
test('equal parsed stamps compare by install time (tieBreak)', () => {
  const a = S.parseStamp('2026-03-01 10:00Z'), b = S.parseStamp('2026-03-01 10:00Z');
  assert.equal(S.compareBuild(a, 200, b, 100), 'newer'); assert.equal(S.compareBuild(a, 100, b, 200), 'older'); assert.equal(S.compareBuild(a, 100, b, 100), 'same');
  assert.equal(S.tieBreak(2, 1), 'newer'); assert.equal(S.tieBreak(1, 2), 'older');
});
test('different parsed stamps still order by time; unparsed fall back to install time', () => {
  assert.equal(S.compareBuild(S.parseStamp('2026-03-02'), 1, S.parseStamp('2026-03-01'), 999), 'newer');
  assert.equal(S.compareBuild(S.parseStamp('beta'), 5, S.parseStamp('2026-03-01'), 9), 'older');
});
