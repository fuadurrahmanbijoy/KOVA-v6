import zipfile, sys, os, stat
d = sys.argv[1]
def z(name, entries, **kw):
    with zipfile.ZipFile(os.path.join(d, name + '.zip'), 'w', zipfile.ZIP_DEFLATED) as f:
        for e in entries:
            if isinstance(e, zipfile.ZipInfo): f.writestr(e, b'x'); continue
            n, data = e if isinstance(e, tuple) else (e, b'hello')
            f.writestr(zipfile.ZipInfo(n, (2020, 1, 1, 0, 0, 0)), data, compress_type=zipfile.ZIP_DEFLATED)
z('ok', ['kova.json', 'ui/index.html', 'ui/a/b.txt', 'dir/'])
z('abs', ['/etc/passwd']); z('dotdot', ['a/../../evil']); z('dotdot2', ['../evil']); z('drive', ['C:/evil.txt']); z('drive2', ['C:evil.txt'])
z('backslash', ['a\\..\\..\\evil']); z('bsabs', ['\\evil']); z('ads', ['file.txt:stream']); z('con', ['ui/CON']); z('con2', ['nul.txt']); z('com1', ['com1']); z('lpt9', ['Lpt9.log'])
z('dot', ['ui/file.']); z('space', ['ui/file ']); z('dir_dot', ['ui./x']); z('dup', ['A.txt', 'a.TXT']); z('dup2', ['x/', 'X'])
zi = zipfile.ZipInfo('link'); zi.create_system = 3; zi.external_attr = (stat.S_IFLNK | 0o777) << 16; z('symlink', [zi])
zi2 = zipfile.ZipInfo('script.sh'); zi2.create_system = 3; zi2.external_attr = (stat.S_IFREG | 0o755) << 16; z('exec_ok', [zi2])
z('many', [f'f{i}' for i in range(30)]); z('bomb', [('zeros.bin', b'\0' * (12 * 1024 * 1024))]); z('bigfile', [('big.bin', os.urandom(200000))]); z('twobig', [('a', os.urandom(150000)), ('b', os.urandom(150000))])
z('ratio_small', [('tiny.bin', b'\0' * 20000)])
