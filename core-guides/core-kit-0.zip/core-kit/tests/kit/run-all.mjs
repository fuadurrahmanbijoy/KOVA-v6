// Builds src/kit into a temp dir (TypeScript transpile, no type resolution needed), installs stubs for electron/esbuild when the real
// packages are missing, then runs every *.test.mjs with node:test.   node tests/kit/run-all.mjs | tail -n 20
import { spawnSync, execSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, mkdirSync, readdirSync, readFileSync, writeFileSync, existsSync, cpSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const here = dirname(fileURLToPath(import.meta.url)), root = join(here, '..', '..');
const req = createRequire(join(root, 'package.json'));
function loadTs() {
  try { return req('typescript'); } catch {}
  try { return req(join(execSync('npm root -g', { encoding: 'utf8' }).trim(), 'typescript')); } catch {}
  console.error('typescript not found: run npm install'); process.exit(2);
}
const ts = loadTs(), out = mkdtempSync(join(tmpdir(), 'kit-build-'));
mkdirSync(join(out, 'kit'), { recursive: true });
for (const f of readdirSync(join(root, 'src', 'kit')).filter((x) => x.endsWith('.ts'))) {
  const r = ts.transpileModule(readFileSync(join(root, 'src', 'kit', f), 'utf8'), { fileName: f, compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true } });
  writeFileSync(join(out, 'kit', f.replace(/\.ts$/, '.js')), r.outputText);
}
// node_modules for the build: real packages when installed, stubs otherwise.
const nm = join(out, 'node_modules'); mkdirSync(nm, { recursive: true });
const real = (n) => { try { return dirname(req.resolve(n + '/package.json')); } catch { return null; } };
for (const n of ['yauzl', 'yazl', 'npm', '@fluentui/svg-icons', 'pend', 'buffer-crc32', 'fd-slicer']) { const d = real(n); if (d) { mkdirSync(join(nm, ...n.split('/').slice(0, -1)), { recursive: true }); cpSync(d, join(nm, n), { recursive: true }); } }
const fl = join(nm, '@fluentui', 'svg-icons'); if (!existsSync(fl)) { mkdirSync(join(fl, 'icons'), { recursive: true }); writeFileSync(join(fl, 'package.json'), '{"name":"@fluentui/svg-icons","version":"0.0.0-stub"}'); for (const [f, t] of [['home_24_regular.svg', 'home'], ['wifi_1_24_regular.svg', 'wifi1'], ['arrow_left_24_regular.svg', 'left']]) writeFileSync(join(fl, 'icons', f), '<svg>' + t + '</svg>'); }
cpSync(join(here, 'stubs', 'electron'), join(nm, 'electron'), { recursive: true });   // tests never run Electron
if (!real('esbuild')) cpSync(join(here, 'stubs', 'esbuild'), join(nm, 'esbuild'), { recursive: true });   // transformSync via TypeScript, same ESM output shape
writeFileSync(join(out, 'ts-path.json'), JSON.stringify({ ts: req.resolve('typescript') }));
if (process.env.KEEP_BUILD) { console.log(out); process.exit(0); }
const files = readdirSync(here).filter((f) => f.endsWith('.test.mjs')).sort().map((f) => join(here, f));
const r = spawnSync(process.execPath, ['--test', '--test-reporter=tap', ...files], { env: { ...process.env, KIT_BUILD: out, KIT_ROOT: root }, encoding: 'utf8', maxBuffer: 1 << 26 });
const txt = (r.stdout || '') + (r.stderr || '');
const fails = txt.split('\n').filter((l) => /^\s*not ok/.test(l) && !/# SKIP|# skip/i.test(l));
const num = (k) => +((txt.match(new RegExp('^# ' + k + ' (\\d+)', 'm')) || [])[1] || 0);
fails.slice(0, 12).forEach((l) => console.log(l.trim()));
if (fails.length) console.log(txt.split('\n').filter((l) => /^\s*(error|message|expected|actual|at )/i.test(l)).slice(0, 10).join('\n'));
console.log(`passed ${num('pass')} / ${num('tests')}  (skipped ${num('skipped')}, failed ${num('fail')})`);
rmSync(out, { recursive: true, force: true });
process.exit(r.status === 0 ? 0 : 1);
