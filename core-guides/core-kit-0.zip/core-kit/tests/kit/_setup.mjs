import { createRequire } from 'node:module';
import { join } from 'node:path';
export const BUILD = process.env.KIT_BUILD, ROOT = process.env.KIT_ROOT;
const r = createRequire(join(BUILD, 'kit', 'x.js'));
export const kit = (n) => r('./' + n + '.js');
export const stub = (n) => r(n);
export const has = (n) => { try { r.resolve(n); return true; } catch { return false; } };
