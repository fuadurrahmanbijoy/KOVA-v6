// Minimal fake of the Electron main-process API, enough for rpc.ts / window.ts unit tests. Never used outside tests.
const { EventEmitter } = require('events');
const handlers = new Map(), log = { cursor: 0, permReq: null, permCheck: null, windows: [], views: [] };
class WC extends EventEmitter { constructor(o) { super(); this.opts = o || {}; this.sent = []; this.openHandler = null; this.url = ''; this.focused = false; }
  setWindowOpenHandler(f) { this.openHandler = f; } send(...a) { this.sent.push(a); } getURL() { return this.url; } isDestroyed() { return false; }
  loadFile(f) { this.url = 'file://' + f; } focus() { this.focused = true; this.emit('focus'); } isFocused() { return this.focused; } }
class View { constructor(o) { this.webContents = new WC(o.webPreferences); this.bounds = null; log.views.push(this); } setBackgroundColor() {} setBounds(b) { this.bounds = b; } }
class Win extends EventEmitter { constructor(o) { super(); this.opts = o; this.webContents = new WC(o.webPreferences); this.children = [];
    this.contentView = { addChildView: (v) => this.children.push(v), removeChildView: (v) => { this.children = this.children.filter((c) => c !== v); } }; log.windows.push(this); }
  getContentSize() { return [1000, 700]; } getBounds() { return { x: 0, y: 0, width: 1000, height: 700 }; } isVisible() { return true; } isMinimized() { return false; } isMaximized() { return false; }
  isDestroyed() { return false; } isFocused() { return false; } loadFile(f) { this.webContents.loadFile(f); } show() {} minimize() {} maximize() {} unmaximize() {} close() {} }
Win.getAllWindows = () => log.windows;
module.exports = { __log: log, __handlers: handlers, BrowserWindow: Win, WebContentsView: View,
  ipcMain: { handle: (n, f) => handlers.set(n, f), removeHandler: (n) => handlers.delete(n) },
  screen: { getCursorScreenPoint: () => { log.cursor++; return { x: 500, y: 300 }; } },
  session: { defaultSession: { setPermissionRequestHandler: (f) => { log.permReq = f; }, setPermissionCheckHandler: (f) => { log.permCheck = f; } } },
  app: {}, dialog: {} };
