// Test stand-in for esbuild.transformSync (esbuild is not installable offline). Same contract: ESM output with double quotes, external map, errors[0].location.line.
const fs = require('fs'), path = require('path');
const ts = require(JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'ts-path.json'), 'utf8')).ts);
exports.transformSync = (code, o) => {
  const r = ts.transpileModule(code, { fileName: o.sourcefile || 'x.ts', reportDiagnostics: true, compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, sourceMap: true, inlineSources: true } });
  const d = (r.diagnostics || []).find((x) => x.category === 1);
  if (d) { const pos = d.file && d.file.getLineAndCharacterOfPosition(d.start); const e = new Error('Transform failed'); e.errors = [{ text: String(d.messageText.messageText || d.messageText), location: { line: pos ? pos.line + 1 : 0 } }]; throw e; }
  return { code: r.outputText.replace(/\/\/# sourceMappingURL=.*$/m, '').trimEnd() + '\n', map: r.sourceMapText };
};
