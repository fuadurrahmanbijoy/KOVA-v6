import { test } from 'node:test'; import assert from 'node:assert/strict'; import * as fs from 'node:fs'; import { tmpdir } from 'node:os'; import { join } from 'node:path'; import { kit } from './_setup.mjs';
const F = kit('fingerprint');
const tree = (stamp, extra = {}) => { const d = fs.mkdtempSync(join(tmpdir(), 'fp-')); fs.mkdirSync(join(d, 'ui')); fs.writeFileSync(join(d, 'ui', 'index.html'), '<p>hi'); fs.writeFileSync(join(d, 'a.b'), 'x'); fs.mkdirSync(join(d, 'a')); fs.writeFileSync(join(d, 'a', 'b'), 'y');
  fs.writeFileSync(join(d, 'kova.json'), JSON.stringify({ name: 'N', type: 't', edition: 2, ...(stamp ? { buildStamp: stamp } : {}), ...extra }, null, stamp === '1' ? 4 : 2)); return d; };
test('same content, different buildStamp (or none, or key order) -> equal', () => {
  const a = F.contentFingerprint(tree('111')), b = F.contentFingerprint(tree('999')), c = F.contentFingerprint(tree(null));
  assert.equal(a, b); assert.equal(a, c);
  const d = tree('5'); fs.writeFileSync(join(d, 'kova.json'), '{"edition":2,"type":"t","buildStamp":"7","name":"N"}'); assert.equal(F.contentFingerprint(d), a);
});
test('real content change -> different', () => { assert.notEqual(F.contentFingerprint(tree('1')), F.contentFingerprint(tree('1', { description: 'x' }))); const d = tree('1'), e = F.contentFingerprint(d); fs.writeFileSync(join(d, 'a.b'), 'z'); assert.notEqual(F.contentFingerprint(d), e); });
test('symlink throws (never followed)', (t) => {
  const d = tree('1'); try { fs.symlinkSync(join(d, 'a.b'), join(d, 'ln')); } catch { return t.skip('symlinks unavailable'); }
  assert.throws(() => F.contentFingerprint(d), /symlink/);
  const e = tree('1'); try { fs.symlinkSync(tmpdir(), join(e, 'dirln')); } catch { return; } assert.throws(() => F.contentFingerprint(e), /symlink/);
});
