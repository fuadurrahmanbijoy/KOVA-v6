import { test } from 'node:test'; import assert from 'node:assert/strict'; import os from 'node:os'; import { kit } from './_setup.mjs';
const R = kit('redact'), red = R.makeRedactor(['ab', 'Zanzibar']), host = os.hostname(), user = os.userInfo().username, home = os.homedir();
const gone = (s, secret) => { const o = red(s); assert.ok(!o.includes(secret), `"${s}" -> "${o}"`); return o; };
test('audit fixtures are all redacted', () => {
  gone('Authorization: Basic dXNlcjpwYXNz', 'dXNlcjpwYXNz'); gone('cookie: sid=abc123', 'abc123'); gone('Set-Cookie: sid=abc123; Path=/', 'abc123');
  gone('https://x.test/cb?access_token=eyJhbGciOi.AAAA.BBB&x=1', 'eyJhbGciOi'); assert.ok(red('https://x.test/cb?access_token=zzz&x=1').endsWith('&x=1'));
  gone('ip 192.168.1.20', '192.168.1.20'); if (host.length >= 3) gone('host ' + host, host); gone('Bearer eyJabc.def.ghi', 'eyJabc');
  gone('Authorization: Bearer abc.def', 'abc.def'); gone('Authorization: Digest username="x", nonce="n"', 'nonce'); gone('Authorization: token ghp_x1', 'ghp_x1');
});
test('query params, JWT, IPv6', () => {
  for (const k of ['token', 'key', 'secret', 'sig', 'signature', 'id_token', 'code', 'password', 'auth']) gone(`https://a.test/p?z=1&${k}=SECRETVAL&y=2`, 'SECRETVAL');
  assert.ok(red('see https://a.test/p?page=2&q=hello').includes('q=hello'));
  gone('eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.sig_part-1', 'eyJzdWIi');
  for (const ip of ['2001:db8:85a3:0:0:8a2e:370:7334', 'fe80::1', '::1', '2001:db8::ff00:42:8329']) gone('addr ' + ip + ' end', ip);
  assert.equal(red('at 12:30:45 done'), 'at 12:30:45 done'); assert.equal(red('std::string x'), 'std::string x'); assert.equal(red('1.2.3'), '1.2.3');
});
test('home path in forward-slash, JSON-escaped and UNC forms', () => {
  for (const h of [home, home.replace(/\\/g, '/'), home.replace(/\\/g, '\\\\'), '\\\\?\\' + home]) { const o = gone('file ' + h + '/x.txt', h); assert.ok(o.includes('<HOME>')); }
  gone('\\\\server\\C$\\Users\\' + user + '\\docs', user);
});
test('username uses Unicode-aware boundaries; short profile values ignored', () => {
  if (user.length >= 3) { gone('user=' + user + ';', user); assert.equal(red('x' + user + 'y'), 'x' + user + 'y'); assert.equal(red('é' + user), 'é' + user); assert.equal(red(user + 'é'), user + 'é'); assert.equal(red('_' + user), '_' + user); }
  assert.equal(red('ab and cd'), 'ab and cd'); assert.ok(red('trip to zanzibar!').includes('<PROFILE>')); assert.equal(red('Zanzibarish'), 'Zanzibarish');
});
test('summarizeMessage has no body; MessageLog is a 300 ring', () => {
  const env = { v: 2, id: 'i', from: 'a', to: 'b', kind: 'event', name: 'n', body: { secret: 'hunter2hunter2' }, time: 5, replyTo: 'r' };
  const s = R.summarizeMessage(env); assert.deepEqual(Object.keys(s).sort(), ['bytes', 'from', 'kind', 'name', 'replyTo', 'time', 'to']); assert.ok(s.bytes > 10); assert.ok(!JSON.stringify(s).includes('hunter2'));
  const log = new R.MessageLog(); for (let i = 0; i < 350; i++) log.add({ ...env, time: i }); assert.equal(log.list().length, 300); assert.equal(log.list()[0].time, 50); assert.ok(log.list().every((m) => !('body' in m)));
  const kb = new R.MessageLog({ keepBody: true, redact: red }); kb.add({ ...env, body: { t: 'Bearer eyJabc.def.ghi', pad: 'x'.repeat(5000) } });
  const b = kb.list()[0].body; assert.ok(b.length <= 2048); assert.ok(!b.includes('eyJabc')); assert.ok(/Bearer <(JWT|REDACTED)>/.test(b));
});
