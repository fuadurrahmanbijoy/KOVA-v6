import { test } from 'node:test'; import assert from 'node:assert/strict'; import * as fs from 'node:fs'; import { tmpdir } from 'node:os'; import { join } from 'node:path'; import { kit } from './_setup.mjs';
const A = kit('atomic'), d = () => fs.mkdtempSync(join(tmpdir(), 'at-'));
const flaky = (fails, code = 'EPERM') => { let n = 0, calls = []; A.io.fs = { ...fs, renameSync: (a, b) => { calls.push(b); if (n++ < fails) { const e = new Error(code); e.code = code; throw e; } return fs.renameSync(a, b); } }; A.io.sleep = async () => {}; return calls; };
test.afterEach(() => { A.io.fs = fs; });
test('rename retried on EPERM/EBUSY/EACCES, then succeeds', async () => {
  for (const code of ['EPERM', 'EBUSY', 'EACCES']) { const p = join(d(), 'a.json'), calls = flaky(3, code); await A.writeJsonAtomic(p, { a: 1 }); assert.equal(calls.length, 4); assert.deepEqual(JSON.parse(fs.readFileSync(p, 'utf8')), { a: 1 }); }
});
test('gives up after 8 retries, leaves no tmp file', async () => {
  const dir = d(), calls = flaky(99); await assert.rejects(A.writeJsonAtomic(join(dir, 'a.json'), 1), /EPERM/); assert.equal(calls.length, 9); assert.deepEqual(fs.readdirSync(dir), []);
});
test('other errors are not retried; sync variants retry too', async () => {
  const calls = flaky(99, 'ENOENT'); await assert.rejects(A.writeJsonAtomic(join(d(), 'a.json'), 1), /ENOENT/); assert.equal(calls.length, 1);
  const c2 = flaky(2); const p = join(d(), 's.json'); A.writeJsonAtomicSync(p, [1]); assert.equal(c2.length, 3); assert.ok(fs.existsSync(p));
});
test('tmp names are unique; cleanupTmp removes leftovers', async () => {
  const dir = d(), seen = new Set(); A.io.fs = { ...fs, renameSync: (a, b) => { seen.add(a); return fs.renameSync(a, b); } };
  await A.writeJsonAtomic(join(dir, 'x.json'), 1); await A.writeJsonAtomic(join(dir, 'y.json'), 2); await A.writeJsonAtomic(join(dir, 'x.json'), 3); assert.equal(seen.size, 3); A.io.fs = fs;
  fs.writeFileSync(join(dir, 'z.json.tmp-123-abcd1234'), 'x'); fs.writeFileSync(join(dir, 'w.json.tmp-9'), 'x'); assert.equal(A.cleanupTmp(dir), 2); assert.deepEqual(fs.readdirSync(dir).sort(), ['x.json', 'y.json']);
});
test('commitDir retries and never replaces an existing target', async () => {
  const dir = d(), s = join(dir, 's'), f = join(dir, 'out', 'f'); fs.mkdirSync(s); fs.writeFileSync(join(s, 'k'), '1');
  const calls = flaky(2, 'EBUSY'); await A.commitDir(s, f); assert.equal(calls.length, 3); assert.ok(fs.existsSync(join(f, 'k')));
  fs.mkdirSync(join(dir, 's2')); await assert.rejects(A.commitDir(join(dir, 's2'), f), /target exists/); assert.throws(() => A.commitDirSync(join(dir, 's2'), f), /target exists/);
});
