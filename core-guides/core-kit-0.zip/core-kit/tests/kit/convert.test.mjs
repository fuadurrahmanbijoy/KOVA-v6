import { test } from 'node:test'; import assert from 'node:assert/strict'; import * as fs from 'node:fs'; import { tmpdir } from 'node:os'; import { join } from 'node:path'; import { spawnSync } from 'node:child_process'; import { pathToFileURL } from 'node:url'; import { kit } from './_setup.mjs';
const C = kit('convert');
const put = (r, p, t) => { fs.mkdirSync(join(r, p, '..'), { recursive: true }); fs.writeFileSync(join(r, p), t); };
function sample() {
  const r = fs.mkdtempSync(join(tmpdir(), 'cv-'));
  put(r, 'kova.json', '{}');
  put(r, 'backend/main.ts', "import { run } from './engine';\nimport { also } from './engine/index';\nexport const m: number = run() + also();\nexport async function lazy() { return (await import('./engine/util.ts')).u; }\nexport * from './engine/util.js';\n");
  put(r, 'backend/engine/index.ts', "import { u } from './util';\nimport { u as u2 } from './util.js';\nimport { u as u3 } from './util.ts';\nexport const run = (): number => u + u2 + u3;\nexport const also = (): number => 1;\n");
  put(r, 'backend/engine/util.ts', 'export const u: number = 1;\n');
  put(r, 'backend/side.mts', "import './engine/util';\nexport const s = 1;\n");
  put(r, 'ui/index.html', '<script type="module" src="./app.ts"></script><link href="x.mts"><script src="https://x.test/a.ts"></script>');
  put(r, 'ui/app.ts', "import { u } from '../backend/engine/util';\nexport const a: string = String(u);\n");
  put(r, 'vendor/lib.ts', 'import "./other";\n'); put(r, 'vendor-npm/node_modules/p/x.ts', 'export {}');
  return r;
}
test('converted tree loads in Node with module auto-detection OFF', () => {
  const r = sample(), errs = C.convertTree(r); assert.deepEqual(errs, []);
  assert.equal(fs.readFileSync(join(r, 'package.json'), 'utf8').trim(), '{"type":"module"}');
  for (const f of ['backend/main.js', 'backend/engine/index.js', 'backend/engine/util.js', 'backend/side.mjs', 'ui/app.js']) assert.ok(fs.existsSync(join(r, f)), f);
  assert.ok(!fs.existsSync(join(r, 'backend/main.ts')));
  const idx = fs.readFileSync(join(r, 'backend/engine/index.js'), 'utf8'); assert.ok(/from ["']\.\/util\.js["']/.test(idx) && !/["']\.\/util["']/.test(idx) && !idx.includes('util.ts'));
  const main = fs.readFileSync(join(r, 'backend/main.js'), 'utf8'); assert.ok(/["']\.\/engine\/index\.js["']/.test(main) && /import\(["']\.\/engine\/util\.js["']\)/.test(main) && /from ["']\.\/engine\/util\.js["']/.test(main), main);
  const run = spawnSync(process.execPath, ['--no-experimental-detect-module', '-e', `import(${JSON.stringify(pathToFileURL(join(r, 'backend/main.js')).href)}).then(async (m) => { console.log(m.m, await m.lazy()); })`], { encoding: 'utf8' });
  assert.equal(run.status, 0, run.stderr); assert.equal(run.stdout.trim(), '4 1');
  const side = spawnSync(process.execPath, ['--no-experimental-detect-module', join(r, 'backend/side.mjs')], { encoding: 'utf8' }); assert.equal(side.status, 0, side.stderr);
});
test('html src/href, vendor untouched, package.json kept if present, sourcesContent kept', () => {
  const r = sample(); put(r, 'package.json', '{"name":"mine"}'); C.convertTree(r);
  const h = fs.readFileSync(join(r, 'ui/index.html'), 'utf8'); assert.ok(h.includes('src="./app.js"') && h.includes('href="x.mjs"'), h);
  assert.equal(fs.readFileSync(join(r, 'package.json'), 'utf8'), '{"name":"mine"}');
  assert.ok(fs.existsSync(join(r, 'vendor/lib.ts')) && fs.existsSync(join(r, 'vendor-npm/node_modules/p/x.ts')));
  const map = JSON.parse(fs.readFileSync(join(r, 'backend/main.js.map'), 'utf8')); assert.ok(map.sourcesContent && map.sourcesContent[0].includes('run()'));
  assert.ok(!fs.existsSync(join(r, 'vendor/package.json')) && !fs.existsSync(join(r, 'vendor-npm/package.json')));
});
test('mapSpecifier edge cases', () => {
  const f = new Set(['a/b.ts', 'a/c/index.ts', 'a/d.css', 'a/e.mts', 'a/main.ts']);
  const m = (s) => C.mapSpecifier(s, 'a/main.ts', f);
  assert.equal(m('./b'), './b.js'); assert.equal(m('./c'), './c/index.js'); assert.equal(m('./c/'), './c/index.js'); assert.equal(m('./d.css'), './d.css'); assert.equal(m('./e'), './e.mjs');
  assert.equal(m('./b.js'), './b.js'); assert.equal(m('./b.ts'), './b.js'); assert.equal(m('./x.mts'), './x.mjs'); assert.equal(m('./nothing'), './nothing'); assert.equal(m('node:fs'), 'node:fs'); assert.equal(m('pkg/b'), 'pkg/b');
});
test('errors still map to a file and line (KV-IN-007)', () => {
  const r = fs.mkdtempSync(join(tmpdir(), 'cv-')); put(r, 'backend/ok.ts', 'export const a = 1;\n'); put(r, 'backend/bad.ts', 'export const x = 1;\nexport const = ;\n');
  const e = C.convertTree(r); assert.equal(e.length, 1); assert.equal(e[0].file, 'backend/bad.ts'); assert.equal(e[0].line, 2); assert.ok(e[0].message);
  assert.ok(!fs.existsSync(join(r, 'package.json')), 'no package.json written when conversion failed');
});
