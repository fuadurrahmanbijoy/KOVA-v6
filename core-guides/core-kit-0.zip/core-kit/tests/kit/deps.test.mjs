import { test } from 'node:test'; import assert from 'node:assert/strict'; import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs'; import { tmpdir } from 'node:os'; import { join } from 'node:path'; import { kit } from './_setup.mjs';
const S = kit('schema'), D = kit('deps');
test('hostile specs are refused', () => {
  for (const v of ['--registry=http://evil', 'git+https://x/y.git', 'file:../x', 'npm:evil@1', '-x', 'github:a/b', 'http://x/y.tgz', '', ' 1.0.0', '1.0.0 --foo', '^1.0.0\n--x']) assert.equal(S.validRange(v), false, 'range ' + v);
  for (const n of ['--registry=x', '-x', '../evil', 'a/b', 'A', '@scope', '.hidden', 'a b']) assert.equal(S.validPkgName(n), false, 'name ' + n);
  for (const [n, v] of [['left-pad', '^1.3.0'], ['@scope/pkg', '>=1.0.0 <2'], ['x', '1.x'], ['a.b_c', '~2.1.0']]) { assert.ok(S.validPkgName(n)); assert.ok(S.validRange(v)); }
  assert.equal(S.validateDependencies({ '--registry=http://e': '1.0.0', ok: 'git+https://x' }).errors.length, 2);
});
test('installDeps returns invalid-spec before spawning anything', async () => {
  const r = await D.installDeps(tmpdir(), { 'left-pad': 'git+https://x/y.git' });
  assert.equal(r.ok, false); assert.equal(r.reason, 'invalid-spec'); assert.ok(r.errors.length);
  assert.deepEqual(await D.installDeps(tmpdir(), {}), { ok: true, output: '' });
});
test('npm argument vector: scripts off, specs after --, ci with a lockfile', () => {
  const d = mkdtempSync(join(tmpdir(), 'dep-')), a = D.npmArgs(d, { 'left-pad': '^1.3.0', '@s/p': '2.x' });
  for (const f of ['--ignore-scripts', '--no-audit', '--no-fund', '--no-bin-links', '--no-save']) assert.ok(a.includes(f), f);
  const i = a.indexOf('--'); assert.ok(i > 0); assert.deepEqual(a.slice(i + 1), ['left-pad@^1.3.0', '@s/p@2.x']); assert.equal(a[0], 'install');
  mkdirSync(join(d, 'vendor-npm')); writeFileSync(join(d, 'vendor-npm', 'package-lock.json'), '{}');
  const c = D.npmArgs(d, { x: '1' }); assert.equal(c[0], 'ci'); assert.ok(c.includes('--ignore-scripts')); assert.ok(!c.includes('--'));
});
