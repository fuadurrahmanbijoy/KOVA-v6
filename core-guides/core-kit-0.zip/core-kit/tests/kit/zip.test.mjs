import { test } from 'node:test'; import assert from 'node:assert/strict'; import * as fs from 'node:fs'; import { tmpdir } from 'node:os'; import { join } from 'node:path'; import { spawnSync } from 'node:child_process'; import { fileURLToPath } from 'node:url'; import { kit, has } from './_setup.mjs'; import { readCentral } from './zipdir.mjs';
const Z = kit('zip'), dir = fs.mkdtempSync(join(tmpdir(), 'zt-')), here = fileURLToPath(new URL('.', import.meta.url));
const py = spawnSync('python3', [join(here, 'zipmake.py'), dir], { encoding: 'utf8' }); assert.equal(py.status, 0, py.stderr);
const chk = (n, lim) => Z.checkEntries(readCentral(join(dir, n + '.zip')), lim);
const rejects = (n, code, why, lim) => { try { chk(n, lim); assert.fail(n + ' should be rejected'); } catch (e) { assert.ok(e instanceof Z.ZipError, n + ': ' + e.message); assert.equal(e.code, code, n + ': ' + e.message); assert.match(e.reason, why, n); } };
test('normal archive is accepted and total is reported up front', () => { assert.equal(chk('ok'), 15); assert.ok(chk('exec_ok') >= 0); });
test('unsafe names -> KV-IN-001', () => {
  rejects('abs', 'KV-IN-001', /absolute/); rejects('dotdot', 'KV-IN-001', /traversal/); rejects('dotdot2', 'KV-IN-001', /traversal/); rejects('drive', 'KV-IN-001', /absolute/); rejects('drive2', 'KV-IN-001', /absolute/);
  rejects('backslash', 'KV-IN-001', /traversal/); rejects('bsabs', 'KV-IN-001', /absolute/); rejects('ads', 'KV-IN-001', /colon/);
  for (const n of ['con', 'con2', 'com1', 'lpt9']) rejects(n, 'KV-IN-001', /reserved/);
  for (const n of ['dot', 'space', 'dir_dot']) rejects(n, 'KV-IN-001', /trailing/);
});
test('duplicates (case-insensitive) and symlinks -> KV-IN-001', () => { rejects('dup', 'KV-IN-001', /duplicate/); rejects('dup2', 'KV-IN-001', /duplicate/); rejects('symlink', 'KV-IN-001', /symlink/); });
test('size limits -> KV-IN-011', () => {
  rejects('many', 'KV-IN-011', /entries/, { maxEntries: 29 }); assert.equal(chk('many', { maxEntries: 30 }), 150);
  rejects('bigfile', 'KV-IN-011', /entry too large/, { maxEntry: 100000 }); rejects('twobig', 'KV-IN-011', /total/, { maxTotal: 250000 }); assert.equal(chk('twobig', { maxTotal: 300000 }), 300000);
  rejects('bomb', 'KV-IN-011', /200:1/); assert.ok(chk('bomb', { maxRatio: 1e9 }) > 0); assert.ok(chk('ratio_small') > 0, 'tiny files under ratioMinBytes are exempt');
  assert.equal(Z.DEFAULT_LIMITS.maxEntries, 20000); assert.equal(Z.DEFAULT_LIMITS.maxTotal, 2 * 1024 ** 3); assert.equal(Z.DEFAULT_LIMITS.maxEntry, 1024 ** 3); assert.equal(Z.DEFAULT_LIMITS.maxRatio, 200);
});
test('badName unit', () => { for (const n of ['a/b.txt', 'dir/', 'ui/index.html', 'a b/c d.txt', 'con-x.txt', 'aux1']) assert.equal(Z.badName(n), null, n); for (const n of ['', '/x', 'a//b', './x', 'a/./b', 'x\0y']) assert.notEqual(Z.badName(n), null, JSON.stringify(n)); });
const live = has('yauzl') && has('yazl');
test('round trip with yauzl/yazl (needs npm install)', { skip: live ? false : 'yauzl/yazl not installed in this environment' }, async () => {
  const src = fs.mkdtempSync(join(tmpdir(), 'zs-')); fs.mkdirSync(join(src, 'ui')); fs.writeFileSync(join(src, 'ui', 'a.txt'), 'AAA'); fs.writeFileSync(join(src, 'kova.json'), '{}'); fs.mkdirSync(join(src, 'node_modules')); fs.writeFileSync(join(src, 'node_modules', 'x'), '1');
  const out = join(tmpdir(), 'rt-' + Date.now() + '.zip'); await Z.createZip(src, out, { exclude: ['node_modules'] });
  assert.deepEqual((await Z.listEntries(out)).map((e) => e.name).sort(), ['kova.json', 'ui/a.txt']); assert.deepEqual(await Z.inspectZip(out), { entries: 2, totalBytes: 5 });
  assert.equal((await Z.readEntry(out, 'ui/a.txt', 100)).toString(), 'AAA'); await assert.rejects(Z.readEntry(out, 'ui/a.txt', 2), /too large/);
  const dest = fs.mkdtempSync(join(tmpdir(), 'zd-')); const r = await Z.safeExtract(out, dest); assert.equal(r.files, 2); assert.equal(fs.readFileSync(join(dest, 'ui', 'a.txt'), 'utf8'), 'AAA');
  await assert.rejects(Z.safeExtract(out, dest), /EEXIST/, 'never overwrites');
  const evil = join(dir, 'dotdot.zip'); await assert.rejects(Z.safeExtract(evil, fs.mkdtempSync(join(tmpdir(), 'zd-'))), (e) => e.code === 'KV-IN-001');
});
