// Tiny central-directory reader so rejection logic can be tested with no zip library installed.
import { readFileSync } from 'node:fs';
export function readCentral(file) {
  const b = readFileSync(file); let e = b.length - 22; while (e >= 0 && b.readUInt32LE(e) !== 0x06054b50) e--; if (e < 0) throw new Error('no EOCD');
  const n = b.readUInt16LE(e + 10); let p = b.readUInt32LE(e + 16); const out = [];
  for (let i = 0; i < n; i++) { if (b.readUInt32LE(p) !== 0x02014b50) throw new Error('bad CD'); const made = b.readUInt16LE(p + 4), csize = b.readUInt32LE(p + 20), size = b.readUInt32LE(p + 24), nl = b.readUInt16LE(p + 28), xl = b.readUInt16LE(p + 30), cl = b.readUInt16LE(p + 32), ext = b.readUInt32LE(p + 38);
    const name = b.toString('utf8', p + 46, p + 46 + nl); out.push({ name, size, csize, isDir: name.endsWith('/'), mode: (made >> 8) === 3 ? (ext >>> 16) & 0xffff : 0 }); p += 46 + nl + xl + cl; }
  return out;
}
