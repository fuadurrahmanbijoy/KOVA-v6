import { test } from 'node:test'; import assert from 'node:assert/strict'; import * as fs from 'node:fs'; import { join } from 'node:path'; import { kit, stub, ROOT } from './_setup.mjs';
test('no markup-string assignment anywhere in src/kit', () => {
  const bad = []; for (const f of fs.readdirSync(join(ROOT, 'src', 'kit'))) { const t = fs.readFileSync(join(ROOT, 'src', 'kit', f), 'utf8'); if (/innerHTML|outerHTML|insertAdjacentHTML|document\.write/.test(t)) bad.push(f); }
  assert.deepEqual(bad, []);
});
test('no OS-font glyphs in assets', () => {
  for (const f of ['base.css', 'overlay.html', 'inject-screen.js']) { const t = fs.readFileSync(join(ROOT, 'assets', f), 'utf8'); assert.ok(!/Segoe (Fluent|MDL2)/.test(t), f + ' uses an icon font'); assert.ok(!/\\E[0-9A-F]{3}|&#xE[0-9A-F]{3};/i.test(t), f + ' uses a private-use glyph'); }
  assert.ok(!/innerHTML/.test(fs.readFileSync(join(ROOT, 'assets', 'overlay.html'), 'utf8')));
});
test('base.css uses --k-accent-text for text uses of the accent', () => {
  const c = fs.readFileSync(join(ROOT, 'assets', 'base.css'), 'utf8'); for (const sel of ['.k-chip.ok{', '.k-tab[aria-selected=true]{', '.k-sel-opt[aria-selected=true]{', ':focus-visible{']) { const i = c.indexOf(sel); assert.ok(i >= 0, sel); assert.ok(c.slice(i, i + 160).includes('--k-accent-text'), sel); }
});
test('inject-screen: a11y attributes and ONE document listener', () => {
  const j = fs.readFileSync(join(ROOT, 'assets', 'inject-screen.js'), 'utf8'); for (const a of ['combobox', 'aria-expanded', 'aria-controls', 'aria-labelledby', 'aria-activedescendant', "'Tab'"]) assert.ok(j.includes(a), a);
  assert.equal((j.match(/document\.addEventListener/g) || []).length, 1); new Function(j.replace(/^\(\(\) => \{/gm, '(() => {')); // parses
});
test('icons: Map index, variant names, placeholder', () => {
  const fl = stub('@fluentui/svg-icons/package.json'); assert.ok(fl); const I = kit('icons');
  assert.equal(I.iconsReady(), true); assert.ok(I.iconUrl('home').startsWith('data:image/svg+xml;base64,'));
  assert.equal(Buffer.from(I.iconUrl('wifi').split(',')[1], 'base64').toString(), '<svg>wifi1</svg>'); assert.equal(Buffer.from(I.iconUrl('back').split(',')[1], 'base64').toString(), '<svg>left</svg>');
  const ph = I.iconUrl('does-not-exist'); assert.ok(Buffer.from(ph.split(',')[1], 'base64').toString().includes('stroke-dasharray')); assert.equal(I.iconUrl('home', true, 20) === ph, true);
});
