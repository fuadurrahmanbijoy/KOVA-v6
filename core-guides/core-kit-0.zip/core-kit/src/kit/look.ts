import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { WebContents } from 'electron';
import { deriveAccent } from './accent';
import { parseAccent } from './schema';
export const DEFAULT_ACCENT = '#0F6CBD';
export interface LookProfile { mode: 'light' | 'dark'; accent: string }
export const varsCss = (p: LookProfile, follows = true) => {
  const mode = follows ? p.mode : 'light', a = deriveAccent(parseAccent(p.accent) ?? DEFAULT_ACCENT, mode);   // anything invalid falls back: no CSS injection through basics.json
  return `:root{--k-accent:${a.accent};--k-accent-hover:${a.hover};--k-accent-pressed:${a.pressed};--k-accent-tint:${a.tint};--k-on-accent:${a.onAccent};--k-accent-text:${a.text}}`;
};
/** Injects base.css, accent variables, data-mode and the data-icon filler into a screen. Returns apply(): call it when the profile changes. */
export function attachLook(wc: WebContents, get: () => LookProfile, follows: () => boolean, assets: string) {
  const base = readFileSync(join(assets, 'base.css'), 'utf8'), inj = readFileSync(join(assets, 'inject-screen.js'), 'utf8');
  let key: string | undefined;
  const apply = async () => {
    if (wc.isDestroyed()) return;
    const p = get(), f = follows();
    try {
      if (key) await wc.removeInsertedCSS(key).catch(() => {});
      key = await wc.insertCSS(varsCss(p, f));
      await wc.executeJavaScript(`document.documentElement.dataset.mode=${JSON.stringify(f ? p.mode : 'light')}`);
    } catch {}
  };
  wc.on('dom-ready', async () => { key = undefined; try { await wc.insertCSS(base); await apply(); await wc.executeJavaScript(inj); } catch {} });
  return apply;
}
export const setShape = (wc: WebContents, s: 'compact' | 'regular' | 'large') => { if (!wc.isDestroyed()) wc.executeJavaScript(`document.documentElement.dataset.shape=${JSON.stringify(s)}`).catch(() => {}); };
