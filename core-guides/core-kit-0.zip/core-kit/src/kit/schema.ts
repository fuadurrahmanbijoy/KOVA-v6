// Persisted-data contract (rev 4). Foundation, Installer, Runner and Seal all read and write these shapes through these validators.
export type Result = { ok: boolean; errors: string[] };
const res = (errors: string[]): Result => ({ ok: errors.length === 0, errors });
const isObj = (v: unknown): v is Record<string, any> => typeof v === 'object' && v !== null && !Array.isArray(v);
const isStr = (v: unknown): v is string => typeof v === 'string' && v.length > 0;
const isInt = (v: unknown): v is number => typeof v === 'number' && Number.isInteger(v);
const isStrList = (v: unknown): v is string[] => Array.isArray(v) && v.every((x) => typeof x === 'string');

export const FORMAT = 1;
export const SIZE_HINTS = ['compact', 'regular', 'large'] as const;
export type SizeHint = (typeof SIZE_HINTS)[number];

// ---- npm validators (same rules as scripts/kvlib.py, plus: a range never starts with "-") ----
export const PKG_RE = /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/;
export const RANGE_RE = /^[0-9xX^~<>=| .-]+$/;
export const validPkgName = (n: unknown): n is string => typeof n === 'string' && n.length <= 214 && PKG_RE.test(n);
export const validRange = (v: unknown): v is string => typeof v === 'string' && v.length <= 64 && v.trim() === v && v.length > 0 && !v.startsWith('-') && RANGE_RE.test(v) && /[0-9xX]/.test(v);
export function validateDependencies(d: unknown): Result {
  if (!isObj(d)) return res(['dependencies must be an object']);
  const e: string[] = [];
  for (const [n, v] of Object.entries(d)) {
    if (!validPkgName(n)) e.push(`dependency name not allowed: ${n}`);
    if (!validRange(v)) e.push(`dependency ${n}: version must be a plain semver range`);
  }
  return res(e);
}
/** Strict #RRGGBB; #RGB is expanded; anything else gives null. Output is upper-case. */
export function parseAccent(s: unknown): string | null {
  if (typeof s !== 'string') return null;
  const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(s.trim()); if (!m) return null;
  const h = m[1].length === 3 ? m[1].split('').map((c) => c + c).join('') : m[1];
  return '#' + h.toUpperCase();
}

// ---- kova.json (S2.1) ----
export interface KovaJson {
  name: string; type: string; edition: number; id?: string; buildStamp?: string | number; versionLabel?: string; description?: string; icon?: string;
  entry?: string; backend?: string; dependencies?: Record<string, string>; runsInBackground?: boolean; startsWithCore?: boolean; followsCoreTheme?: boolean;
  sizeHint?: SizeHint; needs?: string[]; opens?: string[]; announces?: string[]; answers?: string[]; worksBetterWith?: string[];
  set?: { setId: string; part: number; total: number; wiring?: unknown };
}
export const OPENS_RE = /^(file:[a-z0-9]+|link:(http|https|magnet))$/;
const badPath = (p: string) => p.startsWith('/') || /^[a-zA-Z]:/.test(p) || p.includes('\\') || p.split('/').some((s) => s === '..' || s === '');
export function validateKovaJson(k: unknown): Result {
  if (!isObj(k)) return res(['kova.json must be an object']);
  const e: string[] = [];
  for (const f of ['name', 'type']) if (!isStr(k[f])) e.push(`missing or empty ${f}`);
  if (!isInt(k.edition) || k.edition < 1) e.push('edition must be an integer >= 1');
  for (const f of ['entry', 'backend']) if (f in k && (typeof k[f] !== 'string' || badPath(k[f]))) e.push(`${f} must be a relative path inside the folder`);
  if ('dependencies' in k) e.push(...validateDependencies(k.dependencies).errors);
  if ('opens' in k && !(isStrList(k.opens) && k.opens.every((x: string) => OPENS_RE.test(x)))) e.push('opens entries must be file:<ext> or link:http|https|magnet');
  if ('sizeHint' in k && !(SIZE_HINTS as readonly string[]).includes(k.sizeHint)) e.push('sizeHint must be compact|regular|large');
  for (const f of ['needs', 'announces', 'answers', 'worksBetterWith']) if (f in k && !isStrList(k[f])) e.push(`${f} must be a list of strings`);
  for (const f of ['runsInBackground', 'startsWithCore', 'followsCoreTheme']) if (f in k && typeof k[f] !== 'boolean') e.push(`${f} must be true or false`);
  if ('set' in k && !(isObj(k.set) && isStr(k.set.setId) && isInt(k.set.part) && isInt(k.set.total) && k.set.part >= 1 && k.set.part <= k.set.total)) e.push('set needs setId, part and total (1 <= part <= total)');
  return res(e);
}
/** Single source of defaults (S2.1). hasBackend = a backend file was found (auto-detect or declared). */
export function withDefaults(k: KovaJson, hasBackend = k.backend !== undefined) {
  return {
    ...k, entry: k.entry ?? 'ui/index.html', backendAutoDetect: k.backend === undefined, runsInBackground: k.runsInBackground ?? hasBackend,
    startsWithCore: k.startsWithCore ?? false, followsCoreTheme: k.followsCoreTheme ?? true, sizeHint: (k.sizeHint ?? 'regular') as SizeHint,
    icon: k.icon ?? 'apps', dependencies: k.dependencies ?? {}, needs: k.needs ?? [], opens: k.opens ?? [], announces: k.announces ?? [], answers: k.answers ?? [], worksBetterWith: k.worksBetterWith ?? [],
  };
}

// ---- persisted records (every one carries `format`) ----
export interface LibraryIndex { format: number; apps: string[]; defaults: Record<string, string>; sets: Record<string, { name: string; total: number; parts: number[] }>; }
export interface AppRecord { format: number; id: string; name: string; type: string; icon: string; active: string; versions: string[]; enabled: boolean; autoStart: boolean; installedAt: number }
export interface VersionRecord { format: number; key: string; fingerprint: string; buildStamp: string; stampParsed: number | null; versionLabel?: string; edition: number; bytes: number; installedAt: number; hasSnapshot: boolean }
export interface Marker { format: number; next: string | null; previous: string | null; lastGood: string | null; pendingFirstStart: boolean; failStreak: number }
export interface PartJson { format: number; setId: string; part: number; total: number; name?: string; owns: string[]; files?: string[] }
export interface Blueprint { format?: number; setId?: string; id?: string; name: string; type?: string; parts: number | { n: number; owns: string[]; exports?: { file: string }[]; messages?: unknown[] }[]; messages?: unknown[] }
export interface ProfileBasics { format: number; nickname: string; mode: 'light' | 'dark'; accent: string; language: string; timeZone: string; dateFormat: string; clock: '12h' | '24h'; railLabels: boolean; topBar: boolean }

const fmt = (o: Record<string, any>, e: string[]) => { if (!isInt(o.format) || o.format < 1) e.push('format must be an integer >= 1'); };
export const emptyIndex = (): LibraryIndex => ({ format: FORMAT, apps: [], defaults: {}, sets: {} });
export const emptyMarker = (): Marker => ({ format: FORMAT, next: null, previous: null, lastGood: null, pendingFirstStart: false, failStreak: 0 });
export function validateLibraryIndex(v: unknown): Result {
  if (!isObj(v)) return res(['index must be an object']); const e: string[] = []; fmt(v, e);
  if (!isStrList(v.apps)) e.push('apps must be a list of ids');
  if (!isObj(v.defaults) || !Object.values(v.defaults).every((x) => typeof x === 'string')) e.push('defaults must map kind to app id');
  if (!isObj(v.sets) || !Object.values(v.sets).every((s) => isObj(s) && isStr(s.name) && isInt(s.total) && Array.isArray(s.parts) && s.parts.every(isInt))) e.push('sets must map setId to {name,total,parts}');
  return res(e);
}
export function validateAppRecord(v: unknown): Result {
  if (!isObj(v)) return res(['app record must be an object']); const e: string[] = []; fmt(v, e);
  for (const f of ['id', 'name', 'type', 'icon', 'active']) if (!isStr(v[f])) e.push(`missing ${f}`);
  if (!isStrList(v.versions)) e.push('versions must be a list of keys'); else if (isStr(v.active) && !v.versions.includes(v.active)) e.push('active must be one of versions');
  for (const f of ['enabled', 'autoStart']) if (typeof v[f] !== 'boolean') e.push(`${f} must be true or false`);
  if (!isInt(v.installedAt)) e.push('installedAt must be an integer');
  return res(e);
}
export function validateVersionRecord(v: unknown): Result {
  if (!isObj(v)) return res(['version record must be an object']); const e: string[] = []; fmt(v, e);
  for (const f of ['key', 'fingerprint', 'buildStamp']) if (!isStr(v[f])) e.push(`missing ${f}`);
  if (!(v.stampParsed === null || isInt(v.stampParsed))) e.push('stampParsed must be an integer or null');
  for (const f of ['edition', 'bytes', 'installedAt']) if (!isInt(v[f])) e.push(`${f} must be an integer`);
  if (typeof v.hasSnapshot !== 'boolean') e.push('hasSnapshot must be true or false');
  return res(e);
}
export function validateMarker(v: unknown): Result {
  if (!isObj(v)) return res(['marker must be an object']); const e: string[] = []; fmt(v, e);
  for (const f of ['next', 'previous', 'lastGood']) if (!(v[f] === null || isStr(v[f]))) e.push(`${f} must be a string or null`);
  if (typeof v.pendingFirstStart !== 'boolean') e.push('pendingFirstStart must be true or false');
  if (!isInt(v.failStreak) || v.failStreak < 0) e.push('failStreak must be an integer >= 0');
  return res(e);
}
export function validatePartJson(v: unknown): Result {
  if (!isObj(v)) return res(['part.json must be an object']); const e: string[] = []; fmt(v, e);
  if (!isStr(v.setId)) e.push('missing setId');
  if (!isInt(v.part) || !isInt(v.total) || v.part < 1 || v.part > v.total) e.push('part and total must satisfy 1 <= part <= total');
  if (!isStrList(v.owns) || !v.owns.length) e.push('owns must be a non-empty list of globs');
  return res(e);
}
export function validateBlueprint(v: unknown): Result {
  if (!isObj(v)) return res(['blueprint must be an object']); const e: string[] = [];
  const sid = v.setId ?? v.id;
  if (!(typeof sid === 'string' && /^[a-z0-9]+(-[a-z0-9]+)*-[a-z0-9]{4}$/.test(sid))) e.push('setId must match ^[a-z0-9]+(-[a-z0-9]+)*-[a-z0-9]{4}$');
  if (!isStr(v.name)) e.push('blueprint missing name');
  if (typeof v.parts === 'number') { if (v.parts !== 5) e.push('core blueprint needs parts == 5'); }
  else if (!Array.isArray(v.parts) || v.parts.length < 3 || v.parts.length > 6) e.push('app blueprint needs 3 to 6 parts');
  else v.parts.forEach((p: any, i: number) => {
    if (!isObj(p) || p.n !== i + 1) e.push(`parts[${i}].n must be ${i + 1}`);
    else if (!isStrList(p.owns) || !p.owns.length || p.owns.some(badPath)) e.push(`part ${i + 1}: owns must be a non-empty list of relative globs`);
  });
  return res(e);
}
export function validateProfileBasics(v: unknown): Result {
  if (!isObj(v)) return res(['profile must be an object']); const e: string[] = []; fmt(v, e);
  if (typeof v.nickname !== 'string') e.push('nickname must be a string');
  if (v.mode !== 'light' && v.mode !== 'dark') e.push('mode must be light or dark');
  if (parseAccent(v.accent) === null) e.push('accent must be #RRGGBB');
  for (const f of ['language', 'timeZone', 'dateFormat']) if (!isStr(v[f])) e.push(`missing ${f}`);
  if (v.clock !== '12h' && v.clock !== '24h') e.push('clock must be 12h or 24h');
  for (const f of ['railLabels', 'topBar']) if (typeof v[f] !== 'boolean') e.push(`${f} must be true or false`);
  return res(e);
}
