import { createHash } from 'node:crypto';
import { lstatSync, readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
/** kova.json is hashed in canonical form: parsed, buildStamp dropped, keys sorted, so the stamp never changes the fingerprint (S2.6). */
export function canonicalKova(buf: Buffer): Buffer {
  try { const o = JSON.parse(buf.toString('utf8')); delete o.buildStamp; const sort = (v: any): any => Array.isArray(v) ? v.map(sort) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, sort(v[k])])) : v; return Buffer.from(JSON.stringify(sort(o))); }
  catch { return buf; }
}
export function contentFingerprint(root: string): string {
  const files: string[] = [];   // posix relative paths
  (function walk(d: string, rel: string) {
    for (const e of readdirSync(d)) {
      const p = join(d, e), r = rel ? rel + '/' + e : e, st = lstatSync(p);
      if (st.isSymbolicLink()) throw new Error('symlink not allowed: ' + r);
      st.isDirectory() ? walk(p, r) : files.push(r);
    }
  })(root, '');
  files.sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
  const h = createHash('sha256');
  for (const f of files) { const raw = readFileSync(join(root, f)); h.update(f + '\0'); h.update(f === 'kova.json' ? canonicalKova(raw) : raw); h.update('\0'); }
  return h.digest('hex');
}
export const shortKey = (fp: string) => fp.slice(0, 12);
