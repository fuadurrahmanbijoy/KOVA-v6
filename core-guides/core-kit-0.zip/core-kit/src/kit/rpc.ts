import { BrowserWindow, ipcMain } from 'electron';
export interface RpcEntry { fn: Function; check?: (args: unknown[]) => void }
export type RpcTable = Record<string, RpcEntry>;
const BANNED = new Set(['__proto__', 'constructor', 'prototype']);
const has = (o: object, k: string) => Object.prototype.hasOwnProperty.call(o, k);
/** Pure dispatch (exported for tests): the path must be an OWN key of the allowlist; nothing is ever walked through prototypes. */
export async function dispatch(table: RpcTable, path: unknown, args: unknown): Promise<unknown> {
  if (typeof path !== 'string' || path.length > 120 || path.split('.').some((s) => BANNED.has(s))) throw new Error('KV-RPC: no such call');
  if (!has(table, path)) throw new Error('KV-RPC: no such call ' + path);
  const e = table[path], a = args === undefined ? [] : args;
  if (!Array.isArray(a)) throw new Error('KV-RPC: arguments must be a list');
  if (typeof e.fn !== 'function') throw new Error('KV-RPC: no such call ' + path);
  e.check?.(a);
  return await e.fn(...a);
}
const bare = (u: string) => u.split('#')[0].split('?')[0];
/** Only the shell page itself may call. Exported for tests. */
export function senderOk(event: { sender: unknown; senderFrame?: { url: string } | null }, allowed: Electron.WebContents): boolean {
  if (event.sender !== allowed) return false;
  const url = event.senderFrame?.url ?? '';
  return url.startsWith('file://') && bare(url) === bare(allowed.getURL());
}
/** Builds allowlist entries: expose('installer', installer, ['apps.list', ...]) gives { 'installer.apps.list': {...} }. Methods are resolved on OWN properties at call time and keep their `this`. */
export function expose(prefix: string, root: any, paths: string[], checks: Record<string, (args: unknown[]) => void> = {}): RpcTable {
  const out: RpcTable = {};
  for (const p of paths) {
    const segs = p.split('.'); if (segs.some((s) => BANNED.has(s))) throw new Error('KV-RPC: bad path ' + p);
    out[prefix + '.' + p] = { check: checks[p], fn: (...a: unknown[]) => {
      let parent: any = root, fn: any = root;
      for (const s of segs) { if (parent === null || typeof parent !== 'object' && typeof parent !== 'function' || !has(parent, s)) throw new Error('KV-RPC: no such call ' + prefix + '.' + p); fn = parent[s]; if (s !== segs[segs.length - 1]) parent = fn; }
      if (typeof fn !== 'function') throw new Error('KV-RPC: no such call ' + prefix + '.' + p);
      return fn.apply(parent, a);
    } };
  }
  return out;
}
/** Renderer pages call main-side services through an explicit allowlist, e.g. 'installer.apps.list'. */
export function registerRpc(table: RpcTable, opts: { allowedSender: () => Electron.WebContents }) {
  ipcMain.removeHandler('kova:call');
  ipcMain.handle('kova:call', async (event, path: string, args: unknown[]) => {
    if (!senderOk(event as any, opts.allowedSender())) throw new Error('KV-RPC: caller not allowed');
    return dispatch(table, path, args);
  });
}
/** Main to renderer events. Any part may call it. */
export const emit = (channel: string, payload?: unknown) => BrowserWindow.getAllWindows().forEach((w) => !w.webContents.isDestroyed() && w.webContents.send('kova:event', channel, payload));
/** Call inside src/frame/preload-shell.ts: exposeKovaCore(contextBridge, ipcRenderer). Works in a sandboxed preload. */
export function exposeKovaCore(cb: Electron.ContextBridge, ipc: Electron.IpcRenderer) {
  const icon = (n: string, f?: boolean, s?: number) => ipc.invoke('kova:icon', n, !!f, s ?? 24);
  cb.exposeInMainWorld('kovaCore', {
    call: (path: string, ...args: unknown[]) => ipc.invoke('kova:call', path, args),
    on: (fn: (channel: string, payload: unknown) => void) => { const h = (_e: unknown, c: string, p: unknown) => fn(c, p); ipc.on('kova:event', h); return () => ipc.removeListener('kova:event', h); },
  });
  cb.exposeInMainWorld('kova', { icon });
}
