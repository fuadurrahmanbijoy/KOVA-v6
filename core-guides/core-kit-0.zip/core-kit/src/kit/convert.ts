import { transformSync } from 'esbuild';
import { existsSync, readdirSync, readFileSync, statSync, writeFileSync, rmSync } from 'node:fs';
import { join, posix } from 'node:path';
const SKIP = new Set(['vendor', 'vendor-npm', 'node_modules']);
const isTs = (e: string) => /\.(ts|mts)$/.test(e) && !e.endsWith('.d.ts');
const outExt = (p: string) => p.replace(/\.m?ts$/, (m) => (m === '.mts' ? '.mjs' : '.js'));
/** Rewrites one relative specifier. `from` = posix path of the importing file, `files` = every pre-conversion file (posix, relative to root). Exported for tests. */
export function mapSpecifier(spec: string, from: string, files: Set<string>): string {
  if (!/^\.\.?(\/|$)/.test(spec)) return spec;
  if (/\.(ts|mts)$/.test(spec)) return outExt(spec);
  const dir = spec.endsWith('/') || spec === '.' || spec === '..';
  const target = posix.normalize(posix.join(posix.dirname(from), spec));
  if (!dir && files.has(target)) return spec;                       // explicit file that really exists (x.css, x.js, x.json)
  const base = target.replace(/\/$/, '');
  const hit = (dir ? [] : [[base + '.ts', '.js'], [base + '.mts', '.mjs']]).concat([[base + '/index.ts', '/index.js'], [base + '/index.mts', '/index.mjs']] as any).find(([f]: string[]) => files.has(f));
  if (!hit) return spec;
  return (dir ? spec.replace(/\/$/, '') : spec) + hit[1];
}
/** esbuild emits double quotes; single quotes are accepted too. Static and dynamic import/export specifiers are rewritten. Line numbers are unchanged. */
export function rewriteSpecifiers(code: string, from: string, files: Set<string>): string {
  const sub = (_m: string, pre: string, q: string, s: string) => `${pre}${q}${mapSpecifier(s, from, files)}${q}`;
  return code.replace(/(\b(?:from|import)\s*)(["'])([^"'\n]+)\2/g, sub).replace(/(\bimport\s*\(\s*)(["'])([^"'\n]+)\2/g, sub);
}
export function convertTree(root: string): { file: string; line?: number; message: string }[] {
  const errs: { file: string; line?: number; message: string }[] = [], files = new Set<string>(), rel = (p: string) => p.slice(root.length + 1).split(/[\\/]/).join('/');
  const scan = (d: string) => { for (const e of readdirSync(d)) { if (SKIP.has(e)) continue; const p = join(d, e); statSync(p).isDirectory() ? scan(p) : files.add(rel(p)); } };
  const walk = (d: string) => { for (const e of readdirSync(d)) { if (SKIP.has(e)) continue; const p = join(d, e); statSync(p).isDirectory() ? walk(p) : isTs(e) ? one(p) : e.endsWith('.html') && html(p); } };
  const one = (p: string) => {
    try {
      const r = transformSync(readFileSync(p, 'utf8'), { loader: 'ts', format: 'esm', target: 'node20', sourcemap: 'external', sourcesContent: true, sourcefile: rel(p) });
      const js = outExt(p), code = rewriteSpecifiers(r.code, rel(p), files);
      writeFileSync(js, code + `\n//# sourceMappingURL=${js.split(/[\\/]/).pop()}.map`); writeFileSync(js + '.map', r.map);
      rmSync(p);
    } catch (e: any) { const x = e.errors?.[0]; errs.push({ file: rel(p), line: x?.location?.line, message: x?.text ?? String(e) }); }
  };
  const html = (p: string) => writeFileSync(p, readFileSync(p, 'utf8').replace(/((?:src|href)=["'][^"']+)\.(m?)ts(["'])/g, '$1.$2js$3'));
  scan(root); walk(root);
  if (!errs.length) { const pj = join(root, 'package.json'); if (!existsSync(pj)) writeFileSync(pj, '{"type":"module"}\n'); }
  return errs;
}
