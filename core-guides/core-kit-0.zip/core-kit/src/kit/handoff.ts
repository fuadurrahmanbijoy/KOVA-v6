import { app } from 'electron';
const EXT = /\.(kvx|kvcore|kvlib|kvpart)$/i;
const filesIn = (argv: string[]) => argv.filter((a) => EXT.test(a));
let cb: (f: string[]) => void = () => {}, pending: string[] = filesIn(process.argv);
export function singleInstance(): boolean {
  if (!app.requestSingleInstanceLock()) { app.quit(); return false; }
  app.on('second-instance', (_e, argv) => { const f = filesIn(argv); if (f.length) cb(f); });
  return true;
}
export function onFiles(fn: (f: string[]) => void) { cb = fn; if (pending.length) { fn(pending); pending = []; } }
