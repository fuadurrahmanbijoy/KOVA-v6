const hex = (h: string) => { const n = parseInt(h.replace('#', ''), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
const toHex = (c: number[]) => '#' + c.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('').toUpperCase();
export const mix = (a: string, b: string, t: number) => { const x = hex(a), y = hex(b); return toHex(x.map((v, i) => v + (y[i] - v) * t)); };
export const lum = (h: string) => { const [r, g, b] = hex(h).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
export const contrast = (a: string, b: string) => { const [p, q] = [lum(a), lum(b)].sort((m, n) => n - m); return (p + 0.05) / (q + 0.05); };
export const textOn = (bg: string) => (contrast(bg, '#FFFFFF') >= contrast(bg, '#242424') ? '#FFFFFF' : '#242424');
export function readableAccent(accent: string, bg: string, mode: 'light' | 'dark') {
  let c = accent; for (let i = 0; i < 40 && contrast(c, bg) < 4.5; i++) c = mix(c, mode === 'light' ? '#000000' : '#FFFFFF', 0.08); return c;
}
export function deriveAccent(accent: string, mode: 'light' | 'dark') {
  const L = mode === 'light';
  return { accent, hover: mix(accent, L ? '#000000' : '#FFFFFF', 0.12), pressed: mix(accent, L ? '#000000' : '#FFFFFF', 0.28),
    tint: mix(accent, L ? '#FFFFFF' : '#1F1F1F', L ? 0.9 : 0.78), onAccent: textOn(accent), text: accentText(accent, mode) };
}
/** Surfaces the accent is drawn on, per mode (same values as base.css). */
export const SURFACES = { light: { page: '#F5F5F5', surface: '#FFFFFF' }, dark: { page: '#292929', surface: '#1F1F1F' } } as const;
/** Accent for TEXT, icons and focus outlines: >= 4.5:1 on page, surface and the accent tint (outline needs only 3:1). */
export function accentText(accent: string, mode: 'light' | 'dark'): string {
  const S = SURFACES[mode], tint = mix(accent, mode === 'light' ? '#FFFFFF' : '#1F1F1F', mode === 'light' ? 0.9 : 0.78);
  return [S.page, S.surface, tint].reduce((c, bg) => readableAccent(c, bg, mode), accent);
}
