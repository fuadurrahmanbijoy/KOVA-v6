export type Kind = 'event' | 'request' | 'reply';
export interface Envelope<T = unknown> { v: number; id: string; from: string; to: string; kind: Kind; name: string; body: T; time: number; replyTo?: string }
export interface Channel { send(m: Envelope): void; onMessage(cb: (m: Envelope) => void): () => void }
let n = 0;
export const newId = () => `${Date.now().toString(36)}-${(n++).toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
export const env = <T>(v: number, from: string, to: string, kind: Kind, name: string, body: T, replyTo?: string): Envelope<T> =>
  ({ v, id: newId(), from, to, kind, name, body, time: Date.now(), replyTo });
/** Core side: the sender's own `from` is never trusted. Overwrite it with the id of the channel the message arrived on. */
export const stamp = <T>(e: Envelope<T>, channelAppId: string): Envelope<T> => ({ ...e, from: channelAppId });
