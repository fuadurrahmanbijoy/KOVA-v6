import { homedir, hostname, userInfo } from 'node:os';
import type { Envelope } from './envelope';
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const B = (s: string) => `(?<![\\p{L}\\p{N}_])${esc(s)}(?![\\p{L}\\p{N}_])`;   // Unicode-aware boundaries instead of \b
const IP4 = '(?:(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)';
const H = '[0-9A-Fa-f]{1,4}';
const IP6 = `(?:\\b(?:${H}:){7}${H}\\b|(?<![\\w:])(?:${H}:){1,6}(?::${H}){1,6}\\b|(?<![\\w:])(?:${H}:){1,7}:(?![\\w:])|(?<![\\w:])::${H}(?::${H}){0,6}(?![\\w:]))`;
export function makeRedactor(profileValues: string[] = []) {
  const user = userInfo().username, home = homedir(), host = hostname();
  const homes = [...new Set([home, home.replace(/\\/g, '/'), home.replace(/\\/g, '\\\\'), '\\\\?\\' + home, '//?/' + home.replace(/\\/g, '/')])].filter((x) => x.length > 2).sort((a, b) => b.length - a.length);
  const rules: [RegExp, string][] = [
    [/\b(Authorization\s*[:=]\s*"?)Digest\s+[^\r\n]+/gi, '$1<REDACTED>'],   // Digest values hold spaces and quotes: take the rest of the line
    [/\b(Authorization\s*[:=]\s*"?)(?:Basic|Bearer|Digest|token)\s+[^\s",;]+/gi, '$1<REDACTED>'],
    [/\b((?:Set-)?Cookie\s*[:=]\s*"?)[^\r\n"]+/gi, '$1<REDACTED>'],
    [/([?&](?:token|key|secret|sig|signature|access_token|id_token|code|password|auth)=)[^&\s#"']*/gi, '$1<REDACTED>'],
    [/\beyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*/g, '<JWT>'],
    [/\bBearer\s+[A-Za-z0-9._~+\/=-]+/gi, 'Bearer <REDACTED>'],
    ...homes.map((h): [RegExp, string] => [new RegExp(esc(h), 'gi'), '<HOME>']),
    [new RegExp(`\\\\\\\\[^\\\\\\s]+\\\\[A-Za-z]\\$\\\\Users\\\\${esc(user)}(?![\\p{L}\\p{N}_])`, 'giu'), '<HOME>'],
    [new RegExp(`\\\\Users\\\\${esc(user)}(?=\\\\|$)`, 'gi'), '\\Users\\<USER>'],
    [new RegExp(`/Users/${esc(user)}(?=/|$)`, 'gi'), '/Users/<USER>'],
    [/(?<![\p{L}\p{N}_])(?:gh[pousr]_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9_-]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,})(?![\p{L}\p{N}_])/gu, '<TOKEN>'],
    [/\b(token|apikey|api_key|secret|password)\s*[=:]\s*\S+/gi, '$1=<REDACTED>'],
    [/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '<EMAIL>'],
    [new RegExp(IP6, 'g'), '<IP>'],
    [new RegExp(`(?<![\\d.])${IP4}(?![\\d.]*\\d)`, 'g'), '<IP>'],
  ];
  if (host.length >= 3) rules.push([new RegExp(B(host), 'giu'), '<HOST>']);
  if (user.length >= 3) rules.push([new RegExp(B(user), 'giu'), '<USER>']);
  for (const v of profileValues.filter((x) => typeof x === 'string' && x.length >= 3)) rules.push([new RegExp(B(v), 'giu'), '<PROFILE>']);
  return (s: string) => rules.reduce((t, [r, to]) => t.replace(r, to), s);
}
export interface MsgSummary { name: string; from: string; to: string; kind: string; bytes: number; time: number; replyTo?: string; body?: string }
/** Metadata only: NO body. */
export function summarizeMessage(e: Envelope): MsgSummary {
  let bytes = 0; try { bytes = Buffer.byteLength(JSON.stringify(e.body ?? null)); } catch {}
  return { name: e.name, from: e.from, to: e.to, kind: e.kind, bytes, time: e.time, replyTo: e.replyTo };
}
/** Ring buffer of message summaries. Bodies are kept only with keepBody (opt-in): redacted and capped at 2 KB. */
export class MessageLog {
  private buf: MsgSummary[] = [];
  constructor(private o: { keepBody?: boolean; redact?: (s: string) => string; capacity?: number } = {}) {}
  add(e: Envelope): MsgSummary {
    const s = summarizeMessage(e);
    if (this.o.keepBody) { let t = ''; try { t = JSON.stringify(e.body ?? null); } catch {} s.body = (this.o.redact ? this.o.redact(t) : makeRedactor()(t)).slice(0, 2048); }
    this.buf.push(s); const cap = this.o.capacity ?? 300; if (this.buf.length > cap) this.buf.splice(0, this.buf.length - cap);
    return s;
  }
  list(n = 300): MsgSummary[] { return this.buf.slice(-n); }
  clear() { this.buf = []; }
}
