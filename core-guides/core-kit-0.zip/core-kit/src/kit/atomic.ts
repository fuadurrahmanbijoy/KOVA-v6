import * as nodefs from 'node:fs';
import { dirname, join } from 'node:path';
import { randomBytes } from 'node:crypto';
/** Swappable for tests. */
export const io = { fs: nodefs as any, sleep: (ms: number) => new Promise<void>((r) => setTimeout(r, ms)) };
const RETRY = new Set(['EPERM', 'EBUSY', 'EACCES']);
const DELAYS = [20, 40, 80, 160, 250, 400, 500, 550]; // 8 retries, about 2 s in total
const tmpName = (p: string) => `${p}.tmp-${process.pid}-${randomBytes(4).toString('hex')}`;
export async function renameRetry(a: string, b: string) {
  for (let i = 0; ; i++) { try { io.fs.renameSync(a, b); return; } catch (e: any) { if (!RETRY.has(e?.code) || i >= DELAYS.length) throw e; await io.sleep(DELAYS[i]); } }
}
export function renameRetrySync(a: string, b: string) {
  for (let i = 0; ; i++) { try { io.fs.renameSync(a, b); return; } catch (e: any) { if (!RETRY.has(e?.code) || i >= DELAYS.length) throw e; const t = Date.now() + DELAYS[i]; while (Date.now() < t); } }
}
function writeTmp(path: string, data: unknown) {
  io.fs.mkdirSync(dirname(path), { recursive: true });
  const tmp = tmpName(path), fd = io.fs.openSync(tmp, 'w');
  try { io.fs.writeSync(fd, JSON.stringify(data, null, 2)); io.fs.fsyncSync(fd); } finally { io.fs.closeSync(fd); }
  return tmp;
}
export async function writeJsonAtomic(path: string, data: unknown): Promise<void> {
  const tmp = writeTmp(path, data); try { await renameRetry(tmp, path); } catch (e) { io.fs.rmSync(tmp, { force: true }); throw e; }
}
export function writeJsonAtomicSync(path: string, data: unknown): void {
  const tmp = writeTmp(path, data); try { renameRetrySync(tmp, path); } catch (e) { io.fs.rmSync(tmp, { force: true }); throw e; }
}
/** Staged folder becomes real by ONE rename (retried). Existing target is never deleted here. */
export async function commitDir(staged: string, final: string): Promise<void> {
  if (io.fs.existsSync(final)) throw new Error('target exists: ' + final);
  io.fs.mkdirSync(dirname(final), { recursive: true }); await renameRetry(staged, final);
}
export function commitDirSync(staged: string, final: string): void {
  if (io.fs.existsSync(final)) throw new Error('target exists: ' + final);
  io.fs.mkdirSync(dirname(final), { recursive: true }); renameRetrySync(staged, final);
}
export const discard = (p: string) => io.fs.rmSync(p, { recursive: true, force: true });
/** Removes leftover `*.tmp-*` files (crashed writes) directly inside dir. Returns how many. */
export function cleanupTmp(dir: string): number {
  let n = 0; try { for (const f of io.fs.readdirSync(dir)) if (/\.tmp-\d+(-[0-9a-f]+)?$/.test(f)) { io.fs.rmSync(join(dir, f), { recursive: true, force: true }); n++; } } catch {}
  return n;
}
