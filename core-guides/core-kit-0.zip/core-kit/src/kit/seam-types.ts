// Seam types · edition 2 (rev 4). Identical in every part. Do not edit (rev 4 = the one authorised change, Batch 2).
import type { WebContentsView } from 'electron';
import type { createFrame } from './window';
import type { LibraryIndex, Marker, ProfileBasics } from './schema';
export type { LibraryIndex, Marker, ProfileBasics };
/** S2.4 states. Runner owns runState; the Installer fills installState only. */
export type AppState = 'staged' | 'installed' | 'starting' | 'ready' | 'running' | 'suspended' | 'stopping' | 'stopped' | 'paused' | 'failed' | 'waiting';
export type InstallState = 'installed' | 'disabled' | 'waiting';
export type KitFrame = ReturnType<typeof createFrame>;   // { win, overlay, addView, removeView, raise, controls: { reveal }, DRAG_REGION_PX }
export type Outcome = 'nothing-changed' | 'rolled-back' | 'paused';
export type Shape = 'compact' | 'regular' | 'large';
export interface KvError { code: string; stage: string; message: string; file?: string; part?: number; detail?: unknown }
export interface Report { ok: boolean; outcome?: Outcome; errors: KvError[]; appId?: string; summary?: string }
export interface BankEntry { headline: string; whatHappened: string; safety: string; steps: string[]; serious: boolean; outcome: Outcome; repairHint: string }
export interface VersionInfo { key: string; buildStamp: string; stampParsed: number | null; versionLabel?: string; edition: number; bytes: number; installedAt: number; active: boolean; hasSnapshot: boolean }
export interface AppInfo {
  id: string; name: string; type: string; icon: string; description?: string; versionLabel?: string;
  entry: string; dir: string /* absolute path of the active version */; backendFile: string | null;
  active: VersionInfo; versions: VersionInfo[]; installState: InstallState /* Installer */; runState: AppState /* Runner, merged in by main.ts */; enabled: boolean; autoStart: boolean;
  runsInBackground: boolean; hasBackend: boolean; followsCoreTheme: boolean; sizeHint: Shape;
  needs: string[]; opens: string[]; announces: string[]; answers: string[]; worksBetterWith: string[]; dataBytes: number; set?: { setId: string; part: number; total: number };
}
export interface Foundation {
  paths: { root: string; staging: string; waiting: string; trash: string; backups: string; guides: string; profile: string; logs: string; app(id: string): string };
  index: { read(): LibraryIndex; /** serialised by a mutex: writers queue, each sees the previous result */ mutate(fn: (draft: LibraryIndex) => void | Promise<void>): Promise<void>; /** @deprecated always throws; use mutate */ write(next: unknown): never };
  /** The ONLY writer of runtime/marker.json. Seal and Foundation both go through it. */
  marker: { read(): Marker; update(fn: (m: Marker) => void): void };
  log: { info(s: string): void; warn(s: string): void; error(s: string): void; tail(n: number): string[] };
  bank: { get(code: string): BankEntry };
  redact(s: string): string;
  fs: { writeJsonAtomic(path: string, data: unknown): Promise<void>; commitDir(staged: string, final: string): Promise<void> };
  safeMode: { isOn(): boolean; recordLaunch(ok: boolean): void; request(): void };
  repair: { forApp(e: { appId: string; errors: KvError[]; evidence?: { log: string[]; messages: unknown[] }; part?: number }): string; forCore(errors: KvError[]): string; friendly(code: string): BankEntry; diagnostics(): string; bundle(e: { appId?: string; errors: KvError[] }): Promise<string> /* path of <id>-repair.zip: note + failing files */; files(e: { appId?: string; errors: KvError[] }): { path: string; reason: string }[] /* the unloadable-files list for the Repair center */ };
  quit: { onRequest(h: () => Promise<'cancel' | 'force' | 'background' | 'ok'>): void; markStartedOk(): void; request(): Promise<void> };
  profile: { read(): ProfileBasics; onChange(cb: (p: ProfileBasics) => void): void };
  space: { check(bytesNeeded: number): { ok: boolean; need: number; have: number } };
  settings: { get<T>(k: string, d?: T): T; set(k: string, v: unknown): void };
}
export interface Installer {
  install(files: string[], ui: { choose(q: string, options: string[]): Promise<number>; /** shown BEFORE any dependency download or app code is stored; false = nothing-changed */ confirm(req: { name: string; id: string; dependencies: Record<string, string>; opens: string[]; needs: string[]; background: boolean }): Promise<boolean> }): Promise<Report[]>;
  /** Registered by main.ts with a callback owned by the Runner (it stops the app). Breaks the Installer<->Runner cycle: the Installer never imports the Runner. */
  onBeforeChange(cb: (id: string, reason: 'remove' | 'switch' | 'update' | 'disable') => Promise<void>): void;
  apps: { list(): AppInfo[]; get(id: string): AppInfo | null; summary(id: string): { background: boolean; internetLikely: boolean; needs: string[]; opens: string[]; editionTested: number }; setAutoStart(id: string, on: boolean): void; setEnabled(id: string, on: boolean): void; remove(id: string, dropData: boolean): Promise<Report> };
  versions: { switch(id: string, key: string): Promise<Report>; remove(id: string, key: string, dropData: boolean): Promise<Report>; snapshots(id: string): { key: string; at: number; bytes: number }[]; restore(id: string, snapKey: string): Promise<Report> };
  waiting: { list(): { setId: string; name: string; have: number[]; total: number }[]; discard(setId: string): Promise<void> };
  defaults: { get(): Record<string, string>; set(kind: string, appId: string | null): void };
  exportSet(setId: string, to: string): Promise<Report>;
}
export interface Runner {
  start(id: string): Promise<Report>;
  stop(id: string, force?: boolean): Promise<void>;
  pause(id: string): void;
  state(id: string): AppState;
  busy(): { id: string; info: string }[];
  stats(): { id: string; memMB: number; cpu: number }[];
  view(id: string): WebContentsView | null;              // the app's screen; Frame sizes and shows it
  setShape(id: string, s: Shape): void;
  setProfile(p: ProfileBasics): void;
  open(what: { file?: string; url?: string; text?: string }): Promise<{ ok: boolean; handledBy?: string }>;
  /** Registered by Frame (frame.chooseOne), used by `open` when several apps can handle something. */
  onChoose(cb: (q: string, options: string[]) => Promise<number>): void;
  report(id: string, userText: string): string;           // repair note for a running or crashed app
  logTail(id: string, n: number): string[];
  onFailure(cb: (r: Report) => void): void;
  onDrop(cb: (files: string[]) => void): void;           // files dropped onto an app screen (Runner intercepts will-navigate to file:// .kv* paths)
  stopAll(graceMs: number): Promise<void>;
}
export interface Frame {
  start(): Promise<void>;
  handleFiles(files: string[]): Promise<void>;
  showFailure(r: Report): void;
  pickFile(o: { filters?: { name: string; extensions: string[] }[]; multi?: boolean }): Promise<string[] | null>;
  openFolder(path: string): void;
  copyText(text: string): void;
  chooseOne(q: string, options: string[]): Promise<number>;  // backing for runner.onChoose
  restart(): Promise<void>;
  toast(text: string): void;
  show(page: string, arg?: unknown): void;               // fixed page ids: 'home' | 'app' (arg = app id) | 'busy' | 'settings'
}
export interface Seal {
  exportLibrary(include: string[], to: string): Promise<Report>;
  importLibrary(file: string): Promise<Report>;
  /** D1 = drop: validate, store under <root>/cores/<id>/, return a Report whose summary is the next-step text ("close Kova and start the new Core yourself"). No switching. */
  installCore(file: string): Promise<Report>;
  listCores(): { id: string; name: string; buildStamp: string; edition: number; runtimeEdition: number; running: boolean }[];
  removeCore(id: string): Promise<Report>;
  runtimeInfo(): { version: string | null };
}
/** Every part ships seam.json: { "part": "...", "entry": "index.ts" }
 *  and deps.json: { "dependencies": { "name": "version" } }.
 *  Factories: foundation.create() · installer.create(f) · runner.create(f,i) · seal.create(f,i,r) · frame.create({foundation,installer,runner,seal,window: KitFrame}) (window is created by main.ts) */
/** Wiring order in main.ts (rev 4): create foundation, installer, runner, seal; build the composite RPC table (apps.list = installer list + runner.state as runState);
 *  runner.onChoose(frame.chooseOne) is registered by main.ts (Frame provides it); installer.onBeforeChange((id, why) => runner.stop(id)) is registered by main.ts (Runner provides it);
 *  both hooks are set BEFORE frame.start(). Parts never import each other. */
