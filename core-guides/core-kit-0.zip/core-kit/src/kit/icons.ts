import { ipcMain } from 'electron';
import { readdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
let dir = '', files: Map<string, string> | null = null, variants = new Map<string, string>();   // file name -> file name; base|size|kind -> first file
const cache = new Map<string, string>();
const ALIAS: Record<string, string> = { back: 'arrow_left', forward: 'arrow_right', speaker: 'speaker_2', wifi: 'wifi_1', dismiss: 'dismiss', next: 'next', previous: 'previous' };
function init() {
  if (files) return;
  files = new Map();
  try {
    dir = join(dirname(require.resolve('@fluentui/svg-icons/package.json')), 'icons');
    for (const f of readdirSync(dir)) { files.set(f, f); const m = /^([a-z0-9_]*?)(?:_\d+)?_(\d+)_(regular|filled)\.svg$/.exec(f); if (m) { const k = `${m[1]}|${m[2]}|${m[3]}`; if (!variants.has(k)) variants.set(k, f); } }
  } catch {}
}
export const iconsReady = () => { init(); return files!.size > 0; };
const PLACEHOLDER = 'data:image/svg+xml;base64,' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="4" fill="none" stroke="#000" stroke-width="2" stroke-dasharray="3 3"/></svg>').toString('base64');
/** Resolve a Fluent icon by plain name. Never throws; unknown names give a dashed placeholder. */
export function iconUrl(name: string, filled = false, size = 24): string {
  init();
  const key = `${name}|${filled}|${size}`, hit = cache.get(key); if (hit) return hit;
  const n = ALIAS[name] ?? name, kind = filled ? 'filled' : 'regular';
  const exact = `${n}_${size}_${kind}.svg`, f = files!.get(exact) ?? variants.get(`${n.replace(/[^a-z0-9_]/gi, '')}|${size}|${kind}`);
  let url = PLACEHOLDER;
  if (f) { try { url = 'data:image/svg+xml;base64,' + readFileSync(join(dir, f)).toString('base64'); } catch {} }
  cache.set(key, url); return url;
}
export function registerIcons() { ipcMain.removeHandler('kova:icon'); ipcMain.handle('kova:icon', (_e, n: string, f?: boolean, s?: number) => iconUrl(String(n), !!f, s === 20 ? 20 : 24)); }
