import { BrowserWindow, WebContentsView, ipcMain, screen, session } from 'electron';
import { join } from 'node:path';
export interface FrameOpts { shellHtml: string; shellPreload: string; bg?: string }
/** Frame must reserve this many px at the top of the rail as a drag strip, above Home. */
export const DRAG_REGION_PX = 28;
export const CSP = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-src 'none'";
/** Put the result inside <head> of ui/shell.html. */
export const cspMeta = () => `<meta http-equiv="Content-Security-Policy" content="${CSP}">`;
/** Frameless window + autohide window controls that always sit ABOVE app views. No top bar.
 *  Paths: shellHtml = join(__dirname,'ui','shell.html'), shellPreload = join(__dirname,'preload-shell.js'). The overlay paths are built in.
 *  NEVER call win.contentView.addChildView yourself: use frame.addView / frame.removeView so the controls stay on top.
 *  Keyboard: Ctrl+Shift+M reveals the controls (controls.reveal) and focuses the first button; Left/Right move, Enter activates, Esc hides. */
export function createFrame(o: FrameOpts) {
  const web = { contextIsolation: true, sandbox: true, nodeIntegration: false };
  const win = new BrowserWindow({ width: 1180, height: 760, minWidth: 720, minHeight: 480, frame: false, show: false, backgroundColor: o.bg ?? '#F5F5F5', webPreferences: { ...web, preload: o.shellPreload } });
  const overlay = new WebContentsView({ webPreferences: { ...web, preload: join(__dirname, 'preload-overlay.js') } });
  overlay.setBackgroundColor('#00000000');
  win.contentView.addChildView(overlay);
  // Lock the shell down: no popups, no navigation away, no permissions for anything.
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  overlay.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  for (const ev of ['will-navigate', 'will-redirect'] as const) { (win.webContents as any).on(ev, (e: any) => e.preventDefault()); (overlay.webContents as any).on(ev, (e: any) => e.preventDefault()); }
  session.defaultSession.setPermissionRequestHandler((_, __, cb) => cb(false));
  session.defaultSession.setPermissionCheckHandler(() => false);

  let shown = false, timer: NodeJS.Timeout | undefined, poll: NodeJS.Timeout | undefined, inside = false;
  const layout = () => {
    const W = win.getContentSize()[0], on = shown || inside;      // bounds stay non-zero while focus is inside the overlay
    overlay.setBounds(on ? { x: W - 196, y: 0, width: 196, height: 48 } : { x: 0, y: 0, width: 0, height: 0 });
    if (!overlay.webContents.isDestroyed()) overlay.webContents.send('wc:state', { visible: on, maximized: win.isMaximized() });
  };
  const hideLater = () => { if (timer) clearTimeout(timer); timer = setTimeout(() => { timer = undefined; if (inside) return; shown = false; layout(); }, 1200); };
  const tick = () => {
    if (win.isDestroyed() || !win.isVisible() || win.isMinimized()) return;
    const p = screen.getCursorScreenPoint(), b = win.getBounds(), dx = p.x - b.x, dy = p.y - b.y;
    const inWin = dx >= 0 && dx <= b.width && dy >= 0 && dy <= b.height;
    const hot = inWin && (dy <= 8 || (shown && dy <= 56 && dx >= b.width - 204));
    if (hot) { if (timer) { clearTimeout(timer); timer = undefined; } if (!shown) { shown = true; layout(); } }
    else if (shown && !timer) hideLater();
  };
  // The cursor is polled in the main process (120 ms) only while the window is focused.
  const startPoll = () => { if (!poll) poll = setInterval(tick, 120); };
  const stopPoll = () => { if (poll) { clearInterval(poll); poll = undefined; } };
  win.on('focus', startPoll); win.on('blur', () => { stopPoll(); if (shown && !inside) hideLater(); });
  win.on('closed', () => { stopPoll(); if (timer) clearTimeout(timer); });
  overlay.webContents.on('focus', () => { inside = true; shown = true; if (timer) { clearTimeout(timer); timer = undefined; } layout(); });
  overlay.webContents.on('blur', () => { inside = false; hideLater(); });
  const reveal = () => {
    if (win.isDestroyed()) return;
    shown = true; if (timer) { clearTimeout(timer); timer = undefined; } layout();
    overlay.webContents.focus(); if (!overlay.webContents.isDestroyed()) overlay.webContents.send('wc:focus-first');
  };
  const keys = (e: Electron.Event, i: Electron.Input) => { if (i.type === 'keyDown' && i.control && i.shift && !i.alt && i.key.toLowerCase() === 'm') { e.preventDefault(); reveal(); } };
  win.webContents.on('before-input-event', keys);
  ipcMain.removeHandler('wc:cmd');
  ipcMain.handle('wc:cmd', (_e, c: string) => {
    if (c === 'min') win.minimize(); else if (c === 'max') (win.isMaximized() ? win.unmaximize() : win.maximize()); else if (c === 'close') win.close();
    else if (c === 'hide') { inside = false; shown = false; win.webContents.focus(); }
    layout();
  });
  for (const ev of ['resize', 'maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen']) (win as any).on(ev, layout);
  overlay.webContents.loadFile(join(__dirname, 'assets', 'overlay.html'));
  win.loadFile(o.shellHtml);
  win.once('ready-to-show', () => { layout(); win.show(); if (win.isFocused()) startPoll(); });
  const raise = () => { win.contentView.removeChildView(overlay); win.contentView.addChildView(overlay); };
  const addView = (v: WebContentsView) => { win.contentView.addChildView(v); v.webContents.on('before-input-event', keys); raise(); };
  const removeView = (v: WebContentsView) => { try { win.contentView.removeChildView(v); } catch {} };
  return { win, overlay, addView, removeView, raise, controls: { reveal }, DRAG_REGION_PX };
}
