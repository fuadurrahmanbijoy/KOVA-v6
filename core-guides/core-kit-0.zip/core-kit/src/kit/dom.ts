// Tiny renderer helper: elements are built with text nodes and attributes only, never from markup strings.
export type Child = Node | string | number | null | undefined | false;
export type Attrs = Record<string, unknown> | null | undefined;
const URL_ATTR = /^(href|src|action|formaction|xlink:href)$/i;
/** h('button', { class: 'k-btn', onclick: fn, 'aria-label': 'Close' }, 'Close') */
export function h<K extends keyof HTMLElementTagNameMap>(tag: K, attrs?: Attrs, ...children: Child[]): HTMLElementTagNameMap[K];
export function h(tag: string, attrs?: Attrs, ...children: Child[]): HTMLElement;
export function h(tag: string, attrs?: Attrs, ...children: Child[]): HTMLElement {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs ?? {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class' || k === 'className') el.className = String(v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on')) { if (typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v as EventListener); }   // string handlers are ignored
    else if (URL_ATTR.test(k) && /^\s*(javascript|data):/i.test(String(v))) continue;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of children.flat() as Child[]) if (c !== null && c !== undefined && c !== false) el.append(typeof c === 'object' ? c : document.createTextNode(String(c)));
  return el;
}
export const setText = (el: Node, text: unknown) => { el.textContent = text === null || text === undefined ? '' : String(text); };
export const clear = (el: Node) => { while (el.firstChild) el.removeChild(el.firstChild); };
