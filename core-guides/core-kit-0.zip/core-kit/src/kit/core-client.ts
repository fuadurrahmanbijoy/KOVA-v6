// Renderer side. import { core, onEvent } from '../../kit/core-client'; then: await core.installer.apps.list()
const w = globalThis as any;
const mk = (path: string): any => new Proxy(function () {}, { get: (_t, k: string) => mk(path ? path + '.' + k : k), apply: (_t, _s, a) => w.kovaCore.call(path, ...a) });
export const core: any = mk('');
export const onEvent = (fn: (channel: string, payload: any) => void): (() => void) => w.kovaCore.on(fn);
