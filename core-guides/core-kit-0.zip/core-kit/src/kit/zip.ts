// Streaming zip helpers (yauzl + yazl, pure JS). Every unsafe archive throws ZipError: KV-IN-001 = damaged or unsafe, KV-IN-011 = too big.
import { createWriteStream, mkdirSync, readdirSync, lstatSync } from 'node:fs';
import { dirname, join, resolve, sep } from 'node:path';
import { Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

export interface ZipEntry { name: string; size: number; csize: number; mode: number; isDir: boolean }
export interface ZipLimits { maxEntries: number; maxTotal: number; maxEntry: number; maxRatio: number; ratioMinBytes: number }
export const DEFAULT_LIMITS: ZipLimits = { maxEntries: 20000, maxTotal: 2 * 1024 ** 3, maxEntry: 1024 ** 3, maxRatio: 200, ratioMinBytes: 65536 };
export class ZipError extends Error {
  constructor(public code: 'KV-IN-001' | 'KV-IN-011', public reason: string, public entry?: string) { super(`${code}: ${reason}${entry ? ' (' + entry + ')' : ''}`); this.name = 'ZipError'; }
}
const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;
const S_IFMT = 0o170000, S_IFLNK = 0o120000;
/** Why a single entry name is unsafe, or null when it is fine. */
export function badName(raw: string): string | null {
  if (!raw) return 'empty name';
  const n = raw.replace(/\\/g, '/');
  if (n.startsWith('/') || /^[a-zA-Z]:/.test(n)) return 'absolute path';
  if (n.includes(':')) return 'colon in name (drive letter or NTFS stream)';
  if (n.includes('\0')) return 'NUL in name';
  const segs = n.replace(/\/$/, '').split('/');
  for (const s of segs) {
    if (s === '..') return 'path traversal';
    if (s === '' || s === '.') return 'empty or dot segment';
    if (/[. ]$/.test(s)) return 'trailing dot or space';
    if (RESERVED.test(s.split('.')[0].replace(/ +$/, ''))) return 'reserved Windows name';
  }
  return null;
}
/** Pure check over the central directory; returns the total uncompressed size. */
export function checkEntries(entries: ZipEntry[], lim: Partial<ZipLimits> = {}): number {
  const L = { ...DEFAULT_LIMITS, ...lim };
  if (entries.length > L.maxEntries) throw new ZipError('KV-IN-011', `more than ${L.maxEntries} entries`);
  const seen = new Set<string>(); let total = 0;
  for (const e of entries) {
    const why = badName(e.name); if (why) throw new ZipError('KV-IN-001', why, e.name);
    if ((e.mode & S_IFMT) === S_IFLNK) throw new ZipError('KV-IN-001', 'symlink entry', e.name);
    const k = e.name.replace(/\\/g, '/').replace(/\/$/, '').toLowerCase();
    if (seen.has(k)) throw new ZipError('KV-IN-001', 'duplicate name', e.name); seen.add(k);
    if (e.isDir) continue;
    if (e.size > L.maxEntry) throw new ZipError('KV-IN-011', 'entry too large', e.name);
    if (e.size >= L.ratioMinBytes && e.size / Math.max(1, e.csize) > L.maxRatio) throw new ZipError('KV-IN-011', `compression ratio above ${L.maxRatio}:1`, e.name);
    total += e.size; if (total > L.maxTotal) throw new ZipError('KV-IN-011', 'total uncompressed size too large');
  }
  return total;
}
const yauzl = () => require('yauzl');
const open = (file: string): Promise<any> => new Promise((ok, no) => yauzl().open(file, { lazyEntries: true, autoClose: false, validateEntrySizes: true }, (e: any, z: any) => (e ? no(new ZipError('KV-IN-001', String(e.message ?? e))) : ok(z))));
const toEntry = (e: any): ZipEntry => ({ name: e.fileName, size: e.uncompressedSize, csize: e.compressedSize, isDir: /\/$/.test(e.fileName), mode: (e.versionMadeBy >> 8) === 3 ? (e.externalFileAttributes >>> 16) & 0xffff : 0 });
function walkEntries(z: any, on: (raw: any) => void): Promise<void> {
  return new Promise((ok, no) => { z.on('error', (e: any) => no(new ZipError('KV-IN-001', String(e.message ?? e)))); z.on('end', ok); z.on('entry', (e: any) => { try { on(e); z.readEntry(); } catch (x) { no(x); } }); z.readEntry(); });
}
export async function listEntries(file: string): Promise<ZipEntry[]> {
  const z = await open(file), out: ZipEntry[] = [];
  try { await walkEntries(z, (e) => out.push(toEntry(e))); } finally { z.close(); }
  return out;
}
/** Central-directory totals, for space.check and the size prompt (uncompressed bytes). Throws like safeExtract would. */
export async function inspectZip(file: string, lim: Partial<ZipLimits> = {}): Promise<{ entries: number; totalBytes: number }> {
  const l = await listEntries(file); return { entries: l.length, totalBytes: checkEntries(l, lim) };
}
const stream = (z: any, raw: any): Promise<NodeJS.ReadableStream> => new Promise((ok, no) => z.openReadStream(raw, (e: any, s: any) => (e ? no(new ZipError('KV-IN-001', String(e.message ?? e), raw.fileName)) : ok(s))));
const limit = (max: number, what: string, name: string) => { let n = 0; return new Transform({ transform(c, _e, cb) { n += c.length; n > max ? cb(new ZipError('KV-IN-011', what, name)) : cb(null, c); } }); };
export async function readEntry(file: string, name: string, maxBytes: number): Promise<Buffer> {
  const z = await open(file); let found: any = null;
  try {
    await walkEntries(z, (e) => { if (e.fileName === name) found = e; });
    if (!found) throw new ZipError('KV-IN-001', 'entry not found', name);
    if (found.uncompressedSize > maxBytes) throw new ZipError('KV-IN-011', 'entry too large', name);
    const s = await stream(z, found), parts: Buffer[] = [];
    await pipeline(s as any, limit(maxBytes, 'entry too large', name), new Transform({ transform(c, _e, cb) { parts.push(c); cb(); } }));
    return Buffer.concat(parts);
  } finally { z.close(); }
}
/** Validates the whole central directory first, then extracts into dest (a temp dir you own). Existing files are never overwritten ('wx'). */
export async function safeExtract(file: string, dest: string, lim: Partial<ZipLimits> = {}): Promise<{ files: number; totalBytes: number }> {
  const L = { ...DEFAULT_LIMITS, ...lim }, all = await listEntries(file), totalBytes = checkEntries(all, L);
  const root = resolve(dest); mkdirSync(root, { recursive: true });
  const z = await open(file); let files = 0, written = 0;
  const jobs: any[] = [];
  try {
    await walkEntries(z, (e) => jobs.push(e)); // collect; extraction below reopens streams one at a time
    for (const raw of jobs) {
      const rel = raw.fileName.replace(/\\/g, '/'), target = resolve(root, rel);
      if (target !== root && !target.startsWith(root + sep)) throw new ZipError('KV-IN-001', 'path traversal', raw.fileName);
      if (rel.endsWith('/')) { mkdirSync(target, { recursive: true }); continue; }
      mkdirSync(dirname(target), { recursive: true });
      const s = await stream(z, raw);
      const budget = Math.min(raw.uncompressedSize, L.maxEntry);
      await pipeline(s as any, limit(budget, 'entry larger than its header says', raw.fileName), new Transform({ transform(c, _e, cb) { written += c.length; written > L.maxTotal ? cb(new ZipError('KV-IN-011', 'total uncompressed size too large')) : cb(null, c); } }), createWriteStream(target, { flags: 'wx' }));
      files++;
    }
  } finally { z.close(); }
  return { files, totalBytes };
}
/** Zip a folder (streaming). exclude: names or relative posix paths to skip. */
export function createZip(srcDir: string, outFile: string, opts: { exclude?: string[] } = {}): Promise<void> {
  const yazl = require('yazl'), zf = new yazl.ZipFile(), ex = new Set(opts.exclude ?? []), root = resolve(srcDir);
  (function walk(d: string, rel: string) {
    for (const n of readdirSync(d).sort()) {
      const p = join(d, n), r = rel ? rel + '/' + n : n; if (ex.has(n) || ex.has(r)) continue;
      const st = lstatSync(p); if (st.isSymbolicLink()) throw new Error('symlink not allowed: ' + r);
      st.isDirectory() ? walk(p, r) : zf.addFile(p, r);
    }
  })(root, '');
  mkdirSync(dirname(resolve(outFile)), { recursive: true });
  return new Promise((ok, no) => { const o = createWriteStream(outFile); o.on('close', () => ok()); o.on('error', no); zf.outputStream.on('error', no).pipe(o); zf.end(); });
}
