// Runs before every start: checks the six parts exist, merges dependencies, finishes Electron's setup, generates src/generated/pages.ts.
import { readdirSync, readFileSync, writeFileSync, existsSync, mkdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
const NUM = { foundation: 1, installer: 2, runner: 3, frame: 4, manager: 5, seal: 0 };
const missing = [];
for (const p of ['foundation', 'installer', 'runner', 'frame', 'seal']) if (!existsSync(join('src', p, 'index.ts'))) missing.push(p);
const noPages = ['home', 'app', 'busy', 'settings'].filter((id) => !existsSync(join('src', 'manager', 'ui', 'pages', id + '.ts')));
if (noPages.length) missing.push('manager');
if (missing.length) {
  console.error('\nKova cannot start yet. These parts are missing or incomplete:\n' + missing.map((p) => p === 'manager' && noPages.length ? `  - manager  (page ids missing: ${noPages.join(', ')}; build it with core-2-build-parts, part 5, then copy its files into this folder)` : null).filter(Boolean).join('\n') + (missing.some((p) => p !== 'manager') ? '\n' : '') + missing.filter((p) => p !== 'manager').map((p) => `  - ${p}  (${NUM[p] ? `build it with core-2-build-parts, part ${NUM[p]}` : 'build it with core-3-seal-parts'}, then copy its files into this folder)`).join('\n') + '\n');
  process.exit(1);
}
const pkg = JSON.parse(readFileSync('package.json', 'utf8')); let changed = false;
const parts = readdirSync('src').filter((d) => d !== 'kit' && d !== 'generated' && statSync(join('src', d)).isDirectory());
const pages = []; const seen = {};
for (const d of parts) {
  const dj = join('src', d, 'deps.json');
  if (existsSync(dj)) for (const [k, v] of Object.entries(JSON.parse(readFileSync(dj, 'utf8')).dependencies ?? {})) {
    if (seen[k] && seen[k].v !== v) { console.error(`Dependency conflict: "${k}" is ${seen[k].v} in src/${seen[k].d} but ${v} in src/${d}. Make both parts use the same range.`); process.exit(1); }
    seen[k] = { v, d };
    if (!pkg.dependencies[k]) { pkg.dependencies[k] = v; changed = true; }
  }
  const pd = join('src', d, 'ui', 'pages');
  if (existsSync(pd)) for (const f of readdirSync(pd)) if (/\.ts$/.test(f) && !/\.d\.ts$/.test(f)) pages.push({ id: f.replace(/\.ts$/, ''), imp: `../${d}/ui/pages/${f.replace(/\.ts$/, '')}` });
}
const run = (args) => spawnSync(process.execPath, args, { stdio: 'inherit' });
if (changed) {
  writeFileSync('package.json', JSON.stringify(pkg, null, 2));
  try { const r = run([createRequire(import.meta.url).resolve('npm/bin/npm-cli.js'), 'install']); if (r.status !== 0) console.error(`npm install failed (exit ${r.status}); run "npm install" once more.`); } catch { console.error('npm install could not start; run "npm install" once more.'); }
}
if (!existsSync('node_modules/electron/path.txt') && existsSync('node_modules/electron/install.js')) { console.log('Finishing Electron setup (one time)...'); run(['node_modules/electron/install.js']); }
mkdirSync('src/generated', { recursive: true });
writeFileSync('src/generated/pages.ts', pages.map((p, i) => `import p${i} from '${p.imp}';`).join('\n') + `\nexport const pages: Record<string, any> = { ${pages.map((p, i) => `'${p.id}': p${i}`).join(', ')} };\n`);
console.log('setup ok:', parts.join(', '));
