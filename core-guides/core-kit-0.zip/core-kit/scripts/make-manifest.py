#!/usr/bin/env python3
"""Kit integrity manifest. Run from the project/kit root.
  python scripts/make-manifest.py           writes kit.manifest.json (sha256 of main.ts, scripts/**, assets/**, src/kit/**; package.json is excluded)
  python scripts/make-manifest.py --check   lists changed / missing / added kit files, exit 1 if any"""
import sys, os, json, hashlib, pathlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kvlib as L

M = 'kit.manifest.json'


def scan(root='.'):
    r = pathlib.Path(root); fs = {}
    cand = [r / 'main.ts'] + [p for d in ('scripts', 'assets', 'src/kit') for p in sorted((r / d).rglob('*'))]
    for p in cand:
        if p.is_file() and not L.is_junk(p.relative_to(r).parts): fs[p.relative_to(r).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    return fs


def check(root='.'):
    mf = pathlib.Path(root) / M
    if not mf.is_file(): return [f'{M} missing']
    old = json.loads(mf.read_text('utf8'))['files']; new = scan(root); out = []
    out += [f'changed: {f}' for f in sorted(old) if f in new and old[f] != new[f]]
    out += [f'missing: {f}' for f in sorted(old) if f not in new]
    out += [f'added: {f}' for f in sorted(new) if f not in old]
    return out


if __name__ == '__main__':
    if '--check' in sys.argv:
        pr = check()
        for x in pr[:20]: print(x)
        print('kit manifest: ' + ('FAIL' if pr else 'ok')); sys.exit(1 if pr else 0)
    json.dump({'files': scan()}, open(M, 'w', encoding='utf8'), indent=1, sort_keys=True); print('wrote', M)
