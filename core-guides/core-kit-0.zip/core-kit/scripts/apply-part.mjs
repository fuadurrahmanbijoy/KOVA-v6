// Apply a fixed part to a built Core folder:  node scripts/apply-part.mjs <file.kvpart>   (then: npm start)
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync, rmSync } from 'node:fs';
const f = process.argv[2];
const die = (m) => { console.error(m); process.exit(1); };
if (!f || !existsSync(f)) die('Usage: node scripts/apply-part.mjs <path to the .kvpart file>');
const FOLDERS = { 1: 'foundation', 2: 'installer', 3: 'runner', 4: 'frame', 5: 'manager' };
let pj;   // Windows 10+ includes tar; it reads zip files whatever the extension
try { pj = JSON.parse(execFileSync('tar', ['-xOf', f, 'part.json']).toString('utf8')); } catch { die('Cannot read part.json from ' + f + ' (not a .kvpart?)'); }
if (existsSync('core.json')) { const id = JSON.parse(readFileSync('core.json', 'utf8')).id; if (pj.setId !== id) die(`Refused: this part is for ${pj.setId}, this Core is ${id}.`); }
const dir = FOLDERS[pj.part]; if (!dir || pj.kind !== 'core') die('Refused: part.json is not a Core part 1-5.');
const names = execFileSync('tar', ['-tf', f]).toString('utf8').split(/\r?\n/).filter(Boolean);
const bad = names.filter((n) => n !== 'part.json' && !n.startsWith(`src/${dir}/`) || n.includes('..') || n.includes('\\'));
if (bad.length) die('Refused: files outside src/' + dir + '/: ' + bad.slice(0, 5).join(', '));
rmSync(`src/${dir}`, { recursive: true, force: true });
execFileSync('tar', ['-xf', f, '-C', '.'], { stdio: 'inherit' });
rmSync('part.json', { force: true });
console.log(`Applied part ${pj.part} (${dir}). Now run: npm start`);
