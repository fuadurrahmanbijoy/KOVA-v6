#!/usr/bin/env python3
"""Kova verifier. Each subcommand prints at most 20 lines and exits 1 on failure.
  verify.py fp [--write] <md files...>   recompute every FP:S2.x and CONTRACT-FP (--write rewrites them)
  verify.py contract <dir...>            S2 blocks identical across guides, CONTRACT-FP identical, no dangling section references
  verify.py blueprint <file>             same validation as pack-part
  verify.py core                         (project folder, after assemble + seal) parts, typecheck, bundles, pages, basename collisions, kit manifest
  verify.py app                          (project folder, after wire-app) syntax, import graph, kova.json"""
import sys, os, re, json, glob, hashlib, pathlib, subprocess, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kvlib as L

OUT = []
def say(s): OUT.append(s)
def finish(fail=None):
    for x in OUT[:20]: print(x)
    if len(OUT) > 20: print(f'... {len(OUT) - 20} more')
    sys.exit(1 if (fail if fail is not None else any(x.startswith('FAIL') for x in OUT)) else 0)

BLOCK = re.compile(r'<!-- BEGIN (S\d+\.\d+) -->\n(.*?)\n<!-- END \1 -->(\n`?FP:\1:([0-9a-f]{8})`?)?', re.S)
key = lambda s: tuple(int(x) for x in s[1:].split('.'))
h8 = lambda s: hashlib.sha256(s.encode('utf8')).hexdigest()[:8]


def fp(args):
    w = '--write' in args; files = [f for f in args if f != '--write']
    if not files: say('FAIL no files'); finish()
    texts = {f: open(f, encoding='utf8', newline='').read() for f in files}; secs = {}
    for f, t in texts.items():
        for m in BLOCK.finditer(t): secs.setdefault(m[1], h8(m[2]))
    order = sorted(secs, key=key)
    top = max((key(s)[1] for s in order), default=0)
    complete = [key(s)[1] for s in order] == list(range(1, top + 1))
    cfp = h8(''.join(secs[s] for s in order)) if complete else None
    if not complete: say('SKIP CONTRACT-FP (sections not all present: ' + ', '.join(order) + ')')
    bad = 0
    for f, t in texts.items():
        def fix(m):
            nonlocal bad
            if m[4] is None: say(f'FAIL {os.path.basename(f)}: {m[1]} has no FP line'); bad += 1; return m[0]
            if m[4] != h8(m[2]):
                bad += 1; say(f'FAIL {os.path.basename(f)}: FP:{m[1]} {m[4]} -> {h8(m[2])}'); i = m.start(4) - m.start(0); return m[0][:i] + h8(m[2]) + m[0][i + 8:]
            return m[0]
        nt = BLOCK.sub(fix, t)
        if cfp:
            for m in re.finditer(r'CONTRACT-FP:([0-9a-f]{8})', nt):
                if m[1] != cfp: bad += 1; say(f'FAIL {os.path.basename(f)}: CONTRACT-FP {m[1]} -> {cfp}')
            nt = re.sub(r'CONTRACT-FP:[0-9a-f]{8}', 'CONTRACT-FP:' + cfp, nt)
        if w and nt != t: open(f, 'w', encoding='utf8', newline='').write(nt)
    if w: say(f'wrote FPs for {len(files)} files, CONTRACT-FP {cfp}'); finish(False)
    say('fp: ' + ('FAIL' if bad else 'ok') + (f' CONTRACT-FP {cfp}' if cfp else '')); finish(bool(bad))


def contract(args):
    dirs = args or ['.']; pairs = [(f, d) for d in dirs for f in sorted(glob.glob(os.path.join(d, '**', '*.md'), recursive=True))]; files = [p[0] for p in pairs]; seen = {}; defined = set(); refs = {}; cf = {}
    for f, d in pairs:
        t = open(f, encoding='utf8').read(); b = os.path.join(os.path.basename(os.path.normpath(d)), os.path.relpath(f, d)) if len(dirs) > 1 else os.path.relpath(f, d)
        for m in BLOCK.finditer(t): seen.setdefault(m[1], {}).setdefault(m[2], []).append(b); defined.add(m[1])
        defined |= set(re.findall(r'\[(S\d+(?:\.\d+)?)\]', t))
        for m in re.finditer(r'CONTRACT-FP:([0-9a-f]{8})', t): cf.setdefault(m[1], []).append(b)
        for m in re.finditer(r'\bS\d+(?:\.\d+)?\b', re.sub(r'`?FP:S\d+\.\d+:[0-9a-f]{8}`?', '', t)): refs.setdefault(m[0], set()).add(b)
    for s in sorted(seen, key=key):
        if len(seen[s]) > 1: say(f'FAIL {s} differs: ' + ' | '.join(','.join(v) for v in seen[s].values()))
    if len(cf) > 1: say('FAIL CONTRACT-FP differs: ' + ', '.join(f'{k} in {len(v)} files' for k, v in cf.items()))
    for r in sorted(refs, key=lambda x: tuple(int(y) for y in x[1:].split('.'))):
        if r not in defined and not any(x.startswith(r + '.') for x in defined): say(f'FAIL dangling reference {r} in ' + ', '.join(sorted(refs[r])))
    if any(os.path.basename(f) == 'part-1-foundation.md' for f in files):
        alltext = ' '.join(open(f, encoding='utf8').read() for f in files)
        for k in REQUEST_KEYS:
            if f'requestCard.{k}' not in alltext and not (k == 'extras' and 'requestCard.extras' in alltext): say(f'FAIL requestCard.{k} has no documented consumer in the guides')
    if not OUT: say(f'contract: ok ({len(files)} files, {len(seen)} sections)')
    finish()


REQUEST_KEYS = ('name', 'accent', 'layout', 'capabilities', 'extras')
CAPS = ('tray', 'status', 'blocklist', 'globalShortcuts')


def request_card(bp):
    rc = bp.get('requestCard')
    if rc is None: return
    if not isinstance(rc, dict): say('FAIL requestCard must be an object'); return
    for k in rc:
        if k not in REQUEST_KEYS: say(f'FAIL requestCard.{k} is not a documented key (allowed: ' + ', '.join(REQUEST_KEYS) + ')')
    if 'accent' in rc and not re.fullmatch(r'#[0-9a-fA-F]{6}', str(rc['accent'])): say('FAIL requestCard.accent must be #RRGGBB')
    if 'capabilities' in rc and not (isinstance(rc['capabilities'], list) and all(c in CAPS for c in rc['capabilities'])): say('FAIL requestCard.capabilities must be a subset of ' + ', '.join(CAPS))
    if 'extras' in rc and not (isinstance(rc['extras'], list) and all(isinstance(x, str) for x in rc['extras'])): say('FAIL requestCard.extras must be a list of strings')


def blueprint(args):
    try: bp = json.load(open(args[0], encoding='utf8'))
    except Exception as e: say('FAIL ' + str(e)); finish()
    for e in L.validate_blueprint(bp): say('FAIL ' + e)
    request_card(bp)
    if not OUT: say('blueprint: ok')
    finish()


def run(cmd, **k): return subprocess.run(cmd, capture_output=True, text=True, **k)


def core(args):
    if os.path.isfile('blueprint.json'):
        try: request_card(json.load(open('blueprint.json', encoding='utf8')))
        except Exception: pass
    for p in L.core_problems('.'): say('FAIL ' + p)
    ts = L.find_tsc()
    if os.path.isfile('tsconfig.json') and ts:
        r = run(ts + ['--noEmit', '-p', 'tsconfig.json'])
        if r.returncode: say('FAIL typecheck:'); [say('  ' + x) for x in (r.stdout + r.stderr).strip().splitlines()[:6]]
    else: say('SKIP typecheck (no tsconfig)')
    es = L.find_esbuild(); all_ = [p.as_posix() for p in sorted(pathlib.Path('src').rglob('*')) if p.is_file() and 'node_modules' not in p.parts]
    ent = [f for f in all_ if re.search(r'(^|/)renderer-[^/]*\.ts$', f) or re.search(r'^src/[^/]+/ui/pages/[^/]*\.ts$', f)]
    ent = [f for f in ent if not f.endswith('.d.ts')]
    if es:
        for f in ent:
            r = run(es + [f, '--bundle', '--platform=browser', '--outfile=' + os.devnull, '--log-level=error'])
            if r.returncode: say(f'FAIL bundle {f}: ' + (r.stderr.strip().splitlines() or ['error'])[0][:150])
    else: say('SKIP bundle (no esbuild)')
    base = lambda fs: [(os.path.basename(f)[:-3] if f.endswith('.ts') else os.path.basename(f), f) for f in fs]
    nodes = [('main', 'main.ts')] + base([f for f in all_ if re.search(r'/preload-[^/]*\.ts$', f) or f.endswith('/backend-host.ts')])
    groups = {'node': nodes, 'web': base([f for f in all_ if re.search(r'/renderer-[^/]*\.ts$', f)]), 'ui': base([f for f in all_ if re.search(r'\.(html|css)$', f)])}
    for g, items in groups.items():
        m = {}
        for b, f in items: m.setdefault(b, []).append(f)
        for b, fs in m.items():
            if len(set(fs)) > 1: say(f'FAIL build collision ({g}) "{b}": ' + ', '.join(fs))
    import importlib.util
    sp = importlib.util.spec_from_file_location('mm', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'make-manifest.py')); mm = importlib.util.module_from_spec(sp); sp.loader.exec_module(mm)
    for x in mm.check('.'): say('FAIL kit ' + x)
    if not any(x.startswith('FAIL') for x in OUT): say('core: ok')
    finish()


IMP = re.compile(r'''(?:\bfrom\s*|\bimport\s*\(?\s*|\bexport\s*\*\s*from\s*)['"](\.{1,2}/[^'"]*|\.{1,2})['"]''')


def app(args):
    root = pathlib.Path('app')
    if not root.is_dir(): say('FAIL no app/ folder'); finish()
    ts = [p for p in sorted(root.rglob('*')) if p.suffix in ('.ts', '.tsx') and not L.is_junk(p.relative_to(root).parts) and not p.name.endswith('.d.ts')]
    es = L.find_esbuild()
    for p in ts:
        if es:
            r = subprocess_run_stdin(es, p)
            if r.returncode: say(f'FAIL syntax {p.as_posix()}: ' + (r.stderr.strip().splitlines() or ['error'])[0][:150])
        for m in IMP.finditer(p.read_text('utf8', 'replace')):
            s = m[1]; ext = os.path.splitext(s)[1]
            if not ext or s.endswith('/') or s in ('.', '..'): say(f'FAIL extensionless import "{s}" in {p.as_posix()}'); continue
            t = (p.parent / s).resolve()
            ok = t.is_file() or (ext in ('.js', '.mjs') and any(t.with_suffix(x).is_file() for x in ('.ts', '.tsx')))
            if not ok: say(f'FAIL unresolved import "{s}" in {p.as_posix()}')
    if not es: say('SKIP syntax (no esbuild)')
    try: k = json.loads((root / 'kova.json').read_text('utf8'))
    except Exception as e: say('FAIL kova.json: ' + str(e)); finish()
    for e in L.validate_kova(k, root): say('FAIL kova.json: ' + e)
    if not any(x.startswith('FAIL') for x in OUT): say(f'app: ok ({len(ts)} ts files)')
    finish()


def subprocess_run_stdin(es, p):
    return subprocess.run(es + [str(p), '--log-level=error', '--loader:.ts=ts'], capture_output=True, text=True)


if __name__ == '__main__':
    c = sys.argv[1] if len(sys.argv) > 1 else ''
    f = {'fp': fp, 'contract': contract, 'blueprint': blueprint, 'core': core, 'app': app}.get(c)
    if not f: sys.exit(__doc__)
    f(sys.argv[2:])
