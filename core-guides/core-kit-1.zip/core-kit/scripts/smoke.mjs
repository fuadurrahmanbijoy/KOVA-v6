// `npm run smoke` (Windows + Electron): setup, build, then run the Core once with KOVA_SMOKE=1. Exit code 0 = SMOKE OK.
import { spawnSync, spawn } from 'node:child_process';
import { createRequire } from 'node:module';
const req = createRequire(import.meta.url);
for (const s of ['scripts/setup.mjs', 'scripts/build.mjs']) { const r = spawnSync(process.execPath, [s], { stdio: 'inherit' }); if (r.status) process.exit(r.status); }
const p = spawn(req('electron'), ['.'], { stdio: 'inherit', env: { ...process.env, KOVA_SMOKE: '1' } });
const t = setTimeout(() => { console.log('SMOKE FAIL timeout: no result within 12 minutes'); p.kill(); }, 12 * 60_000);
p.on('exit', (c) => { clearTimeout(t); process.exit(c ?? 1); });
