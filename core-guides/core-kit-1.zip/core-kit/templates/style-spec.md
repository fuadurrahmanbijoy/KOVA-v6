# Kova Core Style Spec · edition 2 (rev 4)
Teams-style, Fluent language. Accent is a variable (default blue `#0F6CBD`); light theme is the default. Apps get these values as `--k-*` variables and `.k-*` classes (see the look kit).

| Token | Light | Dark |
|---|---|---|
| Page | #F5F5F5 | #292929 |
| Surface | #FFFFFF | #1F1F1F |
| Surface 2 (rail, hover) | #EFEFEF | #333333 |
| Text / secondary | #242424 / #616161 | #FFFFFF / #D6D6D6 |
| Border | #E0E0E0 | #4A4A4A |

Type: Segoe UI Variable / Segoe UI; 12, 14, 16, 20, 28 px; weights 400 and 600. Grid 4 px; radii 4 / 8 / 12 px.
Rail: 72 px with labels, 52 px icon only; items stack from the top; icons 24 px, filled when selected; 3x20 accent pill slides to the selected item; running dot under icons.
Motion: 100 ms hover and press, 200 ms fades and panels, 300 ms page enter (fade + 8 px rise); ease-out; no bounce; reduced motion respected.
Cards: radius 8, soft shadow, lift 2 px and accent border on hover. Dialogs: radius 12, scrim, pop-in.
No top bar. Window controls appear only when the pointer touches the top edge.

Accent variables: `--k-accent`, `-hover`, `-pressed`, `-tint`, `--k-on-accent` (text on an accent fill) and `--k-accent-text` (accent used as text, focus outline or selected-tab color; adjusted for contrast on the page). Use `--k-accent-text`, never `--k-accent`, for accent-colored text.

Window chrome (decision D2 = keep autohide, with fixes): the Core keeps the Frame's own title area and the kit overlay draws the window controls, auto-hiding when idle and reappearing on pointer move or keyboard focus. Native `titleBarOverlay` was not chosen. Accent colors must be `#RRGGBB`; anything else is ignored.
