/** Debug hooks used only by the smoke harness (KOVA_SMOKE=1). All are undefined in normal runs, so they cost nothing. */
export const hooks: {
  onNpmSpawn?: (args: string[]) => void;
  onHandshake?: (i: { appId: string; step: number; budget: number; neverStartedOk: boolean }) => void;
} = {};
