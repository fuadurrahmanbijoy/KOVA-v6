/** Smoke harness (rev 4). OFF unless KOVA_SMOKE=1; run it with `npm run smoke` on Windows. It uses a temporary Library, installs
 *  tests/fixtures/mini-app.kvx, runs the checks below one by one and prints `SMOKE OK` or `SMOKE FAIL <step>: <reason>` (exit 0 / 1).
 *  Assumptions (a failing step names the one that did not hold): the Foundation reads the Library root from %LOCALAPPDATA%\Kova\root.json
 *  (the harness points LOCALAPPDATA at a temp folder); removed data lands somewhere under foundation.paths.trash; app data lives in paths.app(id)\data. */
import { app, BrowserWindow, session } from 'electron';
import { mkdtempSync, mkdirSync, writeFileSync, existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { hooks } from './debug';
import { dispatch, type RpcTable } from './rpc';
import type { Foundation, Installer, Runner, Frame, KitFrame } from './seam-types';

export const smokeOn = () => process.env.KOVA_SMOKE === '1';
/** Call BEFORE foundation.create(): isolates Library root and Electron userData in a temp folder. */
export function smokePrelude(): string {
  const tmp = mkdtempSync(join(tmpdir(), 'kova-smoke-')), local = join(tmp, 'local');
  mkdirSync(join(local, 'Kova'), { recursive: true });
  writeFileSync(join(local, 'Kova', 'root.json'), JSON.stringify({ root: join(tmp, 'Library') }));
  process.env.LOCALAPPDATA = local; app.setPath('userData', join(tmp, 'userData'));
  return tmp;
}
const walk = (d: string, depth = 6, out: string[] = []): string[] => {
  if (depth < 0 || !existsSync(d)) return out;
  for (const e of readdirSync(d)) { const p = join(d, e); out.push(p); try { if (statSync(p).isDirectory()) walk(p, depth - 1, out); } catch {} }
  return out;
};
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
export async function runSmoke(c: { tmp: string; kvx: string; foundation: Foundation; installer: Installer; runner: Runner; frame: Frame; window: KitFrame; table: RpcTable; kitRoot: string }): Promise<void> {
  const { foundation: f, installer: ins, runner: run, frame, window: w, table } = c;
  const npm: string[][] = [], hs: { neverStartedOk: boolean; budget: number }[] = []; let restarted = false;
  hooks.onNpmSpawn = (a) => { npm.push(a); }; hooks.onHandshake = (i) => { hs.push(i); };
  const origRestart = frame.restart; (frame as any).restart = () => { restarted = true; return origRestart.call(frame); };
  let id = '';
  const steps: [string, () => Promise<void>][] = [
    ['library-root', async () => { if (!f.paths.root.startsWith(c.tmp)) throw new Error(`Library root is ${f.paths.root}, not under the temp folder; the Foundation ignored %LOCALAPPDATA%\\Kova\\root.json`); }],
    ['rpc-forged-call-table', async () => { try { await dispatch(table, 'foundation.constructor.constructor', ['return process']); } catch (e: any) { if (/KV-RPC/.test(String(e?.message))) return; throw e; } throw new Error('forged call was accepted'); }],
    ['rpc-forged-call-from-shell', async () => {
      if (w.win.webContents.isLoading()) await new Promise((r) => (w.win.webContents as any).once('did-finish-load', r));
      const r = await w.win.webContents.executeJavaScript(`window.kovaCore.call('foundation.constructor.constructor', 'return process.versions').then(() => 'accepted', (e) => 'rejected:' + e.message)`, true);
      if (!String(r).startsWith('rejected')) throw new Error('shell forged call result: ' + r);
    }],
    ['install-mini-app', async () => {
      const reps = await ins.install([c.kvx], { choose: async () => 0, confirm: async () => true });
      const bad = reps.filter((r) => !r.ok); if (bad.length) throw new Error(JSON.stringify(bad[0].errors?.[0] ?? bad[0]));
      id = reps.find((r) => r.appId)?.appId ?? 'mini-probe-k3x9'; if (!ins.apps.get(id)) throw new Error('app not listed after install');
    }],
    ['installer-no-npm-scripts', async () => {
      if (!npm.length) throw new Error('no npm spawn observed (the fixture declares a dependency)');
      const bad = npm.find((a) => !a.includes('--ignore-scripts')); if (bad) throw new Error('npm spawned without --ignore-scripts: ' + bad.join(' '));
    }],
    ['start-and-run', async () => {
      const r = await run.start(id); if (!r.ok) throw new Error(JSON.stringify(r.errors?.[0] ?? r));
      for (let i = 0; i < 240 && run.state(id) !== 'running'; i++) await sleep(500);
      if (run.state(id) !== 'running') throw new Error('runState is ' + run.state(id));
    }],
    ['handshake-first-start-grace', async () => { const h = hs.find((x) => x.neverStartedOk); if (!h || h.budget < 60000) throw new Error('first start did not use the grace budget: ' + JSON.stringify(hs)); }],
    ['app-view-own-partition', async () => { const v = run.view(id); if (!v) throw new Error('no app view'); const s = v.webContents.session; if (s === w.win.webContents.session || s === session.defaultSession) throw new Error('app view shares the shell/default session'); }],
    ['app-permission-denied', async () => {
      const v = run.view(id)!; const r = await v.webContents.executeJavaScript(`new Promise((ok) => { try { navigator.geolocation.getCurrentPosition(() => ok('granted'), (e) => ok('denied:' + e.code), { timeout: 5000 }); } catch (e) { ok('denied:throw'); } })`, true);
      if (!String(r).startsWith('denied')) throw new Error('permission result: ' + r);
    }],
    ['app-window-open-denied', async () => {
      const v = run.view(id)!, n = BrowserWindow.getAllWindows().length;
      const r = await v.webContents.executeJavaScript(`(() => { try { return window.open('about:blank') === null; } catch (e) { return true; } })()`, true); await sleep(500);
      if (!r || BrowserWindow.getAllWindows().length !== n) throw new Error('window.open produced a window');
    }],
    ['marker-only-via-foundation', async () => {
      const bad: string[] = [];
      for (const p of walk(join(c.kitRoot, 'src'), 4)) { if (!p.endsWith('.ts') || /[\\/]src[\\/](foundation|kit)[\\/]/.test(p)) continue; if (/marker\.json/.test(readFileSync(p, 'utf8'))) bad.push(p); }
      if (bad.length) throw new Error('marker.json named outside the Foundation: ' + bad.join(', '));
      f.marker.update((m: any) => { m.smoke = 1; }); if ((f.marker.read() as any).smoke !== 1) throw new Error('foundation.marker.update did not stick');
    }],
    ['stop', async () => { await run.stop(id); if (run.state(id) === 'running') throw new Error('still running after stop'); }],
    ['remove-keep-data-to-trash', async () => {
      const dd = join(f.paths.app(id), 'data'); mkdirSync(dd, { recursive: true }); writeFileSync(join(dd, 'smoke.txt'), 'keep me');
      const r = await ins.apps.remove(id, false); if (!r.ok) throw new Error(JSON.stringify(r.errors?.[0] ?? r));
      if (!walk(f.paths.trash).some((p) => p.endsWith('smoke.txt'))) throw new Error('smoke.txt not found under ' + f.paths.trash);
    }],
    ['quit-without-restart', async () => { await Promise.race([f.quit.request(), sleep(20000).then(() => { throw new Error('quit.request timed out'); })]); if (restarted) throw new Error('frame.restart was called'); }],
  ];
  for (const [name, fn] of steps) {
    try { await fn(); console.log(`SMOKE step ${name}: ok`); }
    catch (e: any) { console.log(`SMOKE FAIL ${name}: ${String(e?.message ?? e).slice(0, 400)}`); app.exit(1); return; }
  }
  console.log('SMOKE OK'); app.exit(0);
}
