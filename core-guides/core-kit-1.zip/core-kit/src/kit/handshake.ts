import { Channel, env } from './envelope';
import { hooks } from './debug';
export interface HsCtx {
  edition: number; capabilities: string[]; appId: string; startTimeoutMs?: number; capMs?: number;
  /** Extra patience when this version has never started successfully: each phase gets at least this long (default 60000). */
  firstStartGraceMs?: number; neverStartedOk?: boolean;
  welcome(hello: { id: string; edition: number; needs: string[] }): { ok: true; body: unknown } | { ok: false; reason: string };
}
export type HsResult = { ok: true; needs: string[] } | { ok: false; code: 'KV-RU-001' | 'KV-RU-007'; reason: string };
export function coreHandshake(ch: Channel, c: HsCtx): Promise<HsResult> {
  const step = c.startTimeoutMs ?? 10_000, cap = c.capMs ?? 120_000, t0 = Date.now();
  const budget = c.neverStartedOk ? Math.max(step, c.firstStartGraceMs ?? 60_000) : step;   // per phase, not shared
  hooks.onHandshake?.({ appId: c.appId, step, budget, neverStartedOk: !!c.neverStartedOk });
  return new Promise((resolve) => {
    let phase: 'hello' | 'ready' = 'hello', phaseStart = t0, deadline = Math.min(t0 + budget, t0 + cap), needs: string[] = [], done = false;
    const finish = (r: HsResult) => { if (done) return; done = true; clearInterval(tick); off(); resolve(r); };
    const off = ch.onMessage((m) => {
      if (m.name === 'stillLoading') { deadline = Math.min(deadline + step, t0 + cap); return; }
      if (phase === 'hello' && m.name === 'hello') {
        const h = m.body as { id: string; edition: number; needs: string[] };
        needs = h.needs ?? [];
        const w = c.welcome(h);
        if (!w.ok) { ch.send(env(c.edition, 'core', c.appId, 'event', 'incompatible', { reason: w.reason })); return finish({ ok: false, code: 'KV-RU-007', reason: w.reason }); }
        ch.send(env(c.edition, 'core', c.appId, 'event', 'welcome', w.body));
        phase = 'ready'; phaseStart = Date.now(); deadline = Math.min(phaseStart + budget, t0 + cap);   // ready gets a fresh budget
      } else if (phase === 'ready' && m.name === 'ready') finish({ ok: true, needs });
    });
    const tick = setInterval(() => { if (Date.now() > deadline) finish({ ok: false, code: 'KV-RU-001', reason: `no ${phase} within ${Math.round((Date.now() - phaseStart) / 1000)}s` }); }, 250);
    ch.send(env(c.edition, 'core', c.appId, 'event', 'hello', { edition: c.edition, capabilities: c.capabilities, startTimeoutMs: step }));
  });
}
