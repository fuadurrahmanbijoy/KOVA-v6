import { spawn, execFile } from 'node:child_process';
import { hooks } from './debug';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { validateDependencies } from './schema';
export type DepsResult = { ok: true; output: string } | { ok: false; reason: 'invalid-spec' | 'offline' | 'timeout' | 'failed'; output: string; errors?: string[] };
const OFFLINE = /ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET|ETIMEDOUT|network|offline/i;
/** Argument vector for npm (exported for tests). Specs come after `--` so nothing is ever read as an option. */
export function npmArgs(appDir: string, deps: Record<string, string>): string[] {
  const vendor = join(appDir, 'vendor-npm'), common = ['--ignore-scripts', '--no-audit', '--no-fund'];
  if (existsSync(join(vendor, 'package-lock.json'))) return ['ci', ...common, '--prefix', vendor];
  return ['install', ...common, '--no-bin-links', '--no-save', '--prefix', vendor, '--', ...Object.entries(deps).map(([n, v]) => `${n}@${v}`)];
}
function killTree(pid: number | undefined, p: { kill(): boolean }) {
  if (process.platform === 'win32' && pid) execFile('taskkill', ['/pid', String(pid), '/T', '/F'], () => {}); else { try { process.kill(-(pid as number), 'SIGKILL'); } catch { p.kill(); } }
}
export function installDeps(dir: string, deps: Record<string, string>, timeoutMs = 5 * 60_000): Promise<DepsResult> {
  const v = validateDependencies(deps);
  if (!v.ok) return Promise.resolve({ ok: false, reason: 'invalid-spec', output: '', errors: v.errors });
  if (!Object.keys(deps).length) return Promise.resolve({ ok: true, output: '' });
  const npmCli = require.resolve('npm/bin/npm-cli.js');
  return new Promise((resolve) => {
    const args = npmArgs(dir, deps); hooks.onNpmSpawn?.(args);
    const p = spawn(process.execPath, [npmCli, ...args], { env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, windowsHide: true, detached: process.platform !== 'win32' });
    let out = '', timedOut = false; p.stdout!.on('data', (d) => (out += d)); p.stderr!.on('data', (d) => (out += d));
    const t = setTimeout(() => { timedOut = true; killTree(p.pid, p); }, timeoutMs);
    p.on('error', (e) => { clearTimeout(t); resolve({ ok: false, reason: 'failed', output: String(e) }); });
    p.on('close', (c) => { clearTimeout(t); out = out.slice(-4000);
      resolve(c === 0 ? { ok: true, output: out } : { ok: false, reason: timedOut ? 'timeout' : OFFLINE.test(out) ? 'offline' : 'failed', output: out }); });
  });
}
