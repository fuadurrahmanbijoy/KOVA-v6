// Run by e2e.py after bundling with esbuild. Args: kvx1 kvx2 workdir. Prints one JSON line.
import { safeExtract } from '../src/kit/zip';
import { contentFingerprint } from '../src/kit/fingerprint';
import { convertTree } from '../src/kit/convert';
import { mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
(async () => {
  const [k1, k2, work] = process.argv.slice(2); const d1 = join(work, 'v1'), d2 = join(work, 'v2');
  mkdirSync(d1, { recursive: true }); mkdirSync(d2, { recursive: true });
  await safeExtract(k1, d1); await safeExtract(k2, d2);
  const out: Record<string, unknown> = { fpEqual: contentFingerprint(d1) === contentFingerprint(d2) };
  const errs = convertTree(d1); out.convertErrors = errs.length;
  out.backendJs = existsSync(join(d1, 'backend', 'main.js')); out.uiJs = existsSync(join(d1, 'ui', 'app.js'));
  writeFileSync(join(d1, 'package.json'), '{"type":"module"}');   // the Core installs this
  const handlers: Record<string, (...a: any[]) => void> = {}; const sent: unknown[] = []; let ready = 0;
  (globalThis as any).kova = { on: (n: string, f: any) => { handlers[n] = f; }, send: (_to: string, n: string, b: unknown) => sent.push([n, b]), ready: () => { ready++; }, log: () => {}, settings: { get: async (_k: string, d: unknown) => d, set: async () => {} }, storagePath: work, busy: () => {} };
  await import(pathToFileURL(join(d1, 'backend', 'main.js')).href);
  handlers['screen-ready']?.();
  out.ready = ready; out.sent = sent; console.log(JSON.stringify(out));
})().catch((e) => { console.log(JSON.stringify({ error: String(e?.stack ?? e) })); process.exit(1); });
