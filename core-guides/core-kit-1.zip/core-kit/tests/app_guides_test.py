"""Batch 4 acceptance: python tests/app_guides_test.py  (md dir via KOVA_MD, default <kits parent>/md)"""
import os, re, sys, glob, json, hashlib, subprocess, tempfile, pathlib
here = pathlib.Path(__file__).resolve().parent; kit = here.parent; top = kit.parent
MD = pathlib.Path(os.environ.get('KOVA_MD', top / 'md'))
V = kit / 'scripts' / 'verify.py'
core = sorted(glob.glob(str(top / 'core-kit/guides/*.md'))); app = sorted(glob.glob(str(top / 'app-kit/guides/*.md')))
md = sorted(glob.glob(str(MD / 'app-*.md')))
h8 = lambda s: hashlib.sha256(s.encode()).hexdigest()[:8]
BLOCK = re.compile(r'<!-- BEGIN (S2\.\d+) -->\n(.*?)\n<!-- END \1 -->\n`FP:\1:([0-9a-f]{8})`', re.S)
rd = lambda f: open(f, encoding='utf8').read()
res = []
def t(name, ok, why=''): res.append(ok); print(('PASS ' if ok else 'FAIL ') + name + (' ' + why if why and not ok else ''))

# 1 S2 blocks canonical + FP + CONTRACT-FP
canon = {}; bad = []; secs = {}
for f in core + app:
    for m in BLOCK.finditer(rd(f)):
        canon.setdefault(m[1], m[2])
        if canon[m[1]] != m[2]: bad.append(f'{m[1]} in {os.path.basename(f)}')
        if m[3] != h8(m[2]): bad.append(f'FP {m[1]} in {os.path.basename(f)}')
order = sorted(canon, key=lambda s: int(s.split('.')[1]))
cfp = h8(''.join(h8(canon[s]) for s in order))
for f in core + app + md:
    for m in re.finditer(r'CONTRACT-FP:([0-9a-f]{8})', rd(f)):
        if m[1] != cfp: bad.append(f'CONTRACT-FP {m[1]} in {os.path.basename(f)}')
need = {'small-app.md': ['S2.1','S2.2','S2.3','S2.4','S2.5','S2.6','S2.9','S2.10','S2.11'], 'part.md': ['S2.3','S2.4','S2.5','S2.10','S2.11']}
for f in app:
    have = [m[1] for m in BLOCK.finditer(rd(f))]
    for s in need.get(os.path.basename(f), []):
        if s not in have: bad.append(f'{s} missing in {os.path.basename(f)}')
t('s2_blocks_match_canonical_and_fp', not bad and len(order) == 11, '; '.join(bad[:5]))

# 2 no extensionless relative import in code examples
imp = re.compile(r'''(?:from|import)\s*\(?\s*['"](\.{1,2}/[^'"]*|\.{1,2})['"]''')
bad = []
for f in app + md + core:
    for blk in re.findall(r'```[a-z]*\n(.*?)```', rd(f), re.S):
        for m in imp.finditer(blk):
            if not os.path.splitext(m[1])[1] or m[1].endswith('/'): bad.append(f'{os.path.basename(f)}: {m[1]}')
t('no_extensionless_relative_import', not bad, '; '.join(bad[:5]))
t('js_extension_rule_present', all('.js` extension' in rd(f) for f in app if os.path.basename(f) in ('small-app.md', 'part.md', 'profile.md')))

# 3 no real-looking tags
bad = [os.path.basename(f) + ':' + g for f in app + md + core + [str(top / 'app-kit/README.txt')] for g in ('4f9k', '7m2q', '8z6m', 'ab12') if g in rd(f)]
t('no_example_tags', not bad, '; '.join(bad[:5]))

# 4 example blueprint validates
bp = re.search(r'```json\n(.*?)\n```', rd(md[0]), re.S) if md else None
ok = False; why = 'no md'
if bp:
    tag = subprocess.run([sys.executable, str(kit / 'scripts/mint-id.py')], capture_output=True, text=True).stdout.strip()
    d = tempfile.mkdtemp(); p = os.path.join(d, 'bp.json'); open(p, 'w').write(bp[1].replace('<tag>', tag))
    r = subprocess.run([sys.executable, str(V), 'blueprint', p], capture_output=True, text=True, cwd=d)
    ok = r.returncode == 0; why = (r.stdout + r.stderr)[-300:]
t('example_blueprint_valid', ok, why)

# 5 contract across both kits
r = subprocess.run([sys.executable, str(V), 'contract', str(top / 'core-kit/guides'), str(top / 'app-kit/guides')] + ([str(MD)] if md else []), capture_output=True, text=True)
t('verify_contract_both_kits', r.returncode == 0, r.stdout[-300:])
print(f'{sum(res)}/{len(res)}'); sys.exit(0 if all(res) else 1)
