import { show } from './text.js';
const msg = document.getElementById('msg')!;
kova.on('hello', (d: { text: string }) => show(msg, d.text));
kova.send('self', 'screen-ready');
