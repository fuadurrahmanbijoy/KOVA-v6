export const show = (el: HTMLElement, t: string): void => { el.textContent = t; };
