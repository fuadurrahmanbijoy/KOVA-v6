import { greet } from './util.js';
kova.on('screen-ready', () => { kova.send('self', 'hello', { text: greet('Mini') }); });
kova.ready();
