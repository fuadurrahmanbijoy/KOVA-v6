import type { Foundation } from '../kit/seam-types';
const inert = (): any => new Proxy(function () {}, { get: (_t, k) => (k === 'then' ? undefined : inert()), apply: () => inert() });
export function create(): Foundation { return inert() as Foundation; }
