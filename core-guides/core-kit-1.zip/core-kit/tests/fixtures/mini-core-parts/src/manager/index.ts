import type { Foundation } from '../kit/seam-types';
const inert = (): any => new Proxy(function () {}, { get: (_t, k) => (k === 'then' ? undefined : inert()), apply: () => inert() });
export function create(_f?: Foundation): unknown { return inert(); }
