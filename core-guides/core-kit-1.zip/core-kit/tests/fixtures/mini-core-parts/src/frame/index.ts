import type { Foundation, Installer, Runner, Seal, Frame, KitFrame } from '../kit/seam-types';
const inert = (): any => new Proxy(function () {}, { get: (_t, k) => (k === 'then' ? undefined : inert()), apply: () => inert() });
export function create(_s: { foundation: Foundation; installer: Installer; runner: Runner; seal: Seal; window: KitFrame }): Frame { return inert() as Frame; }
