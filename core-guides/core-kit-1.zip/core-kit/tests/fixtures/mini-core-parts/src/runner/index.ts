import type { Foundation, Installer, Runner } from '../kit/seam-types';
const inert = (): any => new Proxy(function () {}, { get: (_t, k) => (k === 'then' ? undefined : inert()), apply: () => inert() });
export function create(_f: Foundation, _i: Installer): Runner { return inert() as Runner; }
