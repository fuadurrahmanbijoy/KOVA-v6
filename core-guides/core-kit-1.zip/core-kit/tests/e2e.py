"""End-to-end gates, no Electron.  python tests/e2e.py   (tools: $KOVA_TOOLS or /tmp/kova-tools with typescript, @types/node, electron, esbuild, yauzl, yazl)"""
import os, sys, json, shutil, subprocess, tempfile, zipfile, pathlib, hashlib, re
here = pathlib.Path(__file__).resolve().parent; KIT = here.parent; FX = here / 'fixtures'; PY = sys.executable
TOOLS = pathlib.Path(os.environ.get('KOVA_TOOLS', '/tmp/kova-tools')); NM = TOOLS / 'node_modules'
OUT = pathlib.Path('/tmp/o'); OUT.mkdir(exist_ok=True); os.environ['KOVA_OUT'] = str(OUT)
if not (NM / '.bin' / 'tsc').exists():
    TOOLS.mkdir(parents=True, exist_ok=True); (TOOLS / 'package.json').write_text('{"name":"t","private":true}')
    subprocess.run(['npm', 'i', '--ignore-scripts', '--no-audit', '--no-fund', 'typescript', '@types/node', 'electron@43', 'esbuild@0.25', 'yauzl', 'yazl'], cwd=TOOLS, capture_output=True)
if not (NM / '.bin' / 'tsc').exists(): print('FAIL tools: could not provision typescript/electron/esbuild (set KOVA_TOOLS)'); sys.exit(2)
ENV = dict(os.environ, KOVA_ESBUILD=str(NM / '.bin' / 'esbuild'), NODE_PATH=str(NM))
res = []; ROOT = pathlib.Path(tempfile.mkdtemp(prefix='kova-e2e-'))
def t(name, ok, why=''): res.append(bool(ok)); print(('PASS ' if ok else 'FAIL ') + name + (' :: ' + str(why)[-400:] if why and not ok else ''))
def run(args, cwd, **k): return subprocess.run([str(a) for a in args], cwd=cwd, capture_output=True, text=True, env=ENV, **k)
def core_copy(name):
    w = ROOT / name; shutil.copytree(KIT, w, ignore=shutil.ignore_patterns('node_modules', '__pycache__', 'fixtures')); (w / 'node_modules').symlink_to(NM, target_is_directory=True); return w
def build_core(name, mutate=None):
    """pack the five mini parts, remove their sources, assemble, add the seal, return the project folder"""
    w = core_copy(name); shutil.copy(FX / 'mini-core-parts/blueprint.json', w / 'blueprint.json'); shutil.copytree(FX / 'mini-core-parts/src', w / 'src', dirs_exist_ok=True)
    up = ROOT / (name + '-up'); up.mkdir()
    for n, f in enumerate(['foundation', 'installer', 'runner', 'frame', 'manager'], 1):
        r = run([PY, 'scripts/pack-part.py', 'core', n, f, '--out', up], w); assert r.returncode == 0, r.stdout + r.stderr
    for f in ['foundation', 'installer', 'runner', 'frame', 'manager', 'seal']: shutil.rmtree(w / 'src' / f)
    shutil.copy(w / 'blueprint.json', up / 'blueprint-mini.json')
    r = run([PY, 'scripts/assemble.py', up, '.', 'core'], w)
    shutil.copytree(FX / 'mini-core-parts/src/seal', w / 'src/seal')
    if mutate: mutate(w)
    return w, r, up

# ---- core flow
w, r, up = build_core('core')
t('assemble_five_parts', r.returncode == 0 and 'MISSING []' in r.stdout, r.stdout + r.stderr)
r = run([PY, 'scripts/verify.py', 'core'], w); t('verify_core_tsc_and_bundles', r.returncode == 0 and 'core: ok' in r.stdout and 'SKIP' not in r.stdout, r.stdout + r.stderr)
bo = ROOT / 'main-bundle.js'; rb0 = run([NM / '.bin' / 'esbuild', 'main.ts', '--bundle', '--platform=node', '--format=cjs', '--target=node20', '--external:electron', '--external:esbuild', '--external:npm', '--external:@fluentui/svg-icons', f'--outfile={bo}', '--log-level=error'], w)
t('main_bundles_with_smoke_guard', rb0.returncode == 0 and bo.exists() and 'KOVA_SMOKE' in bo.read_text() and re.search(r'KOVA_SMOKE\s*===\s*["\']1["\']', bo.read_text()) is not None, rb0.stderr)
r = run([PY, 'scripts/pack-core.py', '--out', OUT], w); t('pack_core_ok', r.returncode == 0 and r.stdout.startswith('OK'), r.stdout + r.stderr)
kc = OUT / 'mini-core-z9t2.kvcore'
if kc.exists():
    names = zipfile.ZipFile(kc).namelist()
    t('kvcore_contents', not [n for n in names if re.match(r'(guides|tests|tools|dist)/', n) or 'node_modules' in n or '__pycache__' in n or n.endswith('.env')] and 'core.json' in names and 'START-HERE.txt' in names and 'main.ts' in names, names[:8])
else: t('kvcore_contents', False, 'no .kvcore')

# ---- negatives (core)
w2, _, _ = build_core('neg-page', lambda w: (w / 'src/manager/ui/pages/busy.ts').unlink())
r = run([PY, 'scripts/verify.py', 'core'], w2); t('neg_missing_page_id', r.returncode != 0 and 'busy' in r.stdout, r.stdout)
w3, _, _ = build_core('neg-kit', lambda w: open(w / 'src/kit/atomic.ts', 'a').write('\n// tampered\n'))
r = run([PY, 'scripts/verify.py', 'core'], w3); t('neg_tampered_kit_file', r.returncode != 0 and 'kit' in r.stdout, r.stdout)
w4 = core_copy('neg-path'); shutil.copy(FX / 'mini-core-parts/blueprint.json', w4 / 'blueprint.json'); up4 = ROOT / 'neg-path-up'; up4.mkdir(); shutil.copy(w4 / 'blueprint.json', up4 / 'blueprint-mini.json')
with zipfile.ZipFile(up4 / 'part-1-of-5-mini-core-z9t2.kvpart', 'w') as z:
    z.writestr('part.json', json.dumps({'kind': 'core', 'setId': 'mini-core-z9t2', 'part': 1, 'buildStamp': '1'})); z.writestr('src/foundation/../../main.ts', 'evil')
tgt = ROOT / 'neg-path-tgt'; tgt.mkdir(); r = run([PY, 'scripts/assemble.py', up4, tgt, 'core'], w4)
t('neg_hostile_part_path', r.returncode != 0 and not any(tgt.rglob('*.ts')) and not (tgt / 'main.ts').exists(), r.stdout + r.stderr)

# ---- negatives (app / contract)
def app_dir(name, mutate=None):
    d = ROOT / name; shutil.copytree(FX / 'mini-app', d / 'app'); shutil.copytree(KIT / 'scripts', d / 'scripts', ignore=shutil.ignore_patterns('__pycache__'))
    if mutate: mutate(d / 'app')
    return d
d = app_dir('app-ok'); r = run([PY, 'scripts/verify.py', 'app'], d); t('verify_app_valid_fixture', r.returncode == 0 and 'app: ok' in r.stdout, r.stdout)
d = app_dir('app-bad', lambda a: (a / 'backend/main.ts').write_text((a / 'backend/main.ts').read_text().replace("'./util.js'", "'./util'")))
r = run([PY, 'scripts/verify.py', 'app'], d); t('neg_extensionless_import', r.returncode != 0 and 'extensionless' in r.stdout, r.stdout)
bp = {'setId': 'kitush-torrent-client-z9t2', 'name': 'Kitush', 'type': 'torrent client', 'parts': [{'n': 1, 'owns': ['backend/**'], 'exports': []}, {'n': 2, 'owns': ['backend/**', 'ui/**'], 'exports': []}, {'n': 3, 'owns': ['x/**'], 'exports': []}]}
(ROOT / 'bp.json').write_text(json.dumps(bp)); r = run([PY, 'scripts/verify.py', 'blueprint', ROOT / 'bp.json'], ROOT / 'app-ok'); t('neg_overlapping_owns', r.returncode != 0 and 'appears in parts' in r.stdout, r.stdout)
gd = ROOT / 'g'; gd.mkdir(); src = next(pathlib.Path(KIT / 'guides').glob('part-3-runner.md')).read_text(encoding='utf8'); (gd / 'g.md').write_text(src.replace('Untrusted input:', 'Untrusted inputs:', 1), encoding='utf8')
r = run([PY, 'scripts/verify.py', 'fp', gd / 'g.md'], KIT); t('neg_stale_fp', r.returncode != 0 and 'FAIL' in r.stdout, r.stdout)

# ---- app flow
a = FX / 'mini-app'; before = hashlib.sha256((a / 'kova.json').read_bytes()).hexdigest(); o1, o2 = ROOT / 'o1', ROOT / 'o2'
r1 = run([PY, 'scripts/pack-kvx.py', a, '--out', o1], KIT); r2 = run([PY, 'scripts/pack-kvx.py', a, '--out', o2], KIT)
k1, k2 = o1 / 'mini-probe-k3x9.kvx', o2 / 'mini-probe-k3x9.kvx'
stamp = lambda k: int(json.loads(zipfile.ZipFile(k).read('kova.json'))['buildStamp'])
t('pack_kvx_twice_stamp_increases', r1.returncode == 0 and r2.returncode == 0 and stamp(k2) > stamp(k1), r1.stdout + r1.stderr + r2.stdout + r2.stderr)
t('pack_kvx_source_unchanged', hashlib.sha256((a / 'kova.json').read_bytes()).hexdigest() == before)
bundle = ROOT / 'appflow.cjs'
rb = run([NM / '.bin' / 'esbuild', here / 'e2e_appflow.ts', '--bundle', '--platform=node', '--format=cjs', '--external:yauzl', '--external:yazl', '--external:esbuild', f'--outfile={bundle}', '--log-level=error'], KIT)
rn = run(['node', bundle, k1, k2, ROOT / 'flow'], ROOT) if rb.returncode == 0 else rb
try: j = json.loads(rn.stdout.strip().splitlines()[-1])
except Exception: j = {'error': rn.stdout + rn.stderr}
t('safeExtract_fingerprint_equal_across_stamps', j.get('fpEqual') is True, j)
t('convert_clean_and_js_written', j.get('convertErrors') == 0 and j.get('backendJs') and j.get('uiJs'), j)
t('backend_runs_in_node_esm_with_stub_kova', j.get('ready') == 1 and j.get('sent') == [['hello', {'text': 'hello Mini'}]], j)
print(f'{sum(res)} passed / {len(res)} total'); shutil.rmtree(ROOT, ignore_errors=True); sys.exit(0 if all(res) else 1)
