# CORE PART 1 OF 5 · FOUNDATION · edition 2
`contract edition: 2` · `CONTRACT-FP:7da9cd3b`. You were sent here by `core-2-build-parts.md`; its rules (token rules, no stamps, never draw icons) apply. Read only this file.

---
## [S2] CONTRACT EXCERPT
> Identical to the same sub-sections in every Kova guide. Each has a fingerprint; a missing one means a partial paste: stop and tell the person.

### [S2.6] Identity, stamps, versions
<!-- BEGIN S2.6 -->
- **Layers:** `id` (lineage), `buildStamp` (ordering), `versionLabel` (display only).
- **Stamp parsing:** a plain 13-digit number is epoch milliseconds (UTC), larger means newer; optional and never required; otherwise year-first only (`2026-10-06_1430`, `20261006T143015Z`, `2026/10/06 14:30`); year 2000 to 2100; missing parts zero; no timezone means local; `Z` means UTC. Anything else is a **label**, ordered by install time.
- **Newer wins** by parsed time, else by install time. A parsed stamp more than 1 day in the future, or more than 1 day away from the zip's inner file dates, triggers the suspicious-date question with both dates in plain words. Never guess.
- **Identical:** equal content fingerprint (sha-256 over relative paths and bytes) means identical, whatever the stamp says.
- **Outcomes:** newer → install and activate; identical → ask; older → ask ("install alongside and make active?"); same `id` but very different name or description → ask "update, or a different app?".
- **Every version is kept**, one active at a time; switching and removing are the person's choice. Saved data lives per `id` outside every version and survives all of it. A data snapshot is taken whenever the active version changes.
<!-- END S2.6 -->
`FP:S2.6:b1256106`

### [S2.7] Profile files
<!-- BEGIN S2.7 -->
Folder `<Library>\profile\`. Only a Profile app writes it. The Core reads it, watches it, relays basics.
- `basics.json`: `{ format:1, nickname, mode:'light'|'dark'|'system', accent:'#RRGGBB', language, timeZone, dateFormat, clock, railLabels:true, topBar:false }`
- `personal.json`: `{ format:1, fullName, email, birthday, location, bio, custom:{}, share:{ basics:true, personal:false } }`
- `avatar.<png|jpg|webp>`

Defaults (no files): light, accent `#0F6CBD`, labels on. The Core relays `mode` already resolved (`system` → light/dark) and never relays `personal.json`. Unknown fields are kept. A newer `format` is read, not written. A damaged file never blocks startup: use defaults, keep the file, `KV-PR-001`. (`topBar` is stored for compatibility; the Core has no top bar and ignores it.)
<!-- END S2.7 -->
`FP:S2.7:8a613fac`

### [S2.8] Errors, message bank, repair note
<!-- BEGIN S2.8 -->
**Codes:** `KV-<IN|RU|PT|LB|CR|PR>-nnn`, never reused. Every failure ends as *nothing changed*, *rolled back*, or *paused with a repair note*, and the person is told which.

**Bank entry:** `headline`, `whatHappened`, `safety`, `steps` (ends with "Copy repair note" unless the entry says no note), `serious` (calm tone), `outcome`, `repairHint`. Cores may restyle the screen, never the text. Tone: playful, mischievous, dramatic; one or two lines; never blames the person; always says what to do; calm for deleting or data loss.

**Repair note, fixed order:** 1) role line; 2) scope lock (which part only; what stays fixed); 3) identity (name, id, old buildStamp, edition, Core capabilities); 4) new build stamp (the Core's real clock, epoch milliseconds, later than the old one); 5) errors, each with stage, code, rule, expected vs found, location, concrete fix, all at once; 6) evidence (log tail, message tail, stack traces mapped to original `.ts` lines); 7) the violated guide rules, embedded; 8) output rule (complete files, not diffs; an app comes back as a finished `<id>.kvx` packed with the kit script, a Core part as a replacement `part-N-of-5-<id>.kvpart`, named by S2.9). First line names the part to fix and the parts to leave alone; if unsure it says so and lists the likeliest part first. **Repair bundle:** next to the note the Core writes `<id>-repair.zip`: `repair-note.txt` (the full prompt), every failing file, the app's whole folder if under 2 MB, and the Blueprint if there is one. The prompt tells the person to upload the bundle and the kit zip in **any new chat**; the original chat is never needed. The Core's Repair center shows: what happened (plain words), the list of unloadable files with the reason for each, the full prompt with a Copy button, the files to upload (the bundle, with a Save button), and numbered next steps. Redact Windows user names, home paths, tokens, profile fields. Most important lines first; trim long logs.
<!-- END S2.8 -->
`FP:S2.8:c74f4d35`

### [S2.9] Packages, parts, naming
<!-- BEGIN S2.9 -->
- **Files:** `.kvx` app, `.kvcore` Core package, `.kvlib` Library backup, `.kvpart` one part of a Set. All are zips. The Core checks the inside, never the extension or filename.
- **Naming (no dates or stamps in file names):** app `<id>.kvx` (e.g. `nova-md-reader-7m2q.kvx`); Core `<name>-core-<tag>.kvcore` and `<name>-core-<tag>-run.zip`; part `part-<N>-of-<M>-<id>.kvpart` (e.g. `part-2-of-6-nova-core-8z6m.kvpart`); Blueprint `blueprint-<id>.json`; Style Spec `<id>-style-spec.md`; backup `kova-library.kvlib`. The Core reads the inside of a file, never its name.
- **`.kvpart`** holds `part.json` `{ setId, part, total, buildStamp, kind:'app'|'core', wiring:boolean }` plus that part's files. **Parts never share a file.** Combining is unzipping into one place. Wiring files belong to exactly one part.
- **Blueprint** `blueprint.json`: `{ setId, buildStamp, name, type, plan, parts:[{ n, title, owns:[globs], exports:[...], needs:[...] }], wiring, requestCard }`. Every part is built with it attached.
- **Waiting area:** an incomplete Set waits ("Two of four performers have arrived"); the person can discard it. Same part twice → identical/older/newer rule. Parts of different Sets are refused, naming the strangers. A **replacement part** carries a newer stamp and the part number it replaces. A complete Set can be exported as one `.kvx`.
<!-- END S2.9 -->
`FP:S2.9:ef3c6a22`

---
## YOUR PART · 1. Foundation
**Project folder `proj/`.** `main.ts`, `scripts/`, `assets/`, `src/kit/` come from the kit. Each part owns only `src/<part>/`: `index.ts`, `seam.json` (`{"part":"<name>","entry":"index.ts"}`), `deps.json` (`{"dependencies":{}}`), plus `ui/` and `preload-*.ts` where listed. Export `create(...)` exactly as `src/kit/seam-types.ts` says: that file is the only description of the neighbours you need. **`main.ts` creates the window and its autohide controls (kit); parts never create windows.** Do not write stand-ins and do not compile against neighbours. Renderer files: `src/<part>/ui/renderer-<name>.ts`, `*.html`, `*.css`; preloads: `src/<part>/preload-<name>.ts`. **`main.ts` already registers the IPC handlers `kova:icon` and `kova:call` and the window handlers: never register them again.**
**Fixed page ids (Frame and Manager agree on these):** `home`, `app` (argument = app id), `busy`, `settings`. Page files live in `src/manager/ui/pages/<id>.ts`, `export default { id, render(root: HTMLElement, arg?: any): void | (() => void) }`; `scripts/setup.mjs` generates `src/generated/pages.ts` (`pages` map) from them.

Use kit: `stamp`, `fingerprint`, `redact`, `atomic`, `handoff`. Library root `C:\Kova` (short; flat hashed folders; root remembered in `C:\Kova\root.json` = `{"root":"<path>"}`):
`library.json` index · `runtime\marker.json` `{next,previous,lastGood,pendingFirstStart,failStreak}` · `cores\` · `apps\<id>\{app.json,v\<key>\,data\,snapshots\}` · `staging\ waiting\ trash\ backups\ guides\ profile\ logs\`.

| ID | Do |
|---|---|
| P1-1 | `create(): Foundation` per seam-types. `paths`, `index` (atomic writes), `log` (capped rolling file + memory tail), `settings` (key/value file). |
| P1-2 | Open/create Library; `format` newer than known → refuse, change nothing, `KV-LB-001`. First time a new Core touches it: full backup copy. |
| P1-3 | Verify index vs folders; mismatch → rebuild by scanning, keep the broken file (`KV-LB-002`). Drive missing → pause, calm message, never create a new empty Library silently (`KV-LB-003`). |
| P1-4 | Recovery every launch: discard leftover `staging\`, process `trash\` (`KV-LB-004`, `KV-LB-005`), one short line. |
| P1-5 | Safe Mode: `recordLaunch`; 3 failed launches in a row → all apps off (`KV-CR-004`); `request()` for manual. |
| P1-6 | `bank` generated from S10 exactly. `repair.forApp/forCore/diagnostics` per S2.8 and S14, using `redact` (include profile values). Part-aware first line. |
| P1-7 | `profile.read/onChange`: read `profile\basics.json` (S2.7), watch it, defaults if absent or damaged (`KV-PR-001`), resolve `system` mode via the OS. Never read `personal.json` here. |
| P1-8 | `space.check` (disk) before staging; size ceiling prompt 2 GB is the Installer's job. |
| P1-9 | `quit`: `request()` asks `onRequest` handler; handler returns `cancel|force|background|ok`; `markStartedOk()` writes `lastGood`, clears `pendingFirstStart`. Windows shutdown = closing, shortened if Windows demands. |
| P1-10 | No telemetry of any kind. |
| P1-11 | A repair note's new build stamp is `Date.now()` (epoch milliseconds). File names follow S2.9 (no stamps in names). |
| P1-12 | `repair.bundle` writes `<Library>\repairs\<id>-repair.zip` (S2.8: note, failing files, whole app folder if under 2 MB); `repair.files` returns the unloadable files with reasons. The prompt inside the note tells the person to upload the bundle and the kit zip (`core-kit.zip` or `app-kit.zip`) in ANY new chat and gives the numbered next steps (apps: drop the new `.kvx` onto Kova; Core: `node scripts/apply-part.mjs <file>` then `npm start`). |

---
## Error codes and message bank
Generate `messages.json` from this table exactly: `{ "<code>": { headline, whatHappened, safety, steps, serious, outcome, repairHint } }`. Every `steps` ends with "Copy repair note" unless marked (no note). Default `safety`: "Your files are safe, and your other apps are fine."

| Code | Headline | What happened | Outcome | Serious |
|---|---|---|---|---|
| KV-IN-001 | This file arrived in pieces. | The file is damaged and could not be opened. Get a fresh copy. (no note) | nothing-changed | no |
| KV-IN-002 | Wrong door! | This looks like a {kind}, not a {expected}. Offer to open it the right way. (no note) | nothing-changed | no |
| KV-IN-003 | An app with no ID card. | The ID card (`kova.json`) is missing or unreadable. | nothing-changed | no |
| KV-IN-004 | The ID card has a few typos. | {n} problems found in the ID card, all listed in the note. | nothing-changed | no |
| KV-IN-005 | The front door is missing. | The first screen file {entry} is not in the zip. | nothing-changed | no |
| KV-IN-006 | Identity crisis. | The ID does not match the app's name and type. | nothing-changed | no |
| KV-IN-007 | The translator tripped. | A TypeScript file could not be converted: {file}:{line}. | nothing-changed | no |
| KV-IN-008 | The pantry is out of reach. | This app needs to fetch libraries and could not. Retry, or ask your AI to bundle them. | nothing-changed | no |
| KV-IN-009 | Not enough room backstage. | This needs about {need}; you have {have}. Free some space. (no note) | nothing-changed | no |
| KV-IN-010 | Windows security may be holding this one back. | A file looks quarantined or blocked. Check Windows Security's protection history. | nothing-changed | no |
| KV-IN-011 | That is a big one. | The file is larger than {limit}. Install anyway? (prompt only) | nothing-changed | no |
| KV-IN-012 | The calendar looks suspicious. | The build stamp says {a}; the files say {b}. Which is right? (prompt only) | nothing-changed | no |
| KV-IN-013 | (twin) | Identical version already installed. Prompt. | nothing-changed | no |
| KV-IN-014 | (visitor from the past) | Older version. Prompt. | nothing-changed | no |
| KV-IN-015 | Same name, different app? | Is this an update of {a}, or a different app? Prompt. | nothing-changed | no |
| KV-RU-001 | Stage fright! | {name} never said it was ready. | rolled-back | no |
| KV-RU-002 | Plot twist! {name} collapsed on stage. | It stopped right after starting. | rolled-back | no |
| KV-RU-003 | Paused, so it stops draining your PC. | {name} crashed several times in a row. | paused | no |
| KV-RU-004 | It will not take a hint. | {name} ignored the stop signal and was stopped. | nothing-changed | no |
| KV-RU-005 | Nobody picked up. | A request got no answer. (log only) | nothing-changed | no |
| KV-RU-006 | {name} is hogging the stage. | High memory or processor use. See What's busy. | nothing-changed | no |
| KV-RU-007 | Too ambitious for this Core. | The app needs edition {n}; this Core speaks {m}. | nothing-changed | no |
| KV-RU-008 | A missing prop. | The app wanted {feature}, which this Core lacks. It still runs. | nothing-changed | no |
| KV-PT-001 | Waiting for performers. | {x} of {y} parts have arrived. (no note) | paused | no |
| KV-PT-002 | Strangers in the cast. | Parts from different Sets cannot be combined: {list}. | nothing-changed | no |
| KV-PT-003 | The parts do not meet in the middle. | Parts {a} and {b} do not connect. | nothing-changed | no |
| KV-PT-004 | Two parts claim one file. | {file} appears in parts {a} and {b}. | nothing-changed | no |
| KV-PT-005 | Part seen twice. | Identical/older/newer prompt applies. | nothing-changed | no |
| KV-LB-001 | This Core is too old for your Library. | The Library is newer than this Core understands. Nothing was changed. (no note) | nothing-changed | yes |
| KV-LB-002 | The Library's index got tangled. | Rebuilt by scanning; the broken file is kept. | rolled-back | yes |
| KV-LB-003 | The Library has wandered off. | Its drive is not reachable. Reconnect it. (no note) | paused | yes |
| KV-LB-004 | Stuck for now. | A file is in use; removal is scheduled for next launch. | nothing-changed | yes |
| KV-LB-005 | An interrupted installation. | Cleaned up. Nothing was harmed. (no note) | rolled-back | no |
| KV-CR-001 | The Core upgrade was interrupted. | The previous Core stays active. | rolled-back | no |
| KV-CR-002 | The new Core could not take the stage. | We returned to the previous Core. | rolled-back | no |
| KV-CR-003 | This Core dreams of a newer Runtime. | Installed, but not activated. | nothing-changed | no |
| KV-CR-004 | Quiet mode. | Everything is switched off. Turn things on one by one. | paused | no |
| KV-CR-005 | Not a valid Core. | The package is missing parts of its identity. | nothing-changed | no |
| KV-PR-001 | The profile is scrambled. | Defaults are in use; the broken file is kept. | rolled-back | yes |
| KV-PR-002 | The avatar will not load. | Showing the default picture. | nothing-changed | no |

`repairHint` for each code: one sentence naming the violated rule plus the S2 sub-section label, e.g. "ID card field `type` is required (S2.1)".

## Dictionary and voice
One word per thing: **Core**, **App**, **Library**, **repair note**, **request card**, **snapshot**, **Safe mode**, **backup file**, **Part / Set / Blueprint / Seal**. Voice: playful, mischievous, dramatic; one or two lines; blame the app, never the person; always say what to do; calm for deleting or data loss.
| Moment | Text |
|---|---|
| Installed | "It lives! {name} is now part of your Core. Go on, say hello." |
| Same version | "Ooh, a twin! You already have this exact one. Install it anyway, or pretend this never happened?" |
| Older version | "A visitor from the past! This one is older than what you have. Invite it in as an extra version?" |
| App needs newer Core | "This app is too ambitious for this Core. It dreams of features we don't have yet." |
| Quit while busy | "Hold the curtain! {n} apps are still mid-performance. Cancel quit, force quit, or let them carry on in the background?" |
| Removing (calm) | "You're about to remove version {label} of {name}. Its saved data can stay or go. What would you like to do with it?" |
| Waiting for parts | "{x} of {y} performers have arrived. Waiting for parts {list}." |
| Restart choice | "{Core} is ready. Take the stage now, or switch next time?" |
| Empty apps page | "The stage is empty. Drop a .kvx here and watch the magic." |

---
## OPTIONAL CHECK
Optional, **only after** the files are packed and presented, and only if `npx` works here: `npx esbuild src/foundation/index.ts --bundle --platform=node --external:electron --external:esbuild --external:npm --external:@fluentui/svg-icons --outfile=/tmp/x.js --log-level=error 2>&1 | tail -n 10`. Errors in your files → fix only those lines, re-pack, stop. Any network or tooling error → skip silently. One attempt, never launch the app.

---
## PACK AND REPLY
`python scripts/pack-part.py core 1 foundation` (writes `part-1-of-5-<id>.kvpart` into the outputs folder). Then reply exactly (max 10 lines, no code, no recap):
```
Done: Part 1 Foundation, <n> files → part-1-of-5-<id>.kvpart
Not done: <requirement IDs, or "nothing">
NEXT STEPS
1. Download the file above and keep it.
2. Build the other parts, one new chat each: upload core-kit.zip, blueprint-<id>.json and core-2-build-parts.md, then say "part <N>".
3. After all five exist: new chat with core-3-seal-parts.md, core-kit.zip, blueprint-<id>.json and the five part files.
```
`kova-core-part-1`
