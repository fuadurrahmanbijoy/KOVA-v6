# CORE PART 2 OF 5 · INSTALLER · edition 2
`contract edition: 2` · `CONTRACT-FP:7da9cd3b`. You were sent here by `core-2-build-parts.md`; its rules (token rules, no stamps, never draw icons) apply. Read only this file.

---
## [S2] CONTRACT EXCERPT
> Identical to the same sub-sections in every Kova guide. Each has a fingerprint; a missing one means a partial paste: stop and tell the person.

### [S2.1] ID card
<!-- BEGIN S2.1 -->
Every app zip has `kova.json` at its root.

**Required (3):** `name` (short brand name: "Nova"), `type` ("md reader", "music player"), `edition` (whole number, currently 2). **`buildStamp` is optional**: the pack scripts add the current time in epoch milliseconds (e.g. `1760000000000`); the Core uses install time when it is absent or unreadable. Nobody is ever asked for a stamp.

**`id`** is `<name-slug>-<type-slug>-<tag>`, e.g. `nova-md-reader-7m2q`. The tag is 4 random `a-z0-9`, made once and kept through every update. The Core rejects an `id` whose front part does not match name and type.

**Optional** (default): `buildStamp` (added by the packer), `versionLabel` (none), `description` (none), `icon` (Fluent icon name only; generic), `entry` (`ui/index.html`), `backend` (auto-detected `backend/main.ts|js`), `dependencies` (`{ "name": "semver" }`; none), `runsInBackground` (true if backend exists), `startsWithCore` (false), `followsCoreTheme` (true), `sizeHint` (`compact|regular|large`; regular), `needs` (capability names; none), `opens` (`["file:md","link:https"]`; none), `announces`, `answers` (message names; none), `worksBetterWith` (soft hints; none), `set` (`{ setId, part, total, wiring }` for chunked apps).

Rules: unknown fields are ignored with a log note, never an error. Report all problems at once. Paths are relative and stay inside the zip. A zip may hold `.ts`, `.js`, `.mjs`, `.html`, `.css`, assets and a `vendor/` folder.
<!-- END S2.1 -->
`FP:S2.1:682deafe`

### [S2.5] Messaging and capabilities
<!-- BEGIN S2.5 -->
- **Open:** hand over a file or link. The Core finds apps whose `opens` match (`file:<ext>`, `link:http`, `link:https`, `link:magnet`); if several match it asks the person, with an "always use this one" tick (remembered, changeable). The chosen app receives the event `open` with `{ file?, url?, text? }` via `kova.on('open', fn)`, in its backend if it has one, otherwise in its screen.
- **Announce:** one-way. **Ask:** request with reply; default timeout 5 s; "nobody answering" is a normal reply, not an error.
- **Names:** starter vocabulary (`media.nowPlaying`, `media.control`, `download.start`, `download.finished`, `download.progress`, `alarm.ringing`, `alarm.dismissed`, `file.selected`, `link.clicked`, `note.created`, `calendar.eventSoon`, `clipboard.changed`) or a name starting with the app's own `id`. Others only draw a log warning.
- **No hard dependencies:** an app must start alone.
- **Capabilities (closed list):** `tray`, `status`, `blocklist`, `globalShortcuts`. Always present: `notify`, `openLink`, `settings`, `log`, `icon`. Unknown names mean "not supported", never an error.
<!-- END S2.5 -->
`FP:S2.5:af1b72cd`

### [S2.6] Identity, stamps, versions
<!-- BEGIN S2.6 -->
- **Layers:** `id` (lineage), `buildStamp` (ordering), `versionLabel` (display only).
- **Stamp parsing:** a plain 13-digit number is epoch milliseconds (UTC), larger means newer; optional and never required; otherwise year-first only (`2026-10-06_1430`, `20261006T143015Z`, `2026/10/06 14:30`); year 2000 to 2100; missing parts zero; no timezone means local; `Z` means UTC. Anything else is a **label**, ordered by install time.
- **Newer wins** by parsed time, else by install time. A parsed stamp more than 1 day in the future, or more than 1 day away from the zip's inner file dates, triggers the suspicious-date question with both dates in plain words. Never guess.
- **Identical:** equal content fingerprint (sha-256 over relative paths and bytes) means identical, whatever the stamp says.
- **Outcomes:** newer → install and activate; identical → ask; older → ask ("install alongside and make active?"); same `id` but very different name or description → ask "update, or a different app?".
- **Every version is kept**, one active at a time; switching and removing are the person's choice. Saved data lives per `id` outside every version and survives all of it. A data snapshot is taken whenever the active version changes.
<!-- END S2.6 -->
`FP:S2.6:b1256106`

### [S2.9] Packages, parts, naming
<!-- BEGIN S2.9 -->
- **Files:** `.kvx` app, `.kvcore` Core package, `.kvlib` Library backup, `.kvpart` one part of a Set. All are zips. The Core checks the inside, never the extension or filename.
- **Naming (no dates or stamps in file names):** app `<id>.kvx` (e.g. `nova-md-reader-7m2q.kvx`); Core `<name>-core-<tag>.kvcore` and `<name>-core-<tag>-run.zip`; part `part-<N>-of-<M>-<id>.kvpart` (e.g. `part-2-of-6-nova-core-8z6m.kvpart`); Blueprint `blueprint-<id>.json`; Style Spec `<id>-style-spec.md`; backup `kova-library.kvlib`. The Core reads the inside of a file, never its name.
- **`.kvpart`** holds `part.json` `{ setId, part, total, buildStamp, kind:'app'|'core', wiring:boolean }` plus that part's files. **Parts never share a file.** Combining is unzipping into one place. Wiring files belong to exactly one part.
- **Blueprint** `blueprint.json`: `{ setId, buildStamp, name, type, plan, parts:[{ n, title, owns:[globs], exports:[...], needs:[...] }], wiring, requestCard }`. Every part is built with it attached.
- **Waiting area:** an incomplete Set waits ("Two of four performers have arrived"); the person can discard it. Same part twice → identical/older/newer rule. Parts of different Sets are refused, naming the strangers. A **replacement part** carries a newer stamp and the part number it replaces. A complete Set can be exported as one `.kvx`.
<!-- END S2.9 -->
`FP:S2.9:ef3c6a22`

---
## YOUR PART · 2. Installer
**Project folder `proj/`.** `main.ts`, `scripts/`, `assets/`, `src/kit/` come from the kit. Each part owns only `src/<part>/`: `index.ts`, `seam.json` (`{"part":"<name>","entry":"index.ts"}`), `deps.json` (`{"dependencies":{}}`), plus `ui/` and `preload-*.ts` where listed. Export `create(...)` exactly as `src/kit/seam-types.ts` says: that file is the only description of the neighbours you need. **`main.ts` creates the window and its autohide controls (kit); parts never create windows.** Do not write stand-ins and do not compile against neighbours. Renderer files: `src/<part>/ui/renderer-<name>.ts`, `*.html`, `*.css`; preloads: `src/<part>/preload-<name>.ts`. **`main.ts` already registers the IPC handlers `kova:icon` and `kova:call` and the window handlers: never register them again.**
**Fixed page ids (Frame and Manager agree on these):** `home`, `app` (argument = app id), `busy`, `settings`. Page files live in `src/manager/ui/pages/<id>.ts`, `export default { id, render(root: HTMLElement, arg?: any): void | (() => void) }`; `scripts/setup.mjs` generates `src/generated/pages.ts` (`pages` map) from them.

Use kit: `convert`, `deps`, `stamp`, `fingerprint`, `atomic`.
| ID | Do |
|---|---|
| P2-1 | `create(f): Installer`. `install(files, ui)`: several files give one combined result. |
| P2-2 | Pipeline in staging, in order: identify by inside (wrong kind → `KV-IN-002` with offer) → unzip → read `kova.json`, validate **all** fields at once (`KV-IN-003..006`) → fingerprint, stamp compare, collisions (`KV-IN-012..015`, prompts through `ui.choose`) → `convertTree` (`KV-IN-007`) → `installDeps` unless bundled (`KV-IN-008`) → disk check (`KV-IN-009`) → one atomic commit → set active. Never write into `data\`. Antivirus symptoms → `KV-IN-010`. |
| P2-3 | Parts: group `.kvpart` by `setId` in `waiting\`; assemble when complete; refuse mixed Sets; replacement parts; seam failure fails in staging naming both parts (`KV-PT-001..005`); `exportSet` as one `.kvx`. |
| P2-4 | `apps.*`: list/get/summary (what the app says it will do), enable, auto-start, remove (stop first; locked → schedule in `trash\`). Build `AppInfo` fully (versions, bytes, data size). |
| P2-5 | `versions.*`: switch (snapshot data first), remove (choose data), snapshots, restore. Failed new version → previous reactivated automatically. |
| P2-6 | `defaults.*`: remembered "open with" choices per kind. |
Emit `emit('apps.changed')` (kit `rpc`) after every change.
| P2-7 | Read everything from inside the files; never rely on file names. Accept any `.kvx/.kvpart/.kvcore/.kvlib` name. |

---
## Error codes you raise
| Code | Headline | What happened |
|---|---|---|
| KV-IN-001 | This file arrived in pieces. | The file is damaged and could not be opened. Get a fresh copy. (no note) |
| KV-IN-002 | Wrong door! | This looks like a {kind}, not a {expected}. Offer to open it the right way. (no note) |
| KV-IN-003 | An app with no ID card. | The ID card (`kova.json`) is missing or unreadable. |
| KV-IN-004 | The ID card has a few typos. | {n} problems found in the ID card, all listed in the note. |
| KV-IN-005 | The front door is missing. | The first screen file {entry} is not in the zip. |
| KV-IN-006 | Identity crisis. | The ID does not match the app's name and type. |
| KV-IN-007 | The translator tripped. | A TypeScript file could not be converted: {file}:{line}. |
| KV-IN-008 | The pantry is out of reach. | This app needs to fetch libraries and could not. Retry, or ask your AI to bundle them. |
| KV-IN-009 | Not enough room backstage. | This needs about {need}; you have {have}. Free some space. (no note) |
| KV-IN-010 | Windows security may be holding this one back. | A file looks quarantined or blocked. Check Windows Security's protection history. |
| KV-IN-011 | That is a big one. | The file is larger than {limit}. Install anyway? (prompt only) |
| KV-IN-012 | The calendar looks suspicious. | The build stamp says {a}; the files say {b}. Which is right? (prompt only) |
| KV-IN-013 | (twin) | Identical version already installed. Prompt. |
| KV-IN-014 | (visitor from the past) | Older version. Prompt. |
| KV-IN-015 | Same name, different app? | Is this an update of {a}, or a different app? Prompt. |
| KV-PT-001 | Waiting for performers. | {x} of {y} parts have arrived. (no note) |
| KV-PT-002 | Strangers in the cast. | Parts from different Sets cannot be combined: {list}. |
| KV-PT-003 | The parts do not meet in the middle. | Parts {a} and {b} do not connect. |
| KV-PT-004 | Two parts claim one file. | {file} appears in parts {a} and {b}. |
| KV-PT-005 | Part seen twice. | Identical/older/newer prompt applies. |

---
## OPTIONAL CHECK
Optional, **only after** the files are packed and presented, and only if `npx` works here: `npx esbuild src/installer/index.ts --bundle --platform=node --external:electron --external:esbuild --external:npm --external:@fluentui/svg-icons --outfile=/tmp/x.js --log-level=error 2>&1 | tail -n 10`. Errors in your files → fix only those lines, re-pack, stop. Any network or tooling error → skip silently. One attempt, never launch the app.

---
## PACK AND REPLY
`python scripts/pack-part.py core 2 installer` (writes `part-2-of-5-<id>.kvpart` into the outputs folder). Then reply exactly (max 10 lines, no code, no recap):
```
Done: Part 2 Installer, <n> files → part-2-of-5-<id>.kvpart
Not done: <requirement IDs, or "nothing">
NEXT STEPS
1. Download the file above and keep it.
2. Build the other parts, one new chat each: upload core-kit.zip, blueprint-<id>.json and core-2-build-parts.md, then say "part <N>".
3. After all five exist: new chat with core-3-seal-parts.md, core-kit.zip, blueprint-<id>.json and the five part files.
```
`kova-core-part-2`
