# CORE PART 3 OF 5 · RUNNER · edition 2
`contract edition: 2` · `CONTRACT-FP:7da9cd3b`. You were sent here by `core-2-build-parts.md`; its rules (token rules, no stamps, never draw icons) apply. Read only this file.

---
## [S2] CONTRACT EXCERPT
> Identical to the same sub-sections in every Kova guide. Each has a fingerprint; a missing one means a partial paste: stop and tell the person.

### [S2.2] Envelope and handshake
<!-- BEGIN S2.2 -->
**Envelope:** `{ v, id, from, to, kind, name, body, time, replyTo? }`. `v` is the contract edition; `kind` is `event`, `request` or `reply`; a reply sets `replyTo` to the request's `id`.

**Handshake** (Core drives): 1) Core→app `hello` `{ edition, capabilities[], startTimeoutMs }`; 2) app→Core `hello` `{ id, edition, needs[] }`; 3) Core→app `welcome` `{ storagePath, profile, mode, shape, previousBuild|null }`, or `incompatible` `{ reason }`; 4) app→Core `ready`.

The app may send `stillLoading` before `ready`. Default wait 10 s; each `stillLoading` adds 10 s, capped at 120 s. No `ready` in time is `KV-RU-001`. The app never sees the transport; it uses `kova`. The Core keeps the last 300 redacted messages per app for repair notes.
<!-- END S2.2 -->
`FP:S2.2:e679ca93`

### [S2.3] The `kova` toolbox
<!-- BEGIN S2.3 -->
The Core injects one global, `kova`, into each app's backend and screen. Apps import nothing. Everything else (files, network, processes) is plain Node and Chromium, unwrapped. The screen is a Chromium page: Node powers (`fs`, `net`, `child_process`) live in the backend, reached from the screen with `kova.send('self', name, body)`. Libraries named in `dependencies` live in `vendor-npm/node_modules` inside the app folder.

```ts
// kova.d.ts · edition 2
type Shape = 'compact' | 'regular' | 'large';
type Mode = 'light' | 'dark';
interface ProfileBasics { nickname: string; mode: Mode; accent: string; language: string; timeZone: string; dateFormat: string; clock: '12h' | '24h'; railLabels: boolean; topBar: boolean }
interface Kova {
  ready(): void;
  stillLoading(): void;
  on(event: 'start' | 'suspend' | 'resume' | 'stop', fn: () => void | Promise<void>): void;
  busy(info: string | null): void;                  // "3 downloads running" or null; drives quit prompt and What's busy
  send(to: string, name: string, body?: unknown): void;   // to: an app id, or 'self' (screen <-> backend)
  on(name: string, fn: (body: any, from: string) => void): void;   // includes the event 'open'
  ask(to: string | 'any', name: string, body?: unknown, timeoutMs?: number): Promise<{ ok: boolean; body?: any; reason?: 'nobody' | 'timeout' }>;
  answer(name: string, fn: (body: any, from: string) => any | Promise<any>): void;
  announce(name: string, body?: unknown): void;
  open(what: { file?: string; url?: string; text?: string }): Promise<{ ok: boolean; handledBy?: string }>;
  storagePath: string;                              // private; survives updates and removals
  notify(title: string, text?: string): void;
  settings: { get<T>(key: string, fallback?: T): Promise<T>; set(key: string, value: unknown): Promise<void> };
  log(level: 'info' | 'warn' | 'error', text: string): void;   // feeds repair notes
  has(capability: string): boolean;
  hintShape(shape: Shape): void;                    // a hint; the Core may ignore it
  previousBuild: string | null;
  openLink(url: string): void;                      // user's default browser
  status?(text: string | number | null): void;      // only if has('status')
  icon(name: string, filled?: boolean, size?: 20 | 24): Promise<string>;   // data URL of a Fluent icon; rarely needed, see S2.10
  shape: Shape; onShape(fn: (s: Shape) => void): void;     // screen
  profile: Readonly<ProfileBasics>; onProfile(fn: (p: ProfileBasics) => void): void;
}
declare const kova: Kova;
```
Rule: treat every optional capability and every other app as maybe-absent.
<!-- END S2.3 -->
`FP:S2.3:8ed79cbc`

### [S2.4] Lifecycle states
<!-- BEGIN S2.4 -->
`staged → installed → starting → ready → running`, then `suspended` (screen only), `stopping`, `stopped`. Side states: `paused` (crash loop), `failed`, `waiting` (parts missing). Only the Core moves an app between states. Signals: `start`, `suspend`, `resume`, `stop`. A hidden screen may be suspended; a backend is never suspended unless the person turns the app off. `stop` has a grace period (default 10 s, extended while the app reports `busy`). Apps save as they go and never rely on `stop` to save.
<!-- END S2.4 -->
`FP:S2.4:1b42ff9c`

### [S2.5] Messaging and capabilities
<!-- BEGIN S2.5 -->
- **Open:** hand over a file or link. The Core finds apps whose `opens` match (`file:<ext>`, `link:http`, `link:https`, `link:magnet`); if several match it asks the person, with an "always use this one" tick (remembered, changeable). The chosen app receives the event `open` with `{ file?, url?, text? }` via `kova.on('open', fn)`, in its backend if it has one, otherwise in its screen.
- **Announce:** one-way. **Ask:** request with reply; default timeout 5 s; "nobody answering" is a normal reply, not an error.
- **Names:** starter vocabulary (`media.nowPlaying`, `media.control`, `download.start`, `download.finished`, `download.progress`, `alarm.ringing`, `alarm.dismissed`, `file.selected`, `link.clicked`, `note.created`, `calendar.eventSoon`, `clipboard.changed`) or a name starting with the app's own `id`. Others only draw a log warning.
- **No hard dependencies:** an app must start alone.
- **Capabilities (closed list):** `tray`, `status`, `blocklist`, `globalShortcuts`. Always present: `notify`, `openLink`, `settings`, `log`, `icon`. Unknown names mean "not supported", never an error.
<!-- END S2.5 -->
`FP:S2.5:af1b72cd`

### [S2.10] Look kit
<!-- BEGIN S2.10 -->
The Core injects this into every app screen. Use these instead of native form controls, which look out of place. Apps may use all, some, or none of it; app styles always win (the base classes live in `@layer kova`).
- **On `<html>`:** `data-mode="light|dark"` (forced `light` if `followsCoreTheme` is false) and `data-shape="compact|regular|large"`.
- **Variables:** `--k-accent`, `--k-accent-hover`, `--k-accent-pressed`, `--k-accent-tint`, `--k-on-accent`; `--k-page`, `--k-surface`, `--k-surface2`, `--k-text`, `--k-text2`, `--k-border`; `--k-r1` 4px, `--k-r2` 8px, `--k-r3` 12px; `--k-font`; `--k-fast` 100ms, `--k-med` 200ms, `--k-slow` 300ms, `--k-ease`; `--k-sh1`, `--k-sh2`. They follow the user's profile live.
- **Classes:** `.k-btn` (`.primary` `.quiet` `.danger`), `.k-card` (`.hover`), `.k-chip` (`.ok` `.warn` `.bad`), `.k-input`, `.k-switch`, `.k-check` and `.k-radio` (on `<input type=checkbox|radio>`), `.k-field`/`.k-label`/`.k-row` (form layout), `<select class="k-select">` (upgraded to a themed dropdown; after setting `.value` in code, dispatch `change`), `.k-tabs` + `.k-tab[aria-selected]`, `.k-page`, `.k-enter`, `.k-stagger` (children get `--i`), `.k-pop`.
- **Icons:** write `<i class="k-ic" data-icon="play"></i>`; add `data-filled` for the filled style and `data-size="20"` for 20 px. The Core fills them, also for elements added later. Names only; never draw icons.
<!-- END S2.10 -->
`FP:S2.10:4e71cfc3`

---
## YOUR PART · 3. Runner
**Project folder `proj/`.** `main.ts`, `scripts/`, `assets/`, `src/kit/` come from the kit. Each part owns only `src/<part>/`: `index.ts`, `seam.json` (`{"part":"<name>","entry":"index.ts"}`), `deps.json` (`{"dependencies":{}}`), plus `ui/` and `preload-*.ts` where listed. Export `create(...)` exactly as `src/kit/seam-types.ts` says: that file is the only description of the neighbours you need. **`main.ts` creates the window and its autohide controls (kit); parts never create windows.** Do not write stand-ins and do not compile against neighbours. Renderer files: `src/<part>/ui/renderer-<name>.ts`, `*.html`, `*.css`; preloads: `src/<part>/preload-<name>.ts`. **`main.ts` already registers the IPC handlers `kova:icon` and `kova:call` and the window handlers: never register them again.**
**Fixed page ids (Frame and Manager agree on these):** `home`, `app` (argument = app id), `busy`, `settings`. Page files live in `src/manager/ui/pages/<id>.ts`, `export default { id, render(root: HTMLElement, arg?: any): void | (() => void) }`; `scripts/setup.mjs` generates `src/generated/pages.ts` (`pages` map) from them.

Use kit: `envelope`, `handshake`, `look`, `icons`. Files: `preload-app.ts` (exposes `kova` to screens), `backend-host.ts` (utility-process bootstrap that defines `globalThis.kova`, then imports the app's backend).
| ID | Do |
|---|---|
| P3-1 | `create(f,i): Runner`. Backend in its own `utilityProcess`; screen in its own `WebContentsView` (contextIsolation on, sandbox off), `view(id)` creates lazily. |
| P3-2 | Handshake with `coreHandshake` on every start; unknown/newer edition → `incompatible`, `KV-RU-007`; missing optional `needs` → still runs, `KV-RU-008`. Cores speak edition 2 and run edition 1 apps. |
| P3-3 | `kova` exactly as S2.3 (screen and backend), including `icon()` via `ipc 'kova:icon'`. |
| P3-4 | Look: `attachLook(view.webContents, profile, followsCoreTheme, assets)` per screen; `setProfile` re-applies; `setShape` via kit `setShape`. Screens get S2.10. |
| P3-5 | Lifecycle S2.4: crash on start `KV-RU-002`; 3 crashes in 2 min → `paused` `KV-RU-003`; ignored stop → kill after grace `KV-RU-004`; hidden screen `suspend`, backend never. |
| P3-6 | Bus: `send/on/ask/answer/announce/open`; last 300 redacted messages per app; unknown names → log warning; `open` matches `opens`, asks via Installer `defaults` then Frame choose, delivers `open` event. |
| P3-7 | `stats()` every 2 s; hog flag after 60 s above 85% CPU or 2 GB (`KV-RU-006`). `busy()` aggregation. `stopAll(graceMs)`. |
| P3-8 | `report(id,text)`, `logTail`; stack traces mapped to original `.ts` via source maps. |
| P3-9 | Blocklist if capability `blocklist` is declared: match by `id` and fingerprint. |
| P3-10 | **Drops on app screens:** on each app view's `will-navigate`, if the URL is a `file:` path ending `.kvx/.kvpart/.kvcore/.kvlib`, `preventDefault()` and call the `onDrop` callbacks with the decoded path; block every other navigation away from the app's own folder. |
| P3-11 | **Never register `ipcMain` handlers named `kova:icon`, `kova:call` or `wc:*`** (`main.ts` and the kit do). Handle your own channels only, with unique names starting `kova:run:`. |

---
## Error codes you raise
| Code | Headline | What happened |
|---|---|---|
| KV-RU-001 | Stage fright! | {name} never said it was ready. |
| KV-RU-002 | Plot twist! {name} collapsed on stage. | It stopped right after starting. |
| KV-RU-003 | Paused, so it stops draining your PC. | {name} crashed several times in a row. |
| KV-RU-004 | It will not take a hint. | {name} ignored the stop signal and was stopped. |
| KV-RU-005 | Nobody picked up. | A request got no answer. (log only) |
| KV-RU-006 | {name} is hogging the stage. | High memory or processor use. See What's busy. |
| KV-RU-007 | Too ambitious for this Core. | The app needs edition {n}; this Core speaks {m}. |
| KV-RU-008 | A missing prop. | The app wanted {feature}, which this Core lacks. It still runs. |

---
## OPTIONAL CHECK
Optional, **only after** the files are packed and presented, and only if `npx` works here: `npx esbuild src/runner/index.ts --bundle --platform=node --external:electron --external:esbuild --external:npm --external:@fluentui/svg-icons --outfile=/tmp/x.js --log-level=error 2>&1 | tail -n 10`. Errors in your files → fix only those lines, re-pack, stop. Any network or tooling error → skip silently. One attempt, never launch the app.

---
## PACK AND REPLY
`python scripts/pack-part.py core 3 runner` (writes `part-3-of-5-<id>.kvpart` into the outputs folder). Then reply exactly (max 10 lines, no code, no recap):
```
Done: Part 3 Runner, <n> files → part-3-of-5-<id>.kvpart
Not done: <requirement IDs, or "nothing">
NEXT STEPS
1. Download the file above and keep it.
2. Build the other parts, one new chat each: upload core-kit.zip, blueprint-<id>.json and core-2-build-parts.md, then say "part <N>".
3. After all five exist: new chat with core-3-seal-parts.md, core-kit.zip, blueprint-<id>.json and the five part files.
```
`kova-core-part-3`
