# CORE PART 4 OF 5 · FRAME · edition 2
`contract edition: 2` · `CONTRACT-FP:7da9cd3b`. You were sent here by `core-2-build-parts.md`; its rules (token rules, no stamps, never draw icons) apply. Read only this file.

---
## [S2] CONTRACT EXCERPT
> Identical to the same sub-sections in every Kova guide. Each has a fingerprint; a missing one means a partial paste: stop and tell the person.

### [S2.7] Profile files
<!-- BEGIN S2.7 -->
Folder `<Library>\profile\`. Only a Profile app writes it. The Core reads it, watches it, relays basics.
- `basics.json`: `{ format:1, nickname, mode:'light'|'dark'|'system', accent:'#RRGGBB', language, timeZone, dateFormat, clock, railLabels:true, topBar:false }`
- `personal.json`: `{ format:1, fullName, email, birthday, location, bio, custom:{}, share:{ basics:true, personal:false } }`
- `avatar.<png|jpg|webp>`

Defaults (no files): light, accent `#0F6CBD`, labels on. The Core relays `mode` already resolved (`system` → light/dark) and never relays `personal.json`. Unknown fields are kept. A newer `format` is read, not written. A damaged file never blocks startup: use defaults, keep the file, `KV-PR-001`. (`topBar` is stored for compatibility; the Core has no top bar and ignores it.)
<!-- END S2.7 -->
`FP:S2.7:8a613fac`

### [S2.10] Look kit
<!-- BEGIN S2.10 -->
The Core injects this into every app screen. Use these instead of native form controls, which look out of place. Apps may use all, some, or none of it; app styles always win (the base classes live in `@layer kova`).
- **On `<html>`:** `data-mode="light|dark"` (forced `light` if `followsCoreTheme` is false) and `data-shape="compact|regular|large"`.
- **Variables:** `--k-accent`, `--k-accent-hover`, `--k-accent-pressed`, `--k-accent-tint`, `--k-on-accent`; `--k-page`, `--k-surface`, `--k-surface2`, `--k-text`, `--k-text2`, `--k-border`; `--k-r1` 4px, `--k-r2` 8px, `--k-r3` 12px; `--k-font`; `--k-fast` 100ms, `--k-med` 200ms, `--k-slow` 300ms, `--k-ease`; `--k-sh1`, `--k-sh2`. They follow the user's profile live.
- **Classes:** `.k-btn` (`.primary` `.quiet` `.danger`), `.k-card` (`.hover`), `.k-chip` (`.ok` `.warn` `.bad`), `.k-input`, `.k-switch`, `.k-check` and `.k-radio` (on `<input type=checkbox|radio>`), `.k-field`/`.k-label`/`.k-row` (form layout), `<select class="k-select">` (upgraded to a themed dropdown; after setting `.value` in code, dispatch `change`), `.k-tabs` + `.k-tab[aria-selected]`, `.k-page`, `.k-enter`, `.k-stagger` (children get `--i`), `.k-pop`.
- **Icons:** write `<i class="k-ic" data-icon="play"></i>`; add `data-filled` for the filled style and `data-size="20"` for 20 px. The Core fills them, also for elements added later. Names only; never draw icons.
<!-- END S2.10 -->
`FP:S2.10:4e71cfc3`

---
## YOUR PART · 4. Frame
**Project folder `proj/`.** `main.ts`, `scripts/`, `assets/`, `src/kit/` come from the kit. Each part owns only `src/<part>/`: `index.ts`, `seam.json` (`{"part":"<name>","entry":"index.ts"}`), `deps.json` (`{"dependencies":{}}`), plus `ui/` and `preload-*.ts` where listed. Export `create(...)` exactly as `src/kit/seam-types.ts` says: that file is the only description of the neighbours you need. **`main.ts` creates the window and its autohide controls (kit); parts never create windows.** Do not write stand-ins and do not compile against neighbours. Renderer files: `src/<part>/ui/renderer-<name>.ts`, `*.html`, `*.css`; preloads: `src/<part>/preload-<name>.ts`. **`main.ts` already registers the IPC handlers `kova:icon` and `kova:call` and the window handlers: never register them again.**
**Fixed page ids (Frame and Manager agree on these):** `home`, `app` (argument = app id), `busy`, `settings`. Page files live in `src/manager/ui/pages/<id>.ts`, `export default { id, render(root: HTMLElement, arg?: any): void | (() => void) }`; `scripts/setup.mjs` generates `src/generated/pages.ts` (`pages` map) from them.

| ID | Do |
|---|---|
| P4-1 | `create(s): Frame` per seam-types. **`s.window` is the kit window created by `main.ts`** (`{ win, overlay, addView, removeView, raise }`): never create a `BrowserWindow`, never load the shell yourself. You provide `ui/shell.html`, `ui/renderer-shell.ts`, `ui/shell.css`, `preload-shell.ts` (calls `exposeKovaCore(contextBridge, ipcRenderer)`), `index.ts`. **There is no top bar and no title bar. The rail is the only Core chrome.** |
| P4-2 | **Window controls are provided by the kit window; do not write your own.** Add and remove every app view only with `s.window.addView(view)` / `s.window.removeView(view)` (never `contentView.addChildView`). No `-webkit-app-region: drag` except the empty rail space, never in the top 56 px or the right 204 px. Alt+F4 and Win+arrows must work. |
| P4-3 | **Rail (S12.2), one column, three zones, every item stacks from the top of its zone.** *Top:* Home (`home`), What's running (`pulse`). *Middle (scrolls on its own):* one item per installed app in install order, using the app's `icon` (default `apps`), its name as label, a dot when running, `status` badge if any. Updates on `apps.changed`. *Bottom:* Settings (`settings`), then Profile (`person`) at the very bottom, shown **only if an app whose `type` slug is `profile` is installed** (it is then not repeated in the middle). Labels follow profile `railLabels`; icon-only shows a tooltip. Click on an app item starts it if needed and shows its view; click on Home/What's running/Settings shows that page. |
| P4-4 | **Main area** = everything right of the rail. App: Runner `view(id)` sized to it, edge to edge, resized on window resize; send `compact` / `regular` / `large` by width (<560 / <1000 / else). Pages: renderer pages from `src/generated/pages.ts`. |
| P4-5 | **Transitions required (S12.4):** page enter, app-switch scrim fade, sliding rail pill, dialogs, toasts, drop overlay. |
| P4-6 | **Drop overlay** when files are dragged over the shell; also subscribe to `runner.onDrop` (files dropped on an app screen). `handleFiles(files)` → `installer.install` → result sheet. Install methods: drag, double-click (kit `handoff` via `main.ts`), and the Add app button (Manager calls `frame.pickFile`). |
| P4-7 | **Repair center** (also used by the Manager's Activity tab): for any failure show a dialog page with, in this order: **What happened** (the bank entry in plain words, safety line), **Files that could not load** (list from `foundation.repair.files`: path + reason each), **Your repair prompt** (full text from `foundation.repair.forApp/forCore`, preview box, big **Copy repair prompt** button), **Files to give your AI** (one item: the repair bundle from `foundation.repair.bundle`, with a **Save bundle** button that reveals the file), **Next steps** (numbered, 4 lines max, taken from the prompt). Also: Turn this app off for now, Try again. Serious entries use calm styling. |
| P4-8 | **Quit flow:** handler for `foundation.quit.onRequest`: ask apps to finish (10 s, longer while `busy`). Busy → dialog with exactly three buttons: *Cancel quit*, *Force quit*, *Continue in background*. Idle → close quietly. Background needs a way back: tray if supported, else a minimized taskbar entry. |
| P4-9 | **Startup:** window shows immediately; restore the last session (on by default, setting to turn off); relay the profile to Runner and to the shell's own look (`attachLook`); if `iconsReady()` is false show a one-time toast "Icons need `npm install`". |
| P4-10 | Emit `apps.changed`, `profile.changed`, `busy.changed` (kit `emit`). `frame.show(page, arg)` switches pages. |
| P4-11 | **Use the look kit's custom controls** (`.k-select`, `.k-radio`, `.k-check`, `.k-switch`, `.k-input`), never native-looking ones. |
| P4-12 | Accessibility: keyboard-reachable rail and pages, visible focus, labels on controls, text scaling to 200%, reduced motion. |

---
## Error codes you show
| Code | Headline | What happened |
|---|---|---|
| KV-CR-001 | The Core upgrade was interrupted. | The previous Core stays active. |
| KV-CR-002 | The new Core could not take the stage. | We returned to the previous Core. |
| KV-CR-003 | This Core dreams of a newer Runtime. | Installed, but not activated. |
| KV-CR-004 | Quiet mode. | Everything is switched off. Turn things on one by one. |
| KV-CR-005 | Not a valid Core. | The package is missing parts of its identity. |
| KV-PR-001 | The profile is scrambled. | Defaults are in use; the broken file is kept. |
| KV-PR-002 | The avatar will not load. | Showing the default picture. |

## Dictionary and voice
One word per thing: **Core**, **App**, **Library**, **repair note**, **request card**, **snapshot**, **Safe mode**, **backup file**, **Part / Set / Blueprint / Seal**. Voice: playful, mischievous, dramatic; one or two lines; blame the app, never the person; always say what to do; calm for deleting or data loss.
| Moment | Text |
|---|---|
| Installed | "It lives! {name} is now part of your Core. Go on, say hello." |
| Same version | "Ooh, a twin! You already have this exact one. Install it anyway, or pretend this never happened?" |
| Older version | "A visitor from the past! This one is older than what you have. Invite it in as an extra version?" |
| App needs newer Core | "This app is too ambitious for this Core. It dreams of features we don't have yet." |
| Quit while busy | "Hold the curtain! {n} apps are still mid-performance. Cancel quit, force quit, or let them carry on in the background?" |
| Removing (calm) | "You're about to remove version {label} of {name}. Its saved data can stay or go. What would you like to do with it?" |
| Waiting for parts | "{x} of {y} performers have arrived. Waiting for parts {list}." |
| Restart choice | "{Core} is ready. Take the stage now, or switch next time?" |
| Empty apps page | "The stage is empty. Drop a .kvx here and watch the magic." |

## Design system (Frame and Manager)
> Design like a senior product designer with a refined, creative, professional taste: calm, spacious, precise, a little delightful. Teams-inspired Fluent language; the look kit (`assets/base.css`) supplies tokens, base classes and custom controls. **Colour and token values are provisional until verified against Fluent's official tokens.**

**D1 Principles.** Quiet surfaces; one accent used sparingly (selection, primary action, focus); generous space (8 px grid, sections 24 to 32 px apart); 14 px body, 16 headings, 28 page titles; weights 400 and 600 only; subtle depth (`--k-sh1` resting, `--k-sh2` lifted); motion eases out in 100/200/300 ms, never bounces; one idea per card.

**D2 Rail.** Width 72 px (labels) or 52 px (icon-only), `--k-surface2` background, 1 px right border. Three zones in one column. **Top:** Home, What's running. **Middle:** every installed app, in install order, scrolling on its own with a thin scrollbar, between two hairline dividers. **Bottom:** Settings, and below it Profile (only if a Profile app is installed). Items 56×56, 4 px gaps, icon 24 px, label 11 px centred below, radius 8, and **always start at the top of their zone** (never float to the bottom). Hover: surface darkens. Selected: **filled icon**, accent colour, and a 3×20 accent pill on the left edge that **slides** to the new item (200 ms). Running apps: 4 px accent dot under the icon. `status` badge: small accent circle top-right. Icon-only mode: tooltip after 400 ms. Empty rail space is the window drag area.

**D3 Home page** (`.k-page`, staggered): time-aware greeting "Good evening, {nickname}" with a dramatic one-liner; **Running now** (compact cards with icon tile, name, state); **All apps**: title with count chip, search field, type chips (All + types present), **Add app** (primary), grid/list toggle; app cards 248×152 (`.k-card.hover`): 48 px icon tile (radius 12, accent-tint background, accent icon), name 16/600, type chip, version label, state chip (Running ok, Off, Paused warn, Needs attention bad); a "performers arriving" strip for waiting Sets with Discard; a dashed **drop card** "Drop a .kvx to add an app". **First run (no apps):** one centred card: large Fluent `apps` icon in an accent-tint circle, the Core name (28/600), `version · build stamp · edition` in secondary text, one dramatic line, a quiet link to Settings › Guides. No tours.

**D4 Motion (all required).** Page enter `.k-enter` (fade + 8 px rise, 300 ms). Lists and grids `.k-stagger` (30 ms apart). App switch: a page-colour scrim fades out over the new app view in 160 ms. Rail pill slides; hover and press 100 ms; dialogs `.k-pop` over a scrim fading in 200 ms; toasts rise 12 px and fade in 200 ms, leave after 4 s; drop overlay fades in 160 ms. Reduced motion → about 1 ms.

**D5 App detail page** (breadcrumb "Home › Name" and a back button). Header: 64 px icon tile, name 28/600, id (small, copyable), version label · build stamp, state chip. Actions: primary **Open** (or Turn on), Stop/Pause, overflow: Report a problem, Remove. Tabs (`.k-tabs`): *Overview* (description; facts: type, edition tested, runs in background, size hint; switches **Start with Core** and **Enabled**; "What this app says it will do" as plain-language cards; danger zone), *Versions* (a row per version: Active badge, version label, build stamp, edition, size, installed date; **Make active**, **Remove**; calm text about data), *Data & storage* (data size, **Open folder**, snapshots with **Restore**, **Remove saved data** with confirm), *Connections* (opens / announces / answers chips; "Default app for" rows with Change), *Activity* (CPU and memory live bars, last 20 log lines, **Report a problem** text box + **Copy repair note**).

**D6 What's running.** Table: icon + name, state, memory and CPU as slim accent bars with numbers, **Pause** and **Stop**; hogs in warn colour; refresh 2 s; empty state "Everything is calm."

**D7 Settings** (tabs): *Cores* (card per installed Core: name, build stamp, edition, runtime edition, chips "Running now" / "Opens next launch", **Use this version**, **Remove**; **Update core** primary; warning before an older Core that cannot read the Library; after install a dialog **Restart now / Restart later**; Runtime version row), *Guides* (cards for the Style Spec and added guides with edition, View / Copy / Export, **Add guide**), *Backup* (**Export** with include checkboxes, **Import**; line "The backup file contains your profile."), *General* (Library location, restore-last-session switch, rail labels preview, Safe mode, Export diagnostics).

**D8 Dialogs.** Centred card, radius 12, `--k-sh2`, max 480 px, title 20/600, buttons right-aligned, primary last. Install result sheet: one row per file with an outcome chip and the dramatic line.

**D9 Controls.** Selects, radios, checkboxes, switches and inputs are always the look kit's themed ones (`<select class="k-select">`, `.k-radio`, `.k-check`, `.k-switch`, `.k-input`), aligned to a 4 px grid with 32 px height; labels via `.k-field` / `.k-label`. Never leave a native control.

**D10 Colour.** Accent from the profile (default blue `#0F6CBD`), text on accent via `--k-on-accent`, light theme by default.

**D11 Repair center.** One calm page, 640 px column, numbered sections 1 to 5 as in P4-7; the prompt box is monospace 12 px, max 220 px tall, scrolls; **Copy repair prompt** is the only primary button and turns into a tick for 2 s when pressed; the file list uses small file icons, the path in 12 px and the reason in secondary text; the footer repeats the next steps.

---
## OPTIONAL CHECK
Optional, **only after** the files are packed and presented, and only if `npx` works here: `npx esbuild src/frame/index.ts --bundle --platform=node --external:electron --external:esbuild --external:npm --external:@fluentui/svg-icons --outfile=/tmp/x.js --log-level=error 2>&1 | tail -n 10`. Errors in your files → fix only those lines, re-pack, stop. Any network or tooling error → skip silently. One attempt, never launch the app.

---
## PACK AND REPLY
`python scripts/pack-part.py core 4 frame` (writes `part-4-of-5-<id>.kvpart` into the outputs folder). Then reply exactly (max 10 lines, no code, no recap):
```
Done: Part 4 Frame, <n> files → part-4-of-5-<id>.kvpart
Not done: <requirement IDs, or "nothing">
NEXT STEPS
1. Download the file above and keep it.
2. Build the other parts, one new chat each: upload core-kit.zip, blueprint-<id>.json and core-2-build-parts.md, then say "part <N>".
3. After all five exist: new chat with core-3-seal-parts.md, core-kit.zip, blueprint-<id>.json and the five part files.
```
`kova-core-part-4`
