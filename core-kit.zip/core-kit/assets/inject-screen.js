(() => {
  if (window.__kovaIcons) return; window.__kovaIcons = true;
  const cache = new Map();
  const keyOf = (e) => e.dataset.icon + (e.hasAttribute('data-filled') ? '!' : '') + (e.dataset.size || '24');
  async function fill(e) {
    if (!window.kova || !window.kova.icon || !e.dataset.icon) return;
    const k = keyOf(e); if (e.dataset.done === k) return;
    let u = cache.get(k);
    if (!u) { u = await window.kova.icon(e.dataset.icon, e.hasAttribute('data-filled'), +(e.dataset.size || 24)); cache.set(k, u); }
    e.style.setProperty('--src', 'url("' + u + '")'); e.classList.add('k-ic'); e.dataset.done = k;
  }
  const scan = (r) => r.querySelectorAll && r.querySelectorAll('[data-icon]').forEach(fill);
  new MutationObserver((ms) => { for (const m of ms) { if (m.type === 'attributes') fill(m.target); else m.addedNodes.forEach((n) => { if (n.nodeType === 1) { if (n.matches && n.matches('[data-icon]')) fill(n); scan(n); } }); } })
    .observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-icon', 'data-filled', 'data-size'] });
  scan(document);
})();

(() => {
  if (window.__kovaSel) return; window.__kovaSel = true;
  function up(sel) {
    if (sel.dataset.kdone) return; sel.dataset.kdone = '1';
    const w = document.createElement('div'); w.className = 'k-sel'; sel.parentNode.insertBefore(w, sel); w.appendChild(sel);
    const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'k-sel-btn'; btn.setAttribute('aria-haspopup', 'listbox'); w.appendChild(btn);
    let menu = null, idx = 0;
    const label = () => { const o = sel.options[sel.selectedIndex]; btn.textContent = o ? o.textContent : ''; };
    const close = () => { if (menu) { menu.remove(); menu = null; } w.classList.remove('open'); };
    const choose = (i) => { sel.selectedIndex = i; sel.dispatchEvent(new Event('change', { bubbles: true })); label(); close(); btn.focus(); };
    const open = () => {
      if (menu) return close(); menu = document.createElement('div'); menu.className = 'k-sel-menu'; menu.setAttribute('role', 'listbox'); idx = Math.max(0, sel.selectedIndex);
      [...sel.options].forEach((o, i) => { const d = document.createElement('div'); d.className = 'k-sel-opt' + (i === idx ? ' active' : ''); d.setAttribute('role', 'option'); d.setAttribute('aria-selected', String(i === sel.selectedIndex)); d.textContent = o.textContent; d.onmousedown = (e) => { e.preventDefault(); choose(i); }; menu.appendChild(d); });
      w.appendChild(menu); w.classList.add('open');
    };
    btn.onclick = open;
    btn.onkeydown = (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!menu) open(); const n = sel.options.length; idx = (idx + (e.key === 'ArrowDown' ? 1 : n - 1)) % n; [...menu.children].forEach((c, i) => c.classList.toggle('active', i === idx)); }
      else if (e.key === 'Enter' && menu) { e.preventDefault(); choose(idx); } else if (e.key === 'Escape') close();
    };
    document.addEventListener('mousedown', (e) => { if (menu && !w.contains(e.target)) close(); });
    sel.addEventListener('change', label); label();
  }
  const scan = (r) => r.querySelectorAll && r.querySelectorAll('select.k-select').forEach(up);
  new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((n) => { if (n.nodeType === 1) { if (n.matches && n.matches('select.k-select')) up(n); scan(n); } }))).observe(document.documentElement, { childList: true, subtree: true });
  scan(document);
})();
