KOVA KIT · edition 2 (rev 4)
Ready-made files for Core generation. The agent COPIES these; it never retypes them.

  cp -r core-kit/. <project folder>/        (Windows: xcopy /E /Y core-kit\* <project>\)

Contents
  src/kit/*.ts         wire format, stamps, fingerprint, redaction, atomic writes, install helpers,
                       icons, look injection, window + autohide controls, rpc
  assets/              base.css (look kit), inject-screen.js (data-icon filler), overlay.html (window controls)
  scripts/build.mjs    bundles the Core (npm start runs it)
  scripts/pack-kvx.py  packs an App folder into <id>.kvx (validates kova.json, stamps the copy inside the zip, never edits the folder)
  scripts/assemble.py  validates and merges .kvpart files (safe paths, owns, no duplicates, one setId); pack-part.py / pack-core.py pack
  scripts/verify.py    fp | contract | blueprint | core | app checks; fp.py rewrites FP/CONTRACT-FP lines; mint-id.py prints a fresh id tag
  scripts/make-manifest.py  kit.manifest.json (+ --check) detects edited kit files
  tests/run_tests.py   python tests/run_tests.py   (needs esbuild on PATH or KOVA_ESBUILD for the bundle/wiring tests)
  tools/sync-kits.py   copies the shared scripts into app-kit/scripts (core-kit/scripts is the source of truth)
  templates/           START-HERE.txt template
Files here are identical for every part, so copying them in every session is safe.
