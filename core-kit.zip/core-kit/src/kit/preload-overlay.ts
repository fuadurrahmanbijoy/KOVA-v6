import { contextBridge, ipcRenderer } from 'electron';
contextBridge.exposeInMainWorld('kovaWin', {
  cmd: (c: string) => ipcRenderer.invoke('wc:cmd', c),
  onState: (fn: (s: { visible: boolean; maximized: boolean }) => void) => ipcRenderer.on('wc:state', (_e, s) => fn(s)),
});
