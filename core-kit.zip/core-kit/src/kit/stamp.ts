export interface Stamp { raw: string; utc: number | null }
export function parseStamp(raw: string): Stamp {
  const t = raw.trim();
  if (/^\d{13}$/.test(t)) { const ms = +t; if (ms > 946684800000 && ms < 4102444800000) return { raw, utc: ms }; }
  const rx = [
    /^(\d{4})(\d{2})(\d{2})(?:[T\s_-]?(\d{2})(\d{2})(\d{2})?)?\s*(Z)?$/i,
    /^(\d{4})[\s_\-\/:.]+(\d{1,2})[\s_\-\/:.]+(\d{1,2})(?:[\s_\-T:.]+(\d{1,2})[\s_\-:.]*(\d{2})?(?:[\s:.]*(\d{2}))?)?\s*(Z)?$/i,
  ];
  for (const r of rx) {
    const m = r.exec(t); if (!m) continue;
    const [y, mo, d, h, mi, s] = [1, 2, 3, 4, 5, 6].map((i) => (m[i] ? +m[i] : 0));
    if (y < 2000 || y > 2100 || mo < 1 || mo > 12 || d < 1 || d > 31 || h > 23 || mi > 59 || s > 59) continue;
    const utc = m[7] ? Date.UTC(y, mo - 1, d, h, mi, s) : new Date(y, mo - 1, d, h, mi, s).getTime();
    return { raw, utc };
  }
  return { raw, utc: null };
}
export type Order = 'newer' | 'older' | 'same';
/** a = candidate, b = installed. Parsed stamps order by time; otherwise by install time (aAt, bAt). */
export function compareBuild(a: Stamp, aAt: number, b: Stamp, bAt: number): Order {
  const x = a.utc !== null && b.utc !== null ? [a.utc, b.utc] : [aAt, bAt];
  return x[0] > x[1] ? 'newer' : x[0] < x[1] ? 'older' : 'same';
}
export function isSuspicious(s: Stamp, zipInnerNewest: number | null, now = Date.now()): boolean {
  if (s.utc === null) return false;
  const day = 86_400_000;
  return s.utc > now + day || (zipInnerNewest !== null && Math.abs(s.utc - zipInnerNewest) > day);
}
/** Stamp as used in file names: YYYY-MM-DD-HHmm, or a cleaned label. */
export function fileStamp(s: Stamp): string {
  if (s.utc === null) return s.raw.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'unstamped';
  const d = new Date(s.utc), p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
}
