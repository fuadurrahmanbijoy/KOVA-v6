import { openSync, writeSync, fsyncSync, closeSync, renameSync, mkdirSync, rmSync, existsSync } from 'node:fs';
import { dirname } from 'node:path';
export function writeJsonAtomic(path: string, data: unknown) {
  mkdirSync(dirname(path), { recursive: true });
  const tmp = path + '.tmp-' + process.pid;
  const fd = openSync(tmp, 'w'); writeSync(fd, JSON.stringify(data, null, 2)); fsyncSync(fd); closeSync(fd);
  renameSync(tmp, path);
}
/** Staged folder becomes real by ONE rename. Existing target is never deleted here. */
export function commitDir(staged: string, final: string) {
  if (existsSync(final)) throw new Error('target exists: ' + final);
  mkdirSync(dirname(final), { recursive: true });
  renameSync(staged, final);
}
export const discard = (p: string) => rmSync(p, { recursive: true, force: true });
