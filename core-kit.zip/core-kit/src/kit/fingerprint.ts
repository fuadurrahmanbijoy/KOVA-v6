import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
export function contentFingerprint(root: string): string {
  const files: string[] = [];
  (function walk(d: string) { for (const e of readdirSync(d)) { const p = join(d, e); statSync(p).isDirectory() ? walk(p) : files.push(p); } })(root);
  files.sort();
  const h = createHash('sha256');
  for (const f of files) { h.update(relative(root, f).split(sep).join('/') + '\0'); h.update(readFileSync(f)); h.update('\0'); }
  return h.digest('hex');
}
export const shortKey = (fp: string) => fp.slice(0, 12);
