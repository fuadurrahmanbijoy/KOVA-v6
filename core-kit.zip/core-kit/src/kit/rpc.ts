import { BrowserWindow, ipcMain } from 'electron';
/** Renderer pages call main-side services by dotted path, e.g. 'installer.apps.list'. */
export function registerRpc(services: Record<string, any>) {
  ipcMain.removeHandler('kova:call');
  ipcMain.handle('kova:call', async (_e, path: string, args: unknown[]) => {
    const parts = String(path).split('.'); let obj: any = services, fn: any;
    for (let i = 0; i < parts.length; i++) { const next = obj?.[parts[i]]; if (i === parts.length - 1) fn = next; else obj = next; }
    if (typeof fn !== 'function') throw new Error('KV-RPC: no such call ' + path);
    return await fn.apply(obj, args ?? []);
  });
}
/** Main to renderer events. Any part may call it. */
export const emit = (channel: string, payload?: unknown) => BrowserWindow.getAllWindows().forEach((w) => !w.webContents.isDestroyed() && w.webContents.send('kova:event', channel, payload));
/** Call inside src/frame/preload-shell.ts: exposeKovaCore(contextBridge, ipcRenderer) */
export function exposeKovaCore(cb: Electron.ContextBridge, ipc: Electron.IpcRenderer) {
  const icon = (n: string, f?: boolean, s?: number) => ipc.invoke('kova:icon', n, !!f, s ?? 24);
  cb.exposeInMainWorld('kovaCore', {
    call: (path: string, ...args: unknown[]) => ipc.invoke('kova:call', path, args),
    on: (fn: (channel: string, payload: unknown) => void) => { const h = (_e: unknown, c: string, p: unknown) => fn(c, p); ipc.on('kova:event', h); return () => ipc.removeListener('kova:event', h); },
  });
  cb.exposeInMainWorld('kova', { icon });
}
