import { BrowserWindow, WebContentsView, ipcMain, screen } from 'electron';
import { join } from 'node:path';
export interface FrameOpts { shellHtml: string; shellPreload: string; bg?: string }
/** Frameless window + autohide window controls that always sit ABOVE app views. No top bar.
 *  Paths: shellHtml = join(__dirname,'ui','shell.html'), shellPreload = join(__dirname,'preload-shell.js'). The overlay paths are built in.
 *  NEVER call win.contentView.addChildView yourself: use frame.addView / frame.removeView so the controls stay on top. */
export function createFrame(o: FrameOpts) {
  const win = new BrowserWindow({ width: 1180, height: 760, minWidth: 720, minHeight: 480, frame: false, show: false, backgroundColor: o.bg ?? '#F5F5F5',
    webPreferences: { preload: o.shellPreload, contextIsolation: true, sandbox: false } });
  const overlay = new WebContentsView({ webPreferences: { preload: join(__dirname, 'preload-overlay.js'), contextIsolation: true, sandbox: false } });
  overlay.setBackgroundColor('#00000000');
  win.contentView.addChildView(overlay);
  let shown = false, timer: NodeJS.Timeout | undefined;
  const layout = () => {
    const W = win.getContentSize()[0];
    overlay.setBounds(shown ? { x: W - 196, y: 0, width: 196, height: 48 } : { x: 0, y: 0, width: 0, height: 0 });
    if (!overlay.webContents.isDestroyed()) overlay.webContents.send('wc:state', { visible: shown, maximized: win.isMaximized() });
  };
  // The cursor is polled in the main process, so no view, drag region or z-order can block the reveal.
  const tick = () => {
    if (win.isDestroyed() || !win.isVisible() || win.isMinimized()) return;
    const p = screen.getCursorScreenPoint(), b = win.getBounds(), dx = p.x - b.x, dy = p.y - b.y;
    const inWin = dx >= 0 && dx <= b.width && dy >= 0 && dy <= b.height;
    const hot = inWin && (dy <= 8 || (shown && dy <= 56 && dx >= b.width - 204));
    if (hot) { if (timer) { clearTimeout(timer); timer = undefined; } if (!shown) { shown = true; layout(); } }
    else if (shown && !timer) timer = setTimeout(() => { shown = false; timer = undefined; layout(); }, 1200);
  };
  const poll = setInterval(tick, 80);
  win.on('closed', () => clearInterval(poll));
  ipcMain.removeHandler('wc:cmd');
  ipcMain.handle('wc:cmd', (_e, c: string) => {
    if (c === 'min') win.minimize(); else if (c === 'max') (win.isMaximized() ? win.unmaximize() : win.maximize()); else if (c === 'close') win.close();
    layout();
  });
  for (const ev of ['resize', 'maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen']) (win as any).on(ev, layout);
  overlay.webContents.loadFile(join(__dirname, 'assets', 'overlay.html'));
  win.loadFile(o.shellHtml);
  win.once('ready-to-show', () => { layout(); win.show(); });
  const raise = () => { win.contentView.removeChildView(overlay); win.contentView.addChildView(overlay); };
  const addView = (v: WebContentsView) => { win.contentView.addChildView(v); raise(); };
  const removeView = (v: WebContentsView) => { try { win.contentView.removeChildView(v); } catch {} };
  return { win, overlay, addView, removeView, raise };
}
