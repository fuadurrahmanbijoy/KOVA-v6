import { transformSync } from 'esbuild';
import { readdirSync, readFileSync, statSync, writeFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
export function convertTree(root: string): { file: string; line?: number; message: string }[] {
  const errs: { file: string; line?: number; message: string }[] = [];
  const walk = (d: string) => { for (const e of readdirSync(d)) { if (e === 'vendor' || e === 'vendor-npm' || e === 'node_modules') continue; const p = join(d, e); statSync(p).isDirectory() ? walk(p) : /\.(ts|mts)$/.test(e) && !e.endsWith('.d.ts') ? one(p) : e.endsWith('.html') && html(p); } };
  const one = (p: string) => {
    try {
      const r = transformSync(readFileSync(p, 'utf8'), { loader: 'ts', format: 'esm', target: 'node20', sourcemap: 'external', sourcefile: p.slice(root.length + 1) });
      const js = p.replace(/\.m?ts$/, (m) => (m === '.mts' ? '.mjs' : '.js'));
      writeFileSync(js, r.code + `\n//# sourceMappingURL=${js.split(/[\\/]/).pop()}.map`); writeFileSync(js + '.map', r.map);
      rmSync(p);
    } catch (e: any) { const x = e.errors?.[0]; errs.push({ file: p.slice(root.length + 1), line: x?.location?.line, message: x?.text ?? String(e) }); }
  };
  const html = (p: string) => writeFileSync(p, readFileSync(p, 'utf8').replace(/(src=["'][^"']+)\.m?ts(["'])/g, '$1.js$2'));
  walk(root); return errs;
}
