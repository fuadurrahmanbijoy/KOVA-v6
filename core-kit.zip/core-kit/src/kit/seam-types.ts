// Seam types · edition 2 (rev 3). Identical in every part. Do not edit.
import type { WebContentsView } from 'electron';
import type { createFrame } from './window';
export type KitFrame = ReturnType<typeof createFrame>;   // { win, overlay, addView, removeView, raise }
export type Outcome = 'nothing-changed' | 'rolled-back' | 'paused';
export type Shape = 'compact' | 'regular' | 'large';
export interface KvError { code: string; stage: string; message: string; file?: string; part?: number; detail?: unknown }
export interface Report { ok: boolean; outcome?: Outcome; errors: KvError[]; appId?: string; summary?: string }
export interface BankEntry { headline: string; whatHappened: string; safety: string; steps: string[]; serious: boolean; outcome: Outcome; repairHint: string }
export interface ProfileBasics { nickname: string; mode: 'light' | 'dark'; accent: string; language: string; timeZone: string; dateFormat: string; clock: '12h' | '24h'; railLabels: boolean; topBar: boolean }
export interface VersionInfo { key: string; buildStamp: string; stampParsed: number | null; versionLabel?: string; edition: number; bytes: number; installedAt: number; active: boolean; hasSnapshot: boolean }
export interface AppInfo {
  id: string; name: string; type: string; icon: string; description?: string; versionLabel?: string;
  active: VersionInfo; versions: VersionInfo[]; state: string; enabled: boolean; autoStart: boolean;
  runsInBackground: boolean; hasBackend: boolean; followsCoreTheme: boolean; sizeHint: Shape;
  needs: string[]; opens: string[]; announces: string[]; answers: string[]; worksBetterWith: string[]; dataBytes: number; set?: { setId: string; part: number; total: number };
}
export interface Foundation {
  paths: { root: string; staging: string; waiting: string; trash: string; backups: string; guides: string; profile: string; logs: string; app(id: string): string };
  index: { read(): any; write(next: any): Promise<void> };
  log: { info(s: string): void; warn(s: string): void; error(s: string): void; tail(n: number): string[] };
  bank: { get(code: string): BankEntry };
  redact(s: string): string;
  fs: { writeJsonAtomic(path: string, data: unknown): Promise<void>; commitDir(staged: string, final: string): Promise<void> };
  safeMode: { isOn(): boolean; recordLaunch(ok: boolean): void; request(): void };
  repair: { forApp(e: { appId: string; errors: KvError[]; evidence?: { log: string[]; messages: unknown[] }; part?: number }): string; forCore(errors: KvError[]): string; friendly(code: string): BankEntry; diagnostics(): string; bundle(e: { appId?: string; errors: KvError[] }): Promise<string> /* path of <id>-repair.zip: note + failing files */; files(e: { appId?: string; errors: KvError[] }): { path: string; reason: string }[] /* the unloadable-files list for the Repair center */ };
  quit: { onRequest(h: () => Promise<'cancel' | 'force' | 'background' | 'ok'>): void; markStartedOk(): void; request(): Promise<void> };
  profile: { read(): ProfileBasics; onChange(cb: (p: ProfileBasics) => void): void };
  space: { check(bytesNeeded: number): { ok: boolean; need: number; have: number } };
  settings: { get<T>(k: string, d?: T): T; set(k: string, v: unknown): void };
}
export interface Installer {
  install(files: string[], ui: { choose(q: string, options: string[]): Promise<number> }): Promise<Report[]>;
  apps: { list(): AppInfo[]; get(id: string): AppInfo | null; summary(id: string): { background: boolean; internetLikely: boolean; needs: string[]; opens: string[]; editionTested: number }; setAutoStart(id: string, on: boolean): void; setEnabled(id: string, on: boolean): void; remove(id: string, dropData: boolean): Promise<Report> };
  versions: { switch(id: string, key: string): Promise<Report>; remove(id: string, key: string, dropData: boolean): Promise<Report>; snapshots(id: string): { key: string; at: number; bytes: number }[]; restore(id: string, snapKey: string): Promise<Report> };
  waiting: { list(): { setId: string; name: string; have: number[]; total: number }[]; discard(setId: string): Promise<void> };
  defaults: { get(): Record<string, string>; set(kind: string, appId: string | null): void };
  exportSet(setId: string, to: string): Promise<Report>;
}
export interface Runner {
  start(id: string): Promise<Report>;
  stop(id: string, force?: boolean): Promise<void>;
  pause(id: string): void;
  state(id: string): string;
  busy(): { id: string; info: string }[];
  stats(): { id: string; memMB: number; cpu: number }[];
  view(id: string): WebContentsView | null;              // the app's screen; Frame sizes and shows it
  setShape(id: string, s: Shape): void;
  setProfile(p: ProfileBasics): void;
  open(what: { file?: string; url?: string; text?: string }): Promise<{ ok: boolean; handledBy?: string }>;
  report(id: string, userText: string): string;           // repair note for a running or crashed app
  logTail(id: string, n: number): string[];
  onFailure(cb: (r: Report) => void): void;
  onDrop(cb: (files: string[]) => void): void;           // files dropped onto an app screen (Runner intercepts will-navigate to file:// .kv* paths)
  stopAll(graceMs: number): Promise<void>;
}
export interface Frame {
  start(): Promise<void>;
  handleFiles(files: string[]): Promise<void>;
  showFailure(r: Report): void;
  pickFile(o: { filters?: { name: string; extensions: string[] }[]; multi?: boolean }): Promise<string[] | null>;
  openFolder(path: string): void;
  copyText(text: string): void;
  toast(text: string): void;
  show(page: string, arg?: unknown): void;               // fixed page ids: 'home' | 'app' (arg = app id) | 'busy' | 'settings'
}
export interface Seal {
  exportLibrary(include: string[], to: string): Promise<Report>;
  importLibrary(file: string): Promise<Report>;
  installCore(file: string): Promise<Report>;
  listCores(): { id: string; name: string; buildStamp: string; edition: number; runtimeEdition: number; running: boolean; opensNext: boolean }[];
  switchCore(id: string): Promise<Report>;
  removeCore(id: string): Promise<Report>;
  runtimeInfo(): { present: boolean; version: string | null };
}
/** Every part ships seam.json: { "part": "...", "entry": "index.ts" }
 *  and deps.json: { "dependencies": { "name": "version" } }.
 *  Factories: foundation.create() · installer.create(f) · runner.create(f,i) · seal.create(f,i,r) · frame.create({foundation,installer,runner,seal,window: KitFrame}) (window is created by main.ts) */
