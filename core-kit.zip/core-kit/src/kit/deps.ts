import { spawn } from 'node:child_process';
import { join } from 'node:path';
export function installDeps(dir: string, deps: Record<string, string>): Promise<{ ok: boolean; output: string }> {
  const names = Object.entries(deps).map(([n, v]) => `${n}@${v}`);
  if (!names.length) return Promise.resolve({ ok: true, output: '' });
  const npmCli = require.resolve('npm/bin/npm-cli.js');
  return new Promise((resolve) => {
    const p = spawn(process.execPath, [npmCli, 'install', '--no-audit', '--no-fund', '--prefix', join(dir, 'vendor-npm'), ...names], { env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, windowsHide: true });
    let out = ''; p.stdout.on('data', (d) => (out += d)); p.stderr.on('data', (d) => (out += d));
    const t = setTimeout(() => p.kill(), 5 * 60_000);
    p.on('close', (c) => { clearTimeout(t); resolve({ ok: c === 0, output: out.slice(-4000) }); });
  });
}
