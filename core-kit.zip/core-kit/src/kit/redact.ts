import { homedir, userInfo } from 'node:os';
export function makeRedactor(profileValues: string[] = []) {
  const user = userInfo().username, home = homedir();
  const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const rules: [RegExp, string][] = [
    [new RegExp(esc(home), 'gi'), '<HOME>'],
    [new RegExp(`\\\\Users\\\\${esc(user)}(?=\\\\|$)`, 'gi'), '\\Users\\<USER>'],
    [new RegExp(`\\b${esc(user)}\\b`, 'gi'), '<USER>'],
    [/\b(?:gh[pousr]_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9_-]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,})\b/g, '<TOKEN>'],
    [/\b(Bearer|token|apikey|api_key|secret|password)\s*[=:]\s*\S+/gi, '$1=<REDACTED>'],
    [/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '<EMAIL>'],
  ];
  for (const v of profileValues.filter((x) => x && x.length > 2)) rules.push([new RegExp(esc(v), 'gi'), '<PROFILE>']);
  return (s: string) => rules.reduce((t, [r, to]) => t.replace(r, to), s);
}
