#!/usr/bin/env python3
"""Plain-python tests for the Kova scripts (batch 1).  python tests/run_tests.py
Needs esbuild for the bundle/wiring tests (KOVA_ESBUILD, PATH, or /opt/npm-tools); without it those tests report SKIP.
Nothing is written outside temp folders."""
import sys, os, re, json, time, shutil, hashlib, zipfile, tempfile, pathlib, subprocess, traceback, stat
KIT = pathlib.Path(__file__).resolve().parent.parent; SC = KIT / 'scripts'; PY = sys.executable
ES = os.environ.get('KOVA_ESBUILD') or shutil.which('esbuild') or next((p for p in ('/opt/npm-tools/node_modules/.bin/esbuild',) if os.path.exists(p)), None)
ENV = dict(os.environ, KOVA_OUT=tempfile.mkdtemp(prefix='kvout-'))
if ES: ENV['KOVA_ESBUILD'] = ES
R = []; TMP = []


class Skip(Exception): pass


def T(f): R.append(f); return f
def tmp(): d = pathlib.Path(tempfile.mkdtemp(prefix='kvt-')); TMP.append(d); return d
def run(args, cwd=None, env=None): return subprocess.run([str(x) for x in args], cwd=cwd, env=env or ENV, capture_output=True, text=True)
def py(script, *a, cwd=None): return run([PY, SC / script, *a], cwd=cwd)
def need_es():
    if not ES: raise Skip('no esbuild')
def ok(c, m='assertion'):
    if not c: raise AssertionError(m)
def fails(r, m=''): ok(r.returncode != 0, f'expected failure {m}: {r.stdout[-200:]}')
def passes(r, m=''): ok(r.returncode == 0, f'expected success {m}: {(r.stdout + r.stderr)[-300:]}')
def tree(d):
    d = pathlib.Path(d); return {p.relative_to(d).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.rglob('*')) if p.is_file()}
def w(p, s='x'):
    p = pathlib.Path(p); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(s if isinstance(s, bytes) else s.encode()); return p


def kvpart(path, sid, n, kind, files, stamp='1000', links=()):
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr('part.json', json.dumps({'setId': sid, 'part': n, 'total': 5, 'buildStamp': stamp, 'kind': kind}))
        for k, v in files.items(): z.writestr(k, v)
        for k in links:
            zi = zipfile.ZipInfo(k); zi.external_attr = (stat.S_IFLNK | 0o777) << 16; z.writestr(zi, '/etc/passwd')


SID = 'nova-core-x7k3'; ASID = 'demo-tool-x7k3'
FOLD = ['foundation', 'installer', 'runner', 'frame', 'manager']
APP_BP = lambda: {'setId': ASID, 'name': 'Demo', 'type': 'tool', 'buildStamp': '1000', 'parts': [
    {'n': 1, 'owns': ['engine/**'], 'exports': [{'kind': 'backend', 'file': 'engine/index.ts', 'fn': 'register'}]},
    {'n': 2, 'owns': ['ui/*.ts'], 'exports': [{'kind': 'screen', 'file': 'ui/screen.ts', 'fn': 'mount'}]},
    {'n': 3, 'owns': ['ui/*.css']}]}


def core_parts(up, sid=SID):
    up.mkdir(exist_ok=True)
    for i, f in enumerate(FOLD, 1): kvpart(up / f'p{i}.kvpart', sid, i, 'core', {f'src/{f}/index.ts': 'export function create(){}'})
    return up


def app_proj(extra=None):
    d = tmp(); bp = APP_BP(); bp.update(extra or {}); w(d / 'blueprint.json', json.dumps(bp))
    w(d / 'app/engine/index.ts', 'export function register(kova: any): void { kova.registered = true }\n')
    w(d / 'app/ui/screen.ts', 'export function mount(root: any): void {}\n'); w(d / 'app/ui/style.css', 'a{}'); w(d / 'app/ui/extra.css', 'b{}')
    return d


def core_proj(pages=True):
    d = tmp() / 'p'; shutil.copytree(KIT, d, ignore=shutil.ignore_patterns('tests', '__pycache__', 'node_modules'))
    for f in FOLD:
        w(d / f'src/{f}/index.ts', 'export function create() {}\n'); w(d / f'src/{f}/seam.json', '{}'); w(d / f'src/{f}/deps.json', '{"dependencies":{}}')
    w(d / 'src/seal/index.ts', 'export {}\n')
    for p in (('home', 'app', 'busy', 'settings') if pages else ()): w(d / f'src/manager/ui/pages/{p}.ts', 'export default {}\n')
    w(d / 'blueprint.json', json.dumps({'setId': SID, 'name': 'Nova', 'parts': 5, 'buildStamp': '1000'}))
    passes(py('make-manifest.py', cwd=d), 'manifest'); return d


# ---------- 1.1 assemble ----------
@T
def asm_same_file():
    d = tmp(); w(d / 'blueprint.json', json.dumps({'setId': SID, 'name': 'Nova', 'parts': 5})); up = core_parts(d / 'up')
    r = py('assemble.py', up, '.', 'core', cwd=d); passes(r); ok('SameFile' not in r.stderr); ok(r.stdout.startswith('PARTS [1, 2, 3, 4, 5] MISSING [] '), r.stdout)
    ok(len(r.stdout.strip().splitlines()) == 1)
@T
def asm_app_zero_parts():
    d = tmp(); w(d / 'bp/blueprint.json', json.dumps({'setId': ASID, 'name': 'Demo', 'type': 'tool', 'parts': []})); fails(py('assemble.py', d / 'bp', d / 'app', 'app', cwd=d))
@T
def asm_total_from_blueprint():
    d = tmp(); up = d / 'up'; up.mkdir(); w(up / 'blueprint.json', json.dumps(APP_BP())); kvpart(up / 'a.kvpart', ASID, 1, 'app', {'engine/a.ts': 'x'})
    r = py('assemble.py', up, d / 'app', 'app', cwd=d); fails(r); ok('MISSING [2, 3]' in r.stdout, r.stdout)
@T
def asm_hostile_core():
    d = core_proj(); up = core_parts(d.parent / 'up'); before = tree(d)
    kvpart(up / 'p1.kvpart', SID, 1, 'core', {'src/foundation/index.ts': 'x', 'src/kit/seam-types.ts': 'EVIL', 'scripts/build.mjs': 'EVIL', 'package.json': '{}'})
    r = py('assemble.py', up, '.', 'core', cwd=d); fails(r); ok(tree(d) == before, 'kit files changed')
@T
def asm_unsafe_entries():
    for bad in ('/abs.ts', '../x.ts', 'src/foundation/../../x', 'C:/x.ts', 'src\\foundation\\x.ts'):
        d = tmp(); up = core_parts(d / 'up'); w(d / 'blueprint.json', json.dumps({'setId': SID, 'name': 'Nova', 'parts': 5})); kvpart(up / 'p1.kvpart', SID, 1, 'core', {bad: 'x'})
        fails(py('assemble.py', up, d / 't', 'core', cwd=d), bad); ok(not (d / 't').exists(), 'target created for ' + bad)
@T
def asm_symlink():
    d = tmp(); up = core_parts(d / 'up'); w(d / 'blueprint.json', json.dumps({'setId': SID, 'name': 'Nova', 'parts': 5}))
    kvpart(up / 'p1.kvpart', SID, 1, 'core', {}, links=['src/foundation/l.ts']); fails(py('assemble.py', up, d / 't', 'core', cwd=d))
@T
def asm_dup_across_parts():
    d = tmp(); up = d / 'up'; up.mkdir(); bp = APP_BP(); bp['parts'][1]['owns'] = ['engine/**', 'ui/*.ts']; w(up / 'blueprint.json', json.dumps(bp))
    for i in (1, 2, 3): kvpart(up / f'{i}.kvpart', ASID, i, 'app', {'engine/shared.ts': 'x'} if i < 3 else {'ui/a.css': 'x'})
    r = py('assemble.py', up, d / 'app', 'app', cwd=d); fails(r); ok('engine/shared.ts appears in parts 1 and 2' in r.stderr, r.stderr)
@T
def asm_stranger():
    d = tmp(); up = core_parts(d / 'up'); w(d / 'blueprint.json', json.dumps({'setId': SID, 'name': 'Nova', 'parts': 5}))
    kvpart(up / 'x.kvpart', 'other-core-q9q9', 2, 'core', {'src/installer/a.ts': 'x'}); r = py('assemble.py', up, d / 't', 'core', cwd=d); fails(r); ok('KV-PT-002' in r.stderr and 'other-core-q9q9' in r.stderr)
@T
def asm_replace_higher_stamp():
    d = tmp(); up = core_parts(d / 'up'); w(d / 'blueprint.json', json.dumps({'setId': SID, 'name': 'Nova', 'parts': 5}))
    kvpart(up / 'new.kvpart', SID, 1, 'core', {'src/foundation/index.ts': 'NEW'}, stamp='5000'); time.sleep(0.05)
    kvpart(up / 'zold.kvpart', SID, 1, 'core', {'src/foundation/index.ts': 'OLD'}, stamp='2000')   # newer mtime, lower stamp
    r = py('assemble.py', up, d / 't', 'core', cwd=d); passes(r); ok('REPLACED 1' in r.stderr); ok((d / 't/src/foundation/index.ts').read_text() == 'NEW')
@T
def asm_no_blueprint():
    d = tmp(); fails(py('assemble.py', core_parts(d / 'up'), d / 't', 'core', cwd=d))
@T
def asm_app_ok_and_owns():
    d = tmp(); up = d / 'up'; up.mkdir(); w(up / 'blueprint.json', json.dumps(APP_BP()))
    kvpart(up / '1.kvpart', ASID, 1, 'app', {'engine/index.ts': 'x'}); kvpart(up / '2.kvpart', ASID, 2, 'app', {'ui/screen.ts': 'x'}); kvpart(up / '3.kvpart', ASID, 3, 'app', {'ui/style.css': 'x'})
    r = py('assemble.py', up, d / 'app', 'app', cwd=d); passes(r); ok((d / 'app/engine/index.ts').exists() and not (d / 'app/part.json').exists())
    kvpart(up / '3.kvpart', ASID, 3, 'app', {'engine/evil.ts': 'x'}, stamp='9'); d2 = tmp(); fails(py('assemble.py', up, d2 / 'app', 'app', cwd=d2))


# ---------- 1.2 pack-part ----------
def pp(d, *a): return py('pack-part.py', *a, '--out', d / 'o', cwd=d)
@T
def pp_overlap():
    d = app_proj(); bp = json.loads((d / 'blueprint.json').read_text()); bp['parts'][2]['owns'] = ['ui/*.css', 'ui/*.ts']; w(d / 'blueprint.json', json.dumps(bp)); fails(pp(d, 'app', '1'))
@T
def pp_escape_glob():
    d = app_proj(); bp = json.loads((d / 'blueprint.json').read_text()); bp['parts'][0]['owns'] = ['../scripts/*.py']; w(d / 'blueprint.json', json.dumps(bp)); w(d / 'scripts/a.py'); fails(pp(d, 'app', '1'))
@T
def pp_bad_setid():
    d = app_proj({'setId': '../../evil'}); fails(pp(d, 'app', '1')); ok(not (d / 'o').exists() or not list((d / 'o').rglob('*')))
@T
def pp_setid_mismatch_and_reserved():
    fails(pp(app_proj({'setId': 'other-tool-x7k3'}), 'blueprint')); fails(pp(app_proj({'setId': 'demo-tool-7m2q'}), 'blueprint')); passes(pp(app_proj(), 'blueprint'))
@T
def pp_stamp_newer():
    d = app_proj(); passes(pp(d, 'app', '1')); z1 = json.loads(zipfile.ZipFile(next((d / 'o').glob('*.kvpart'))).read('part.json'))['buildStamp']
    ok(int(z1) > 1000); bp = json.loads((d / 'blueprint.json').read_text()); bp['buildStamp'] = str(int(time.time() * 1000) + 10 ** 7); w(d / 'blueprint.json', json.dumps(bp))
    passes(pp(d, 'app', '1')); z2 = json.loads(zipfile.ZipFile(next((d / 'o').glob('*.kvpart'))).read('part.json'))['buildStamp']; ok(int(z2) == int(bp['buildStamp']) + 1, z2)
@T
def pp_part_counts_and_msgs():
    d = app_proj(); bp = json.loads((d / 'blueprint.json').read_text()); bp['parts'] = bp['parts'][:2]; w(d / 'blueprint.json', json.dumps(bp)); fails(pp(d, 'blueprint'))
    d = app_proj({'messages': [{'name': 'media.control'}, {'name': ASID + '.ping'}]}); passes(pp(d, 'blueprint')); d = app_proj({'messages': [{'name': 'bogus.x'}]}); fails(pp(d, 'blueprint'))
    d = app_proj(); bp = json.loads((d / 'blueprint.json').read_text()); bp['parts'][1]['n'] = 3; w(d / 'blueprint.json', json.dumps(bp)); fails(pp(d, 'blueprint'))
@T
def pp_junk_excluded():
    d = app_proj(); w(d / 'app/engine/.env', 'S'); w(d / 'app/engine/__pycache__/a.pyc'); w(d / 'app/engine/node_modules/x.js'); w(d / 'app/engine/ok.ts')
    passes(pp(d, 'app', '1')); names = zipfile.ZipFile(next((d / 'o').glob('*.kvpart'))).namelist(); ok(sorted(names) == ['engine/index.ts', 'engine/ok.ts', 'part.json'], names)
@T
def pp_core_folder_and_count():
    d = core_proj(); passes(pp(d, 'core', '2', 'installer')); fails(pp(d, 'core', '2', 'runner')); bp = json.loads((d / 'blueprint.json').read_text()); bp['parts'] = 6; w(d / 'blueprint.json', json.dumps(bp)); fails(pp(d, 'core', '2', 'installer'))
@T
def mint_id():
    t = py('mint-id.py').stdout.strip(); ok(re.fullmatch(r'[a-z0-9]{4}', t) and t not in ('4f9k', '7m2q', '8z6m', 'ab12', '0000'))


# ---------- 1.3 pack-kvx ----------
def kapp(**k):
    d = tmp() / 'app'; kv = {'name': 'Demo', 'type': 'tool', 'id': ASID, 'edition': 2}; kv.update(k); w(d / 'kova.json', json.dumps(kv, indent=2)); w(d / 'ui/index.html', '<p>'); return d
def kx(d, *a): return py('pack-kvx.py', d, *a, '--out', d.parent / 'o')
@T
def kvx_junk():
    d = kapp(); w(d / '.env', 'S'); w(d / '__pycache__/a.pyc'); w(d / 'node_modules/a.js'); w(d / 'a.ts'); passes(kx(d)); n = zipfile.ZipFile(d.parent / 'o' / f'{ASID}.kvx').namelist(); ok(sorted(n) == ['a.ts', 'kova.json', 'ui/index.html'], n)
@T
def kvx_rejections():
    cases = [dict(edition='two'), dict(edition=0), dict(entry='../scripts/assemble.py'), dict(backend='nope.js'), dict(dependencies={'--registry=http://evil.test': '1.0.0'}),
             dict(dependencies={'x': 'git+https://evil.test/x.git'}), dict(dependencies={'x': 'latest'}), dict(dependencies={'x': 'file:../y'}), dict(dependencies={'x': 'npm:y@1'}),
             dict(opens=['file:TXT']), dict(opens=['link:ftp']), dict(sizeHint='huge')]
    for c in cases: fails(kx(kapp(**c)), str(c))
    for c in (dict(dependencies={'@s/p': '^1.2.0', 'y': '>=1 <2 || 3.x', 'z': '1.0.0 - 2.0.0'}), dict(opens=['file:md', 'link:magnet'], sizeHint='compact')): passes(kx(kapp(**c)), str(c))
@T
def kvx_all_errors_at_once():
    r = kx(kapp(edition='two', sizeHint='huge', opens=['x'])); fails(r); ok(r.stderr.count(';') >= 2, r.stderr)
@T
def kvx_cafe_and_nonlatin():
    passes(kx(kapp(name='Café', id='cafe-tool-x7k3'))); r = kx(kapp(name='日本語', id='x-tool-x7k3')); fails(r); ok('ASCII' in r.stderr, r.stderr)
@T
def kvx_stamp_not_mutating():
    d = kapp(buildStamp='5000'); b = (d / 'kova.json').read_bytes(); passes(kx(d)); s1 = json.loads(zipfile.ZipFile(d.parent / 'o' / f'{ASID}.kvx').read('kova.json'))['buildStamp']; ok((d / 'kova.json').read_bytes() == b, 'source mutated')
    passes(kx(d)); s2 = json.loads(zipfile.ZipFile(d.parent / 'o' / f'{ASID}.kvx').read('kova.json'))['buildStamp']; ok(int(s2) > int(s1) > 5000, (s1, s2))
    far = str(int(time.time() * 1000) + 10 ** 9); d = kapp(buildStamp=far); passes(kx(d)); ok(json.loads(zipfile.ZipFile(d.parent / 'o' / f'{ASID}.kvx').read('kova.json'))['buildStamp'] == str(int(far) + 1))
    passes(kx(d, '--keep-stamp')); ok(json.loads(zipfile.ZipFile(d.parent / 'o' / f'{ASID}.kvx').read('kova.json'))['buildStamp'] == far)


# ---------- 1.4 wire-app ----------
def esm_prepare(d):
    for p in sorted((d / 'app').rglob('*.ts')):
        r = run([ES, p, '--format=esm']); passes(r, str(p)); p.with_suffix('.js').write_text(r.stdout)
    w(d / 'app/package.json', '{"type":"module"}')
def esm_load(d, throw=False):
    w(d / 'run.mjs', "const logs=[];globalThis.kova={log:(l,m)=>logs.push(l),ready:()=>{globalThis.__ready=1}};await import('./app/backend/main.js');console.log(JSON.stringify({ready:globalThis.__ready,logs}));")
    return run(['node', 'run.mjs'], cwd=d)
@T
def wire_esm_loads():
    need_es(); d = app_proj(); passes(py('wire-app.py', cwd=d)); m = (d / 'app/backend/main.ts').read_text(); ok("from '../engine/index.js'" in m, m)
    h = (d / 'app/ui/index.html').read_text(); ok(h.index('extra.css') < h.index('style.css'), h); ok("from './screen.js'" in (d / 'app/ui/app.ts').read_text())
    esm_prepare(d); r = esm_load(d); passes(r); ok(json.loads(r.stdout)['ready'] == 1, r.stdout)
@T
def wire_catches_register_error():
    need_es(); d = app_proj(); passes(py('wire-app.py', cwd=d)); (d / 'app/engine/index.ts').write_text("export function register(kova: any): void { throw new Error('boom') }\n")
    esm_prepare(d); r = esm_load(d); passes(r); o = json.loads(r.stdout); ok(o['ready'] == 1 and o['logs'] == ['error'], r.stdout)
@T
def wire_missing_export():
    d = app_proj(); (d / 'app/ui/screen.ts').unlink(); r = py('wire-app.py', cwd=d); fails(r); ok('ui/screen.ts' in r.stderr + r.stdout)
@T
def wire_then_verify_app():
    need_es(); d = app_proj(); passes(py('wire-app.py', cwd=d)); passes(py('verify.py', 'app', cwd=d))


# ---------- 1.5 pack-core ----------
def pc(d): return py('pack-core.py', '--out', d.parent / 'co', cwd=d)
@T
def core_pack_ok_and_junk():
    need_es(); d = core_proj(); w(d / '.env', 'S'); w(d / 'src/runner/__pycache__/a.pyc'); passes(pc(d)); o = d.parent / 'co'; ok({p.name for p in o.iterdir()} == {f'{SID}.kvcore', f'{SID}-run.zip', f'{SID}-style-spec.md'}, list(o.iterdir()))
    n = zipfile.ZipFile(o / f'{SID}.kvcore').namelist(); ok(not any('.env' in x or '__pycache__' in x for x in n) and 'kit.manifest.json' in n, n)
@T
def core_pack_rejects_stubs():
    for mut in ('stub', 'seam', 'page', 'tamper'):
        d = core_proj()
        if mut == 'stub': w(d / 'src/runner/index.ts', 'export const x = 1\n')
        if mut == 'seam': (d / 'src/frame/seam.json').unlink()
        if mut == 'page': (d / 'src/manager/ui/pages/busy.ts').unlink()
        if mut == 'tamper': w(d / 'src/kit/rpc.ts', 'EVIL')
        fails(pc(d), mut); ok(not (d.parent / 'co').exists() or not list((d.parent / 'co').iterdir()), mut + ' wrote output')


# ---------- 1.6 verify ----------
BLK = lambda b, f='': f'### [S2.1]\n<!-- BEGIN S2.1 -->\n{b}\n<!-- END S2.1 -->\n`FP:S2.1:{f or "00000000"}`\n'
@T
def verify_fp():
    d = tmp(); f = w(d / 'a.md', 'x `CONTRACT-FP:deadbeef`\n' + BLK('hello')); fails(py('verify.py', 'fp', f)); passes(py('verify.py', 'fp', '--write', f)); passes(py('verify.py', 'fp', f))
    ok(hashlib.sha256(b'hello').hexdigest()[:8] in f.read_text()); w(f, f.read_text().replace('hello', 'hellp')); fails(py('verify.py', 'fp', f)); passes(py('fp.py', f)); passes(py('verify.py', 'fp', f))
@T
def verify_fp_real_kit_ok():
    passes(py('verify.py', 'fp', *sorted(str(p) for p in (KIT / 'guides').glob('*.md')), *sorted(str(p) for p in (KIT.parent / 'app-kit/guides').glob('*.md'))))
@T
def verify_contract():
    d = tmp(); h = hashlib.sha256(b'a').hexdigest()[:8]; w(d / 'a.md', BLK('a', h)); w(d / 'b.md', BLK('a', h)); passes(py('verify.py', 'contract', d))
    w(d / 'b.md', BLK('b', hashlib.sha256(b'b').hexdigest()[:8])); fails(py('verify.py', 'contract', d)); w(d / 'b.md', BLK('a', h) + 'see S10 and S14.\n'); r = py('verify.py', 'contract', d); fails(r); ok('S10' in r.stdout and 'S14' in r.stdout)
    w(d / 'b.md', BLK('a', h) + '`CONTRACT-FP:11111111`\n'); w(d / 'a.md', BLK('a', h) + '`CONTRACT-FP:22222222`\n'); fails(py('verify.py', 'contract', d))
@T
def verify_contract_reports_known_dangling():
    r = py('verify.py', 'contract', KIT / 'guides'); ok('S10' in r.stdout or 'S12' in r.stdout, 'dangling refs should be reported while guides still carry them: ' + r.stdout[-200:])
@T
def verify_blueprint():
    d = app_proj(); passes(py('verify.py', 'blueprint', d / 'blueprint.json')); w(d / 'bad.json', json.dumps({'setId': 'x', 'name': 'n'})); fails(py('verify.py', 'blueprint', d / 'bad.json'))
@T
def verify_core_positive_and_negatives():
    need_es(); d = core_proj(); r = py('verify.py', 'core', cwd=d); passes(r); ok('SKIP typecheck (no tsconfig)' in r.stdout, r.stdout)
    muts = {'no seam': lambda d: (d / 'src/frame/seam.json').unlink(), 'no create': lambda d: w(d / 'src/frame/index.ts', 'export const a=1'), 'no page': lambda d: (d / 'src/manager/ui/pages/settings.ts').unlink(),
            'bundle syntax': lambda d: w(d / 'src/manager/ui/pages/home.ts', 'export default {{{'), 'collision': lambda d: (w(d / 'src/frame/renderer-a.ts', 'export {}'), w(d / 'src/runner/renderer-a.ts', 'export {}')),
            'html collision': lambda d: (w(d / 'src/frame/ui/x.css', 'a{}'), w(d / 'src/runner/ui/x.css', 'b{}')), 'kit tamper': lambda d: w(d / 'src/kit/rpc.ts', 'EVIL'),
            'script tamper': lambda d: w(d / 'scripts/build.mjs', 'EVIL')}
    for k, m in muts.items():
        d = core_proj(); m(d); fails(py('verify.py', 'core', cwd=d), k)
@T
def verify_app_negatives():
    need_es(); base = lambda: (lambda d: (py('wire-app.py', cwd=d), d)[1])(app_proj())
    d = base(); passes(py('verify.py', 'app', cwd=d))
    d = base(); w(d / 'app/ui/screen.ts', "import { x } from '../engine/index';\nexport function mount(r:any){}\n"); r = py('verify.py', 'app', cwd=d); fails(r); ok('extensionless' in r.stdout)
    d = base(); w(d / 'app/ui/screen.ts', "import { x } from './nope.js';\nexport function mount(r:any){}\n"); fails(py('verify.py', 'app', cwd=d))
    d = base(); w(d / 'app/ui/screen.ts', 'export function mount(r:any){{{'); fails(py('verify.py', 'app', cwd=d))
    d = base(); k = json.loads((d / 'app/kova.json').read_text()); k['edition'] = 'two'; w(d / 'app/kova.json', json.dumps(k)); fails(py('verify.py', 'app', cwd=d))
@T
def manifest_clean_kit():
    passes(py('make-manifest.py', '--check', cwd=KIT), 'run `python scripts/make-manifest.py` after editing kit files')


# ---------- 1.9 mjs ----------
@T
def setup_mjs_checks():
    d = core_proj(); w(d / 'package.json', json.dumps({'dependencies': {'electron': '^33.0.0'}})); w(d / 'src/foundation/deps.json', '{"dependencies":{"left-pad":"^1.0.0"}}'); w(d / 'src/runner/deps.json', '{"dependencies":{"left-pad":"^2.0.0"}}')
    r = run(['node', 'scripts/setup.mjs'], cwd=d); fails(r); ok('left-pad' in r.stderr and '^1.0.0' in r.stderr and '^2.0.0' in r.stderr, r.stderr)
    d = core_proj(); (d / 'src/manager/ui/pages/busy.ts').unlink(); r = run(['node', 'scripts/setup.mjs'], cwd=d); fails(r); ok('busy' in r.stderr and 'part 5' in r.stderr, r.stderr)
    d = core_proj(); w(d / 'src/manager/ui/pages/x.d.ts', 'export {}'); passes(run(['node', 'scripts/setup.mjs'], cwd=d)); ok('x.d' not in (d / 'src/generated/pages.ts').read_text())
@T
def build_mjs_collision():
    if not os.path.isdir('/opt/npm-tools/node_modules/esbuild'): raise Skip('no esbuild module')
    d = core_proj(); os.symlink('/opt/npm-tools/node_modules', d / 'node_modules'); w(d / 'src/frame/renderer-a.ts', 'export {}'); w(d / 'src/runner/renderer-a.ts', 'export {}')
    r = run(['node', 'scripts/build.mjs'], cwd=d); fails(r); ok('src/frame/renderer-a.ts' in r.stderr and 'src/runner/renderer-a.ts' in r.stderr, r.stderr)
@T
def apply_part_mjs():
    probe = tmp() / 'p.kvpart'; kvpart(probe, SID, 1, 'core', {}); env = None
    if run(['tar', '-xOf', probe, 'part.json']).returncode != 0:   # GNU tar cannot read zip: use a stand-in with the same flags as Windows/bsdtar
        sd = tmp(); w(sd / 'tar', "#!" + PY + "\nimport sys,zipfile\na=sys.argv[1:];z=zipfile.ZipFile(a[1])\nif a[0]=='-xOf': sys.stdout.buffer.write(z.read(a[2]))\nelif a[0]=='-tf': print('\\n'.join(z.namelist()))\nelse: z.extractall(a[a.index('-C')+1])\n"); (sd / 'tar').chmod(0o755); env = dict(ENV, PATH=str(sd) + os.pathsep + os.environ['PATH'])
    d = core_proj(); w(d / 'core.json', json.dumps({'id': SID})); w(d / 'src/installer/stale.ts', 'old'); kvpart(d / 'good.kvpart', SID, 2, 'core', {'src/installer/index.ts': 'export function create(){}'}); passes(run(['node', 'scripts/apply-part.mjs', 'good.kvpart'], cwd=d, env=env))
    ok(not (d / 'src/installer/stale.ts').exists() and not (d / 'part.json').exists())
    kvpart(d / 'bad.kvpart', 'other-core-q9q9', 2, 'core', {'src/installer/index.ts': 'x'}); fails(run(['node', 'scripts/apply-part.mjs', 'bad.kvpart'], cwd=d, env=env))


# ---------- sync ----------
@T
def sync_kits():
    d = tmp(); shutil.copytree(KIT.parent / 'app-kit', d / 'app-kit'); passes(run([PY, KIT / 'tools/sync-kits.py', d / 'app-kit']))
    for f in ('assemble.py', 'pack-part.py', 'pack-kvx.py', 'wire-app.py', 'verify.py', 'fp.py', 'mint-id.py', 'kvlib.py'): ok((d / 'app-kit/scripts' / f).read_bytes() == (SC / f).read_bytes(), f)


if __name__ == '__main__':
    p = s = 0; bad = []
    for f in R:
        try: f(); p += 1
        except Skip as e: s += 1; bad.append(f'SKIP {f.__name__}: {e}')
        except Exception as e: bad.append(f'FAIL {f.__name__}: {str(e)[:220]!r} @ {traceback.extract_tb(sys.exc_info()[2])[-1].lineno}')
    for t in TMP: shutil.rmtree(t, ignore_errors=True)
    shutil.rmtree(ENV['KOVA_OUT'], ignore_errors=True)
    print('\n'.join(bad)); print(f'{p} passed / {len(R)} total' + (f' ({s} skipped)' if s else '')); sys.exit(0 if p + s == len(R) and not [b for b in bad if b.startswith('FAIL')] else 1)
