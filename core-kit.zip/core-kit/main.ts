import { app, dialog } from 'electron';
import { join } from 'node:path';
import { singleInstance, onFiles } from './src/kit/handoff';
import { registerRpc } from './src/kit/rpc';
import { registerIcons } from './src/kit/icons';
import { createFrame } from './src/kit/window';
import * as F from './src/foundation';
import * as I from './src/installer';
import * as R from './src/runner';
import * as S from './src/seal';
import * as FR from './src/frame';

if (singleInstance()) {
  app.whenReady().then(async () => {
    try {
      const foundation = F.create();
      const installer = I.create(foundation);
      const runner = R.create(foundation, installer);
      const seal = S.create(foundation, installer, runner);
      registerIcons();
      // The window and its autohide controls belong to the kit. Parts never create windows.
      const window = createFrame({ shellHtml: join(__dirname, 'ui', 'shell.html'), shellPreload: join(__dirname, 'preload-shell.js') });
      const frame = FR.create({ foundation, installer, runner, seal, window });
      registerRpc({ foundation, installer, runner, seal, frame });
      onFiles((f) => frame.handleFiles(f));
      await frame.start();
      foundation.quit.markStartedOk();
    } catch (e: any) { dialog.showErrorBox('Kova could not start', String(e?.stack ?? e).slice(0, 1500)); app.quit(); }
  });
}
