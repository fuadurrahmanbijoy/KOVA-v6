#!/usr/bin/env python3
"""Seal step 2 (run inside the project folder): python scripts/pack-core.py [--out DIR]
Checks the five parts (index.ts exporting create, seam.json, deps.json, the four Manager pages), the Seal, the kit manifest, then runs
`python scripts/verify.py core` and refuses to pack when it fails. Writes core.json and START-HERE.txt, then <id>.kvcore, <id>-run.zip and <id>-style-spec.md
into --out / env KOVA_OUT / /mnt/user-data/outputs (if it exists) / ../out. Junk (.env, node_modules, __pycache__ ...) is never packed."""
import sys, os, json, zipfile, pathlib, shutil, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kvlib as L
a = sys.argv[1:]; o = None
if '--out' in a: i = a.index('--out'); o = a[i + 1]; del a[i:i + 2]
bp = json.load(open('blueprint.json', encoding='utf8')); cid = bp['setId']; name = bp.get('name', cid); stamp = str(bp.get('buildStamp') or L.now_ms())
if not L.SETID_RE.match(str(cid)): sys.exit('FAIL setId is not valid: ' + str(cid))
miss = L.core_problems('.')
if miss: sys.exit('FAIL missing or incomplete parts (core-2-build-parts / core-3-seal-parts):\n  ' + '\n  '.join(miss))
r = subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'verify.py'), 'core'], capture_output=True, text=True)
if r.returncode: sys.exit('FAIL verify core:\n' + '\n'.join((r.stdout + r.stderr).strip().splitlines()[-15:]))
out = pathlib.Path(o or os.environ.get('KOVA_OUT') or ('/mnt/user-data/outputs' if os.path.isdir('/mnt/user-data/outputs') else '../out')); out.mkdir(parents=True, exist_ok=True)
json.dump({'name': name, 'type': 'core', 'id': cid, 'edition': 2, 'runtimeEdition': 1, 'buildStamp': stamp, 'entry': 'main.ts', 'parts': 5}, open('core.json', 'w'), indent=2)
t = open('templates/START-HERE.txt', encoding='utf8').read().replace('{{NAME}}', name).replace('{{STAMP}}', stamp).replace('{{EDITION}}', '2')
open('START-HERE.txt', 'w', encoding='utf8').write(t)
skip = {'dist', 'part.json', 'blueprint.json', 'guides', 'tests', 'tools'}
def pack(dest):
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(pathlib.Path('.').rglob('*')):
            if p.is_file() and not p.is_symlink() and not (set(p.parts) & skip) and not L.is_junk(p.parts): z.write(p, p.as_posix())
pack(out / f'{cid}.kvcore'); pack(out / f'{cid}-run.zip')
if os.path.exists('templates/style-spec.md'): shutil.copy('templates/style-spec.md', out / f'{cid}-style-spec.md')
print('OK', cid)
