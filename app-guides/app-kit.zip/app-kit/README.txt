KOVA APP KIT · edition 2 (rev 4). Used by the app guides; the agent unzips it and runs the scripts. You do not run anything yourself.
scripts/ is copied from core-kit/scripts (tools/sync-kits.py). mint-id.py makes the id tag; verify.py app (syntax, import graph, kova.json) runs before packing; wire-app.py, pack-part.py, pack-kvx.py, assemble.py do the rest.
Import rule: every relative import uses an explicit .js extension (import { x } from './util.js' for util.ts); styles go in ui/*.css; no JSX.
