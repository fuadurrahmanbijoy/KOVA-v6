# PROFILE APP · build rules · edition 2
Build it as a small app (read `guides/small-app.md` too) with these fixed jobs.
**Imports.** All relative imports use an explicit `.js` extension (`import { x } from './util.js'` even though the source file is `util.ts`); `wire-app.py` now emits `.js` specifiers too.
No CSS imports from JS: put styles in `ui/*.css` (the Seal links every `ui/*.css`). No JSX.
The Core installs `{"type":"module"}` for you; do not add a `package.json`.


**Profile app** Fixed jobs: edit every rich-profile field (S2.7), the **rail labels** toggle, **Share with apps** per group (default basics only, say it is a courtesy), a **Guides** section (view, copy, export every file in `<root>\guides\`, with **Add guide**), the avatar. Find the Library root by reading `%LOCALAPPDATA%\Kova\root.json` first, then `C:\Kova\root.json` (`{"root":"<path>"}`, default `C:\Kova`). Write `<root>\profile\basics.json`, `personal.json`, `avatar.*` exactly per S2.7, `format:1`, atomically (write a temp file, then rename; retry on `EPERM`); only this app writes them. The accent must be `#RRGGBB` (the Core ignores anything else). Keep `railLabels` as the only chrome toggle. Following the Core's Style Spec is recommended.

Name: "Profile", type: `profile` (the Core then pins it to the bottom of its rail). Icon: `person`.
