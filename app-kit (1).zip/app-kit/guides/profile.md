# PROFILE APP · build rules · edition 2
Build it as a small app (read `guides/small-app.md` too) with these fixed jobs.

**Profile app** Fixed jobs: edit every rich-profile field (S2.7), the **rail labels** toggle, **Share with apps** per group (default basics only, say it is a courtesy), a **Guides** section (view, copy, export every file in `<root>\guides\`, with **Add guide**), the avatar. Find the Library via `C:\Kova\root.json` (`{"root":"<path>"}`, default `C:\Kova`). Write `<root>\profile\basics.json`, `personal.json`, `avatar.*` exactly per S2.7, `format:1`, atomically (temp file then rename); only this app writes them. (The Core has no top bar, so there is no top-bar toggle.) Following the Core's Style Spec is recommended.

Name: "Profile", type: `profile` (the Core then pins it to the bottom of its rail). Icon: `person`.
