# APP REPAIR (any new chat) · edition 2
Inputs: the **repair bundle** (`<id>-repair.zip`) and **app-kit.zip**. Nothing else; the original chat is not needed.
1. `mkdir -p proj/app && cd proj && unzip -oq /mnt/user-data/uploads/app-kit.zip -d /tmp/k && cp -r /tmp/k/app-kit/. . && unzip -oq /mnt/user-data/uploads/<id>-repair.zip -d /tmp/b && cp -r /tmp/b/app/. app/ 2>/dev/null || cp -r /tmp/b/. app/` (the bundle holds the app's whole folder and `repair-note.txt`).
2. Read the first 20 lines of `repair-note.txt`. Fix every listed error with the smallest edits; keep `id`, name, type, saved-data format and message names unchanged. Return complete files.
3. `python scripts/pack-kvx.py app` → `<id>.kvx` (a newer stamp is added automatically, so Kova installs it as an update and keeps the old version).
```
Fixed: <one line per fix> → <id>.kvx
Not fixed: <list or "nothing">
NEXT STEPS
1. Download the .kvx file.
2. Drag it onto your Kova Core (or double-click it, or press "Add app").
3. If it still fails, press "Copy repair prompt" again and repeat in a new chat.
```
