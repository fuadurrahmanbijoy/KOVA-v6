KOVA APP KIT (rev 4). Used by the app guides; the agent unzips it and runs scripts/pack-kvx.py etc. You do not run anything yourself.
scripts/ is copied from core-kit/scripts (tools/sync-kits.py); verify.py app checks wiring before packing.
