"""Shared helpers for the Kova scripts (imported by assemble, pack-*, wire-app, verify). Not run directly."""
import re, os, json, glob, pathlib, fnmatch, unicodedata, shutil, subprocess

SETID_RE = re.compile(r'^[a-z0-9]+(-[a-z0-9]+)*-[a-z0-9]{4}$')
RESERVED_TAGS = ('4f9k', '7m2q', '8z6m', 'ab12', '0000')
VOCAB = ('media.nowPlaying', 'media.control', 'download.start', 'download.finished', 'download.progress', 'alarm.ringing',
         'alarm.dismissed', 'file.selected', 'link.clicked', 'note.created', 'calendar.eventSoon', 'clipboard.changed')
CORE_FOLDERS = {1: 'foundation', 2: 'installer', 3: 'runner', 4: 'frame', 5: 'manager'}
PAGES = ('home', 'app', 'busy', 'settings')
EXCLUDE = ('.env', '.env.*', 'node_modules', '__pycache__', '.git', '.gitignore', '*.pyc', 'Thumbs.db', '.DS_Store',
           'PROGRESS.md', '__standins__', '*.tmp-*', 'vendor-npm')


def is_junk(parts):
    return any(fnmatch.fnmatchcase(p, g) for p in parts for g in EXCLUDE)


def slug(s):
    s = unicodedata.normalize('NFKD', str(s)).encode('ascii', 'ignore').decode()
    return re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-')


def now_ms():
    import time
    return int(time.time() * 1000)


def to_int(v, d=0):
    try: return int(str(v))
    except Exception: return d


def glob_re(g):
    """Translate a glob (with ** support, like glob.glob(recursive=True)) into a compiled regex."""
    i, o = 0, ''
    while i < len(g):
        c = g[i]
        if g.startswith('**/', i): o += '(?:.*/)?'; i += 3; continue
        if g.startswith('**', i): o += '.*'; i += 2; continue
        o += '[^/]*' if c == '*' else '[^/]' if c == '?' else re.escape(c); i += 1
    return re.compile('^' + o + '$')


def bad_entry(name):
    """Return a reason string when a zip/path entry name is unsafe, else ''."""
    n = name
    if n.startswith('/') or n.startswith('\\'): return 'absolute path'
    if re.match(r'^[A-Za-z]:', n): return 'drive letter'
    if '\\' in n: return 'backslash'
    if '..' in n.split('/'): return '".." segment'
    if '\x00' in n: return 'NUL byte'
    return ''


def is_core_bp(bp):
    return bp.get('kind') == 'core' or bool(re.search(r'-core-[a-z0-9]{4}$', str(bp.get('setId') or bp.get('id') or '')))


def app_files(bp_part, root='app'):
    """Expand one part's owns globs against root; returns sorted relative posix paths (junk excluded)."""
    r = pathlib.Path(root); out = set()
    for g in bp_part.get('owns', []):
        for f in glob.glob(str(r / g), recursive=True):
            p = pathlib.Path(f)
            if p.is_file() and not is_junk(p.relative_to(r).parts): out.add(p.relative_to(r).as_posix())
    return sorted(out)


def validate_blueprint(bp, root='app'):
    """Return a list of error strings (empty = valid). Same code for pack-part, verify blueprint."""
    e = []
    if not isinstance(bp, dict): return ['blueprint must be a JSON object']
    sid = bp.get('setId') or bp.get('id')
    if not isinstance(sid, str) or not SETID_RE.match(sid): e.append('setId must match ^[a-z0-9]+(-[a-z0-9]+)*-[a-z0-9]{4}$')
    if not bp.get('name'): e.append('blueprint missing name')
    core = is_core_bp(bp)
    if isinstance(sid, str) and SETID_RE.match(sid):
        if sid[-4:] in RESERVED_TAGS: e.append(f'tag "{sid[-4:]}" is a guide example tag; run scripts/mint-id.py')
        if bp.get('name'):
            if not slug(bp['name']): e.append('name has no ASCII letters or digits; use an ASCII brand name')
            elif core:
                if sid != f"{slug(bp['name'])}-core-{sid[-4:]}": e.append('setId must be <name-slug>-core-<tag>')
            elif bp.get('type'):
                if not slug(bp['type']): e.append('type has no ASCII letters or digits')
                elif sid != f"{slug(bp['name'])}-{slug(bp['type'])}-{sid[-4:]}": e.append('setId must be <name-slug>-<type-slug>-<tag>')
    parts = bp.get('parts')
    if core:
        n = len(parts) if isinstance(parts, list) else parts
        if n != 5: e.append('core blueprint needs parts == 5')
        return e
    if not isinstance(parts, list) or not 3 <= len(parts) <= 6: e.append('app blueprint needs 3 to 6 parts'); return e
    seen_globs = {}; expanded = {}
    for i, p in enumerate(parts, 1):
        if not isinstance(p, dict) or p.get('n') != i: e.append(f'parts[{i-1}].n must be {i} (sequential from 1)'); continue
        owns = p.get('owns')
        if not isinstance(owns, list) or not owns or not all(isinstance(g, str) for g in owns): e.append(f'part {i}: owns must be a non-empty list of globs'); continue
        ok = True
        for g in owns:
            r = bad_entry(g)
            if r or os.path.isabs(g): e.append(f'part {i}: owns "{g}" must be relative and without ".." ({r or "absolute"})'); ok = False
            elif g in seen_globs and seen_globs[g] != i: e.append(f'owns "{g}" appears in parts {seen_globs[g]} and {i}')
            else: seen_globs[g] = i
        if not ok: continue
        expanded[i] = set(app_files(p, root))
        for x in p.get('exports', []) or []:
            f = x.get('file') if isinstance(x, dict) else None
            if not f or not any(glob_re(g).match(f) for g in owns): e.append(f'part {i}: export file "{f}" is not matched by its own owns')
    ks = sorted(expanded)
    for a in range(len(ks)):
        for b in range(a + 1, len(ks)):
            for f in sorted(expanded[ks[a]] & expanded[ks[b]]): e.append(f'{f} appears in parts {ks[a]} and {ks[b]}')
    msgs = list(bp.get('messages') or [])
    for p in parts:
        if isinstance(p, dict): msgs += list(p.get('messages') or [])
    for m in msgs:
        nm = m.get('name') if isinstance(m, dict) else m
        if isinstance(nm, str) and not (nm in VOCAB or (isinstance(sid, str) and nm.startswith(sid))): e.append(f'message "{nm}" must start with the setId or be in the S2.5 vocabulary')
    return e


SEMVER_RE = re.compile(r'^[0-9xX^~<>=| .-]+$')
PKG_RE = re.compile(r'^(?:@[a-z0-9][a-z0-9._-]*/)?[a-z0-9][a-z0-9._-]*$')
OPENS_RE = re.compile(r'^(file:[a-z0-9]+|link:(http|https|magnet))$')


def inside(root, rel):
    try:
        r = pathlib.Path(root).resolve(); p = (r / rel).resolve(); p.relative_to(r); return p
    except Exception: return None


def validate_kova(k, root):
    """kova.json validation shared by pack-kvx and verify app. Returns list of errors (all at once)."""
    e = []
    if not isinstance(k, dict): return ['kova.json must be an object']
    for f in ('name', 'type', 'edition'):
        if f not in k: e.append('missing ' + f)
    ed = k.get('edition')
    if 'edition' in k and (isinstance(ed, bool) or not isinstance(ed, int) or ed < 1): e.append('edition must be an integer >= 1')
    iid = k.get('id', '')
    if 'name' in k and 'type' in k:
        if not slug(k['name']) or not slug(k['type']): e.append('name and type need ASCII letters or digits; use an ASCII brand name')
        elif not re.fullmatch(re.escape(slug(k['name'])) + '-' + re.escape(slug(k['type'])) + r'-[a-z0-9]{4}', str(iid)): e.append('id must be <name>-<type>-<4char tag>')
    for key, dflt in (('entry', 'ui/index.html'), ('backend', None)):
        v = k.get(key, dflt)
        if v is None: continue
        if not isinstance(v, str) or bad_entry(v) or os.path.isabs(v): e.append(f'{key} must be a relative path inside the folder'); continue
        p = inside(root, v)
        if p is None: e.append(f'{key} escapes the folder')
        elif not p.is_file(): e.append(f'{key} file missing: {v}')
    deps = k.get('dependencies', {})
    if not isinstance(deps, dict): e.append('dependencies must be an object')
    else:
        for n, v in deps.items():
            if not PKG_RE.match(n): e.append(f'dependency name not allowed: {n}')
            if not (isinstance(v, str) and v.strip() and SEMVER_RE.match(v) and re.search(r'[0-9xX]', v)): e.append(f'dependency {n}: version must be a plain semver range')
    op = k.get('opens', [])
    if not isinstance(op, list) or not all(isinstance(x, str) and OPENS_RE.match(x) for x in op): e.append('opens entries must be file:<ext> or link:http|https|magnet')
    if 'sizeHint' in k and k['sizeHint'] not in ('compact', 'regular', 'large'): e.append('sizeHint must be compact|regular|large')
    return e


def core_problems(root='.'):
    """Required files per Core part. Returns list of problem strings."""
    r = pathlib.Path(root); m = []
    for n, f in CORE_FOLDERS.items():
        for fn in ('index.ts', 'seam.json', 'deps.json'):
            if not (r / 'src' / f / fn).is_file(): m.append(f'src/{f}/{fn} missing (part {n})')
        ix = r / 'src' / f / 'index.ts'
        if ix.is_file() and not re.search(r'\bexport\s+(?:async\s+)?(?:function\*?|const|let|var|class)\s+create\b|\bexport\s*\{[^}]*\bcreate\b[^}]*\}', ix.read_text('utf8', 'replace')):
            m.append(f'src/{f}/index.ts does not export create')
    if not (r / 'src' / 'seal' / 'index.ts').is_file(): m.append('src/seal/index.ts missing (seal)')
    miss = [p for p in PAGES if not (r / 'src' / 'manager' / 'ui' / 'pages' / (p + '.ts')).is_file()]
    if miss: m.append('manager pages missing: ' + ', '.join(miss))
    return m


def find_esbuild():
    c = [os.environ.get('KOVA_ESBUILD'), 'node_modules/.bin/esbuild', str(pathlib.Path(__file__).resolve().parent.parent / 'node_modules/.bin/esbuild'), shutil.which('esbuild')]
    for x in c:
        if x and os.path.isfile(x): return [x]
    return None


def find_tsc():
    for x in ('node_modules/.bin/tsc', str(pathlib.Path(__file__).resolve().parent.parent / 'node_modules/.bin/tsc')):
        if os.path.isfile(x): return [x]
    return None
