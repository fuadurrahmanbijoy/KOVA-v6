#!/usr/bin/env python3
"""Pack an app folder into <id>.kvx (zip with kova.json at the root). Reports every problem at once.
Usage: python pack-kvx.py <folder> [stamp] [--out DIR] [--keep-stamp]
Output: <id>.kvx in --out / env KOVA_OUT / /mnt/user-data/outputs (if it exists) / current folder.
The source folder is never changed. The zip carries a stamped copy of kova.json: buildStamp = max(now_ms or [stamp], previous buildStamp + 1).
--keep-stamp packs kova.json exactly as it is. Junk (.env, node_modules, __pycache__, .git ...) is never packed."""
import sys, os, json, zipfile, pathlib, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kvlib as L


def main():
    ap = argparse.ArgumentParser(usage='pack-kvx.py <folder> [stamp] [--out DIR] [--keep-stamp]')
    ap.add_argument('folder'); ap.add_argument('stamp', nargs='?'); ap.add_argument('--out'); ap.add_argument('--keep-stamp', action='store_true')
    a = ap.parse_args(); root = pathlib.Path(a.folder)
    out = pathlib.Path(a.out or os.environ.get('KOVA_OUT') or ('/mnt/user-data/outputs' if os.path.isdir('/mnt/user-data/outputs') else '.'))
    try: raw = (root / 'kova.json').read_bytes(); k = json.loads(raw.decode('utf8'))
    except Exception as e: sys.exit('FAIL kova.json: ' + str(e))
    errs = L.validate_kova(k, root)
    files = []
    for p in sorted(root.rglob('*')):
        rel = p.relative_to(root)
        if L.is_junk(rel.parts) or p.is_dir(): continue
        if p.is_symlink(): errs.append(f'symlink not allowed: {rel.as_posix()}'); continue
        if rel.as_posix() != 'kova.json': files.append((p, rel.as_posix()))
    if errs: sys.exit('FAIL ' + '; '.join(errs))
    if not a.keep_stamp:
        cand = L.to_int(a.stamp) if a.stamp else L.now_ms()
        k['buildStamp'] = str(max(cand, L.to_int(k.get('buildStamp')) + 1)); raw = json.dumps(k, indent=2).encode('utf8')
    out.mkdir(parents=True, exist_ok=True); dest = out / f'{k["id"]}.kvx'
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('kova.json', raw)
        for p, arc in files: z.write(p, arc)
    print('OK', dest)


main()
