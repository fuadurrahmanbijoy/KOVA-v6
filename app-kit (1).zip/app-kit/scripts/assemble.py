#!/usr/bin/env python3
"""Seal step 1. python scripts/assemble.py <uploads-dir> <target-dir> <core|app>
Validates every .kvpart in a temp dir first, then merges into <target-dir>. Nothing is written to the target on failure.
Core: entries must be under src/<folder>/ (1..5 = foundation, installer, runner, frame, manager). App: entries must match the part's `owns`.
Rejects absolute, '..', drive-letter, backslash and symlink entries, files in two parts (KV-PT-004), parts of another setId (KV-PT-002).
Same part twice: the higher part.json.buildStamp wins (tie: newer file) and 'REPLACED n' goes to stderr.
The blueprint comes from <uploads>/blueprint*.json, else ./blueprint.json; none = exit 2.
Prints exactly one stdout line: PARTS [...] MISSING [...] SETS [...]  (errors go to stderr). Exit 2 on any failure."""
import sys, os, json, zipfile, pathlib, shutil, glob, tempfile, stat
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kvlib as L


def die(parts, missing, sets, errs):
    print('PARTS', sorted(parts), 'MISSING', missing, 'SETS', sorted(sets))
    for m in errs: print(m, file=sys.stderr)
    sys.exit(2)


def load(f):
    try: return json.load(open(f, encoding='utf8'))
    except Exception: return None


def main():
    if len(sys.argv) < 4 or sys.argv[3] not in ('core', 'app'): sys.exit(__doc__)
    up, tgt, kind = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), sys.argv[3]
    errs = []
    cands = sorted(glob.glob(str(up / 'blueprint*.json')))
    bpf = max(cands, key=lambda f: (L.to_int((load(f) or {}).get('buildStamp')), f)) if cands else ('blueprint.json' if os.path.isfile('blueprint.json') else None)
    if not bpf: die([], [], [], ['KV-PT-001 no blueprint (put blueprint*.json in the uploads folder)'])
    bp = load(bpf)
    if not isinstance(bp, dict): die([], [], [], ['KV-PT-001 blueprint unreadable'])
    sid = bp.get('setId') or bp.get('id')
    if kind == 'core': total = 5
    else:
        total = len(bp['parts']) if isinstance(bp.get('parts'), list) else 0
        if total == 0: die([], [], [sid] if sid else [], ['KV-PT-001 blueprint lists no parts'])
    cand = {}; sets = set(); strangers = []
    for f in sorted(up.glob('*.kvpart'), key=lambda p: (p.stat().st_mtime, p.name)):
        try:
            z = zipfile.ZipFile(f); pj = json.loads(z.read('part.json'))
        except Exception as ex: errs.append(f'KV-PT-001 {f.name}: unreadable ({ex})'); continue
        if pj.get('kind') != kind: continue
        sets.add(pj.get('setId'))
        if pj.get('setId') != sid: strangers.append(f'{f.name} (setId {pj.get("setId")})'); continue
        n = pj.get('part')
        if not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= total: errs.append(f'KV-PT-001 {f.name}: part {n} out of range 1..{total}'); continue
        key = (L.to_int(pj.get('buildStamp')), f.stat().st_mtime)
        if n in cand:
            print(f'REPLACED {n}', file=sys.stderr)
            if key < cand[n][0]: continue
        cand[n] = (key, f, z)
    if strangers: errs.append('KV-PT-002 parts from another set: ' + ', '.join(strangers))
    entries = {}; owner = {}
    for n, (_, f, z) in sorted(cand.items()):
        pats = [] if kind == 'core' else [L.glob_re(g) for g in (bp['parts'][n - 1].get('owns') or [])]
        for zi in z.infolist():
            name = zi.filename
            if name == 'part.json': continue
            r = L.bad_entry(name)
            if r: errs.append(f'KV-PT-003 {f.name}: {name!r} {r}'); continue
            if (zi.external_attr >> 16) & 0o170000 == stat.S_IFLNK: errs.append(f'KV-PT-003 {f.name}: {name} is a symlink'); continue
            if name.endswith('/'): continue
            if kind == 'core':
                if not name.startswith(f'src/{L.CORE_FOLDERS[n]}/'): errs.append(f'KV-PT-003 {f.name}: {name} is outside src/{L.CORE_FOLDERS[n]}/'); continue
            elif not any(p.match(name) for p in pats): errs.append(f'KV-PT-003 {f.name}: {name} is not in part {n} owns'); continue
            if name in owner: errs.append(f'KV-PT-004 {name} appears in parts {owner[name]} and {n}'); continue
            owner[name] = n; entries[name] = (z, zi)
    missing = [i for i in range(1, total + 1) if i not in cand]
    if missing: errs.append(f'KV-PT-005 missing parts {missing}')
    if errs: die(cand, missing, sets, errs)
    tmp = pathlib.Path(tempfile.mkdtemp(prefix='kvasm-'))
    try:
        for name, (z, zi) in entries.items():
            p = tmp / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(z.read(zi))
        tgt.mkdir(parents=True, exist_ok=True)
        shutil.copytree(tmp, tgt, dirs_exist_ok=True)
    finally: shutil.rmtree(tmp, ignore_errors=True)
    dst = pathlib.Path('blueprint.json')
    if not (dst.exists() and os.path.samefile(bpf, dst)): shutil.copy(bpf, dst)
    print('PARTS', sorted(cand), 'MISSING', missing, 'SETS', sorted(sets))


main()
