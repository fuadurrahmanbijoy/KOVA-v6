#!/usr/bin/env python3
"""App Seal step 2. python scripts/wire-app.py   (run in the project folder; needs blueprint.json and the assembled ./app/ folder)
Writes app/kova.json, app/backend/main.ts, app/ui/index.html, app/ui/app.ts from the blueprint. Prints one line.
Imports use explicit .js specifiers (native ESM). Each mount()/register() call is wrapped in try/catch. Every ui/*.css is linked (sorted).
Exits non-zero, writing nothing, when an export.file does not exist."""
import json, os, sys, re, pathlib
bp = json.load(open('blueprint.json', encoding='utf8')); app = pathlib.Path('app'); app.mkdir(exist_ok=True)
back, screen = [], []
for p in bp['parts']:
    for e in p.get('exports', []):
        (back if e['kind'] == 'backend' else screen).append(e)
miss = sorted({e['file'] for e in back + screen if not (app / e['file']).is_file()})
if miss: sys.exit('FAIL export files missing: ' + ', '.join(miss))
card = dict(bp.get('card', {})); card.update({'name': bp['name'], 'type': bp['type'], 'id': bp['setId'], 'edition': 2, 'buildStamp': str(bp.get('buildStamp') or __import__('time').time_ns() // 1000000)})
json.dump(card, open(app / 'kova.json', 'w', encoding='utf8'), indent=2)


def rel(f, base):
    r = os.path.relpath(f, base).replace('\\', '/')
    r = re.sub(r'\.(?:tsx?|jsx?|mjs)$', '', r) + '.js'
    return r if r.startswith('.') else './' + r


if back:
    (app / 'backend').mkdir(exist_ok=True)
    L = [f"import {{ {e.get('fn', 'register')} as r{i} }} from '{rel(e['file'], 'backend')}';" for i, e in enumerate(back)]
    L += [''] + [f"try {{ r{i}(kova); }} catch (e) {{ kova.log('error', 'register failed: ' + String((e && e.stack) || e)); }}" for i in range(len(back))] + ['', 'kova.ready();']
    (app / 'backend' / 'main.ts').write_text('\n'.join(L) + '\n', 'utf8')
if screen:
    (app / 'ui').mkdir(exist_ok=True)
    css = ''.join(f'<link rel="stylesheet" href="{c.name}">' for c in sorted((app / 'ui').glob('*.css')))
    (app / 'ui' / 'index.html').write_text(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{bp["name"]}</title>{css}</head><body><div id="root"></div><script type="module" src="app.ts"></script></body></html>\n', 'utf8')
    L = [f"import {{ {e.get('fn', 'mount')} as m{i} }} from '{rel(e['file'], 'ui')}';" for i, e in enumerate(screen)]
    L += ['', "const root = document.getElementById('root')!;"] + [f"try {{ m{i}(root); }} catch (e) {{ console.error('[kova] mount {i} failed', e); }}" for i in range(len(screen))]
    (app / 'ui' / 'app.ts').write_text('\n'.join(L) + '\n', 'utf8')
print('OK wired:', len(back), 'backend,', len(screen), 'screen entries')
