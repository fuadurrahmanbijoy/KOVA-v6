#!/usr/bin/env python3
"""Regenerate FP:S2.x lines and CONTRACT-FP. Alias of `verify.py fp --write`.  python scripts/fp.py [md files...]
With no files: guides/*.md of this kit plus the sibling core-kit/app-kit guides when they exist next to it."""
import sys, os, glob, subprocess
d = os.path.dirname(os.path.abspath(__file__)); kit = os.path.dirname(d); top = os.path.dirname(kit)
files = sys.argv[1:] or sorted({f for k in (kit, os.path.join(top, 'core-kit'), os.path.join(top, 'app-kit')) for f in glob.glob(os.path.join(k, 'guides', '*.md'))})
sys.exit(subprocess.call([sys.executable, os.path.join(d, 'verify.py'), 'fp', '--write'] + files))
