#!/usr/bin/env python3
"""Pack one part, or validate the blueprint. Reads ./blueprint.json (written by the Blueprint/Part 1 step).
  python scripts/pack-part.py core <N> <folder-name>     e.g. core 2 installer     (zips src/<folder-name>/; folder must match N)
  python scripts/pack-part.py app <N>                    (zips the files matching parts[N].owns, relative to app/)
  python scripts/pack-part.py blueprint                  (validates and saves blueprint-<id>.json)
Options: --out DIR (or env KOVA_OUT). Default: /mnt/user-data/outputs when that folder exists, else ./out.
Output: part-N-of-M-<id>.kvpart. part.json.buildStamp is max(now_ms, blueprint stamp + 1), so a replacement part is always newer.
Refuses a bad setId, overlapping/escaping `owns`, unsafe paths, symlinks; junk (.env, node_modules, __pycache__ ...) is never packed."""
import sys, os, json, zipfile, pathlib, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kvlib as L


def main():
    a = sys.argv[1:]; out = None
    if '--out' in a: i = a.index('--out'); out = a[i + 1]; del a[i:i + 2]
    if not a: sys.exit(__doc__)
    out = pathlib.Path(out or os.environ.get('KOVA_OUT') or ('/mnt/user-data/outputs' if os.path.isdir('/mnt/user-data/outputs') else 'out'))
    try: bp = json.load(open('blueprint.json', encoding='utf8'))
    except Exception as e: sys.exit('FAIL blueprint.json missing or invalid: ' + str(e))
    errs = L.validate_blueprint(bp)
    if errs: sys.exit('FAIL blueprint: ' + '; '.join(errs))
    cid = bp.get('setId') or bp.get('id')
    out.mkdir(parents=True, exist_ok=True)
    if a[0] == 'blueprint':
        if not bp.get('buildStamp'): bp['buildStamp'] = str(L.now_ms()); json.dump(bp, open('blueprint.json', 'w', encoding='utf8'), indent=2)
        shutil.copy('blueprint.json', out / f'blueprint-{cid}.json'); print('OK', out / f'blueprint-{cid}.json'); return
    kind = a[0]
    if kind not in ('core', 'app') or len(a) < 2 or not a[1].isdigit(): sys.exit(__doc__)
    n = int(a[1]); core = L.is_core_bp(bp)
    if (kind == 'core') != core: sys.exit(f'FAIL blueprint is for {"core" if core else "app"}, not {kind}')
    total = 5 if core else len(bp['parts'])
    if not 1 <= n <= total: sys.exit(f'FAIL part {n} out of range 1..{total}')
    dest = out / f'part-{n}-of-{total}-{cid}.kvpart'
    files = []
    if core:
        if len(a) < 3 or a[2] != L.CORE_FOLDERS[n]: sys.exit(f'FAIL part {n} is folder "{L.CORE_FOLDERS[n]}"')
        root = pathlib.Path('src').resolve(); src = pathlib.Path('src') / a[2]
        if not src.is_dir(): sys.exit(f'FAIL no folder {src}')
        files = [(p, p.as_posix()) for p in sorted(src.rglob('*')) if p.is_file() and not L.is_junk(p.relative_to(src).parts)]
    else:
        root = pathlib.Path('app').resolve()
        files = [(pathlib.Path('app') / f, f) for f in L.app_files(bp['parts'][n - 1])]
    for p, arc in files:
        if p.is_symlink(): sys.exit(f'FAIL symlink not allowed: {arc}')
        try: p.resolve().relative_to(root)
        except ValueError: sys.exit(f'FAIL path outside {root.name}/: {arc}')
    if not files: sys.exit('FAIL nothing to pack')
    stamp = max(L.now_ms(), L.to_int(bp.get('buildStamp')) + 1)
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('part.json', json.dumps({'setId': cid, 'part': n, 'total': total, 'buildStamp': str(stamp), 'kind': kind, 'wiring': False}))
        for p, arc in files: z.write(p, arc)
    print('OK', dest, len(files), 'files')


main()
