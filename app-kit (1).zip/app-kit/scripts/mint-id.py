#!/usr/bin/env python3
"""Print a random 4-char id tag (a-z0-9). Never one of the guide example tags."""
import secrets, string
A = string.ascii_lowercase + string.digits
while True:
    t = ''.join(secrets.choice(A) for _ in range(4))
    if t not in ('4f9k', '7m2q', '8z6m', 'ab12', '0000'): print(t); break
